# Java — 資深工程師技能指南

> 本文件記錄資深工程師對 Java 的深度理解：不在於語法細節，而在於 JVM 的運作原理、Spring 生態系的設計哲學、Java 並發模型的本質，以及 Java 在現代後端工程中的定位與演化方向。

---

## 一、Java 的設計哲學與演化

Java 的設計原則在 1995 年誕生時是「Write Once, Run Anywhere」——透過 JVM 抽象層，讓程式碼可以在任何平台執行。這個原則至今仍然有效，但 Java 的演化方向已經從單純的跨平台，擴展到了更廣泛的工程目標。

**Java 的保守主義傳統**

Java 以向後相容性（Backward Compatibility）著稱，也以此為榮。Java 5 的程式碼今天仍然可以在 Java 21 上執行，這在主流語言中幾乎是唯一的。這種保守主義帶來的代價是：新特性的引入極其緩慢，語言演化受到大量歷史包袱的約束。

**Java 的現代化加速**

從 Java 9 開始，Java 採用了六個月的固定發布週期。Java 17 和 Java 21 是重要的 LTS（Long-Term Support）版本，引入了大量現代化特性：

- **Records（Java 16）**：不可變的資料載體，取代冗長的 POJO
- **Sealed Classes（Java 17）**：限制繼承層次，配合 Pattern Matching 使用
- **Pattern Matching（Java 21）**：更強大的型別判斷和解構
- **Virtual Threads（Java 21）**：Project Loom 的成果，徹底改變 Java 的並發模型
- **Text Blocks（Java 15）**：多行字串字面量

資深工程師應該認識到：現代 Java（17+，尤其是 21+）和十年前的 Java 是非常不同的語言。對 Java 的很多負面印象，來自於對 Java 6/7 時代的記憶，在現代 Java 中很多已經改善。

---

## 二、JVM 的深度理解

### 2.1 JVM 記憶體模型

理解 JVM 的記憶體分區，是診斷效能問題和 OOM（OutOfMemoryError）的基礎：

**Heap（堆）**：物件實例存放的地方，是 GC 管理的主要區域。分為：
- **Young Generation（年輕代）**：新建立的物件先在這裡，分為 Eden 和兩個 Survivor 區。大多數物件在這裡快速死亡（短命物件）
- **Old Generation（老年代/Tenured）**：存活多次 GC 的物件晉升到這裡。Old Generation 的 GC（Major GC/Full GC）成本遠高於 Young Generation 的 GC（Minor GC）

**Non-Heap**：
- **Metaspace（元空間，Java 8+）**：儲存類別的元資料（取代了之前的 PermGen）。預設沒有上限，如果有大量動態類別生成（如某些 ORM、位元組碼操作），可能無限成長
- **Code Cache**：JIT 編譯後的機器碼快取

**Stack**：每個 Thread 有自己的 Stack，存放 Stack Frame（本地變數、運算中間值、返回地址）。Stack 大小通常遠小於 Heap，StackOverflowError 通常是無限遞迴的信號。

### 2.2 垃圾回收器（GC）的選擇

GC 是 JVM 效能調校的核心。不同的 GC 在吞吐量（Throughput）和延遲（Latency）之間有不同的取捨：

**G1GC（Garbage-First，Java 9+ 預設）**：把 Heap 分成多個相等大小的 Region，優先回收垃圾最多的 Region。目標是在可預測的停頓時間內完成 GC，適合大多數通用場景。

**ZGC（Java 15+ 穩定）**：幾乎全程並發的 GC，停頓時間極短（通常 < 1ms），且停頓時間不隨 Heap 大小增長。代價是吞吐量略低於 G1GC。適合對延遲有嚴格要求的場景（低延遲 API、即時系統）。

**Shenandoah GC**：和 ZGC 目標類似，Red Hat 主導開發。在某些場景下比 ZGC 更快。

**選擇原則**：
- 通用後端服務 → G1GC（預設，不用特別設定）
- 對 P99 延遲敏感（< 10ms）→ ZGC
- 批次處理、高吞吐低延遲要求 → Parallel GC（`-XX:+UseParallelGC`）

### 2.3 JVM 調校的關鍵參數

```bash
# Heap 大小：-Xms（初始）和 -Xmx（最大）設成相同值，避免動態調整的開銷
-Xms4g -Xmx4g

# GC 選擇
-XX:+UseZGC          # 使用 ZGC
-XX:+UseG1GC         # 使用 G1GC（Java 9+ 預設）

# GC 日誌：生產環境必備，用於事後診斷
-Xlog:gc*:file=/var/log/app/gc.log:time,uptime,level,tags:filecount=5,filesize=20m

# Metaspace 上限（避免無限成長）
-XX:MaxMetaspaceSize=256m

# OOM 時 dump heap（用於事後分析）
-XX:+HeapDumpOnOutOfMemoryError
-XX:HeapDumpPath=/var/log/app/heapdump.hprof
```

**JVM 調校的哲學**：**不要過度調校**。先用預設設定，在有實際效能問題時，用 profiler 和 GC 日誌找到瓶頸，再針對性地調整。盲目地調整 JVM 參數往往得不償失。

### 2.4 JIT 編譯器

JVM 啟動時是解釋執行 bytecode，隨著方法被反覆呼叫，JIT（Just-In-Time）編譯器把熱點方法（Hot Method）編譯成機器碼，速度可以接近原生程式碼。

這導致了 JVM 應用的「熱身期（Warm-up）」現象：剛啟動時效能較低，運行一段時間後達到最佳效能。對於需要快速啟動的 serverless 或 CLI 場景，這是 JVM 的明顯劣勢。解法：GraalVM Native Image（AOT 編譯，但失去某些動態特性）。

---

## 三、Java 並發模型

### 3.1 傳統執行緒模型的限制

Java 的傳統並發模型是「一個請求一個 Thread」：每個 HTTP 請求由一個 OS Thread 處理，請求期間如果需要等待 I/O（資料庫、外部 API），這個 Thread 就阻塞等待。

這個模型的問題：OS Thread 是昂貴的資源（預設 512KB-1MB stack），一台機器能支撐的 Thread 數量有限（通常數千個）。高並發場景下，大量 Thread 在等待 I/O，造成資源浪費。

傳統的解法是使用 Reactive Programming（如 Reactor、RxJava）：把 I/O 操作變成非阻塞的，一個 Thread 可以同時處理多個請求。但 Reactive 的程式設計模型複雜，除錯困難，Stack Trace 難以閱讀（因為呼叫鏈被打散成 callback 鏈）。

### 3.2 Virtual Threads（Java 21，Project Loom）

Virtual Thread 是 Java 21 帶來的革命性改變，直接解決了傳統 Thread 的資源問題：

**Virtual Thread 的本質**：和 Go 的 Goroutine 類似，Virtual Thread 是 JVM 管理的輕量級執行緒，由 JVM 調度器映射到 OS Thread 上。數百萬個 Virtual Thread 是可行的。

**Virtual Thread 的核心優勢**：
- 阻塞操作（JDBC、HTTP Client）在 Virtual Thread 中不再浪費 OS Thread
- 程式碼仍然是同步風格（不需要 `async/await` 或 Reactive 的回呼式程式設計）
- Stack Trace 完整，除錯體驗與傳統 Thread 相同

```java
// 使用 Virtual Thread 處理請求（Spring Boot 3.2+ 可以一行設定開啟）
try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
    executor.submit(() -> {
        // 這裡的阻塞 I/O 不會浪費 OS Thread
        var user = userRepository.findById(userId);  // JDBC 阻塞呼叫
        var orders = orderService.getOrders(userId);  // HTTP 呼叫
        return buildResponse(user, orders);
    });
}
```

**Virtual Thread 的限制**：
- Synchronized 區塊在 Virtual Thread 中會 pin（固定）到 OS Thread，失去 Virtual Thread 的優勢。需要把 `synchronized` 改成 `ReentrantLock`
- CPU-bound 任務不適合 Virtual Thread（Virtual Thread 解決的是 I/O 等待問題，不是 CPU 問題）
- 某些依賴 ThreadLocal 的框架可能需要適配

**資深工程師的判斷**：Virtual Thread 是 Java 並發的遊戲規則改變者。對於 I/O-bound 的 Web 服務，Java 21 + Virtual Thread + 傳統同步程式碼，可以達到和 Reactive 程式設計相當的吞吐量，同時保持程式碼的簡單性。

### 3.3 Java 記憶體模型（JMM）

Java 記憶體模型定義了多執行緒程式中記憶體操作的可見性規則。

**volatile 關鍵字**：對 volatile 變數的寫入對所有 Thread 立即可見，且建立 happens-before 關係。適用於一個 Thread 寫、多個 Thread 讀的場景，但不能保證複合操作的原子性：

```java
// volatile 可以保證可見性，但不能保證原子性
private volatile boolean running = true;  // 用於停止 Thread 的旗標，OK

// 這不是原子操作，volatile 不夠！
private volatile int count = 0;
count++;  // 讀取 + 遞增 + 寫入，不是原子的
```

**atomic 類別**：提供原子的複合操作：

```java
private final AtomicInteger count = new AtomicInteger(0);
count.incrementAndGet();  // 原子的讀取-遞增-寫入
count.compareAndSet(expected, newValue);  // CAS（Compare-And-Swap）操作
```

**synchronized vs ReentrantLock**：

`synchronized` 是 Java 最基本的同步機制，簡單但功能有限。`ReentrantLock` 提供更多控制：
- 可中斷的鎖定等待（`lockInterruptibly()`）
- 超時的鎖定嘗試（`tryLock(timeout)`）
- 公平鎖（Fair Lock）
- 與 Virtual Thread 更相容（不會 pin）

```java
private final ReentrantLock lock = new ReentrantLock();
private final Condition condition = lock.newCondition();

public void produce(Item item) {
    lock.lock();
    try {
        while (buffer.isFull()) {
            condition.await();  // 等待，釋放鎖
        }
        buffer.add(item);
        condition.signalAll();
    } finally {
        lock.unlock();  // 必須在 finally 中釋放
    }
}
```

---

## 四、Spring 生態系的設計哲學

### 4.1 Spring 的核心：IoC 與 DI

Spring 的核心是 IoC（控制反轉）容器。傳統程式碼中，物件主動建立它的依賴；IoC 翻轉了這個關係：物件聲明它需要什麼依賴，由容器負責建立和注入。

**為什麼 IoC 有工程價值**：
- **可測試性**：依賴可以被 Mock 替換，不需要真實的資料庫或外部服務
- **靈活性**：改變實作不需要修改使用方
- **生命週期管理**：Spring 管理 Bean 的建立、初始化、銷毀

**依賴注入的三種方式與取捨**：

```java
// 1. 建構子注入（推薦）
@Service
public class OrderService {
    private final UserRepository userRepository;
    private final PaymentGateway paymentGateway;
    
    // 注入在建構時完成，依賴是不可變的（final）
    // 依賴清晰可見，測試時可以直接 new
    public OrderService(UserRepository userRepository,
                       PaymentGateway paymentGateway) {
        this.userRepository = userRepository;
        this.paymentGateway = paymentGateway;
    }
}

// 2. Field 注入（不推薦）
@Service
public class OrderService {
    @Autowired  // 隱藏依賴，難以測試（需要 Spring 容器），依賴可以是 null
    private UserRepository userRepository;
}

// 3. Setter 注入（適用於可選依賴）
@Service
public class OrderService {
    private MetricsCollector metricsCollector;
    
    @Autowired(required = false)
    public void setMetricsCollector(MetricsCollector collector) {
        this.metricsCollector = collector;
    }
}
```

**資深工程師的判斷**：建構子注入是最推薦的方式。它讓依賴清晰可見，讓欄位可以是 `final`（不可變），讓測試不需要 Spring 容器（可以直接 `new`）。Field 注入雖然簡潔，但是以隱藏依賴為代價，在大型系統中是維護問題的來源。

### 4.2 Spring Boot 的哲學

Spring Boot 的核心理念是「Convention over Configuration」（慣例優於配置）：提供合理的預設值，讓開發者只需要設定與預設不同的部分。

**Auto-configuration 的機制**：Spring Boot 根據 classpath 中存在的類別，自動配置對應的 Bean。例如：classpath 中有 `spring-data-jpa` 和資料庫 driver，就自動配置 DataSource、EntityManagerFactory 和事務管理。

這讓「啟動一個能連資料庫的 Spring 應用」從幾十行 XML 配置變成幾行 `application.properties`。

**Auto-configuration 的陷阱**：Magic 越多，出問題時越難診斷。理解 Spring Boot 的自動配置機制，才能在自動配置不符合需求時正確地覆蓋它。`--debug` 啟動模式和 `/actuator/conditions` endpoint 可以查看哪些自動配置被啟用。

### 4.3 Spring 事務管理

`@Transactional` 是 Spring 中最容易被誤用的功能之一：

**事務的傳播行為（Propagation）**：

```java
// REQUIRED（預設）：有事務就加入，沒有就建立新的
@Transactional(propagation = Propagation.REQUIRED)

// REQUIRES_NEW：總是建立新事務，暫停當前事務
@Transactional(propagation = Propagation.REQUIRES_NEW)
// 用途：審計日誌（即使外部事務回滾，日誌仍然保存）

// NESTED：在當前事務中建立 Savepoint
@Transactional(propagation = Propagation.NESTED)
```

**常見的 @Transactional 誤用**：

```java
@Service
public class OrderService {
    
    // 問題 1：自呼叫（Self-invocation）不會觸發事務
    public void processOrder(Order order) {
        this.updateOrder(order);  // 這個呼叫不會有事務！
        // Spring AOP 是透過代理實現的，同類內部呼叫繞過了代理
    }
    
    @Transactional
    public void updateOrder(Order order) { ... }
    
    // 問題 2：在 @Transactional 中 catch 了 RuntimeException 且沒有重新拋出
    @Transactional
    public void badProcess(Order order) {
        try {
            riskyOperation();
        } catch (RuntimeException e) {
            log.error("Error", e);
            // 沒有 rethrow！事務不會回滾，但錯誤被吞掉了
        }
    }
    
    // 問題 3：在事務中做耗時的外部呼叫
    @Transactional
    public void longTransaction(Order order) {
        orderRepository.save(order);
        externalApiCall();  // 這個呼叫期間資料庫連線被鎖住
        notificationService.send(order);
    }
}
```

**資深工程師對事務的判斷**：事務應該儘量短。在事務中做外部 API 呼叫、發送郵件、或任何耗時操作，會長時間持有資料庫連線，降低系統吞吐量。把這些副作用操作移到事務之外，或使用事務性的訊息佇列（Transactional Outbox Pattern）。

### 4.4 Spring Data JPA 的最佳實踐

**N+1 問題**：

```java
// 問題：載入 Order 後，每個 Order 的 items 都是懶加載
// 查詢 N 個 Order 會產生 N+1 個 SQL 查詢
List<Order> orders = orderRepository.findAll();
orders.forEach(o -> o.getItems().size());  // 每個 Order 都觸發一次查詢

// 解法 1：JOIN FETCH
@Query("SELECT o FROM Order o JOIN FETCH o.items WHERE o.userId = :userId")
List<Order> findByUserIdWithItems(@Param("userId") String userId);

// 解法 2：@EntityGraph
@EntityGraph(attributePaths = {"items", "items.product"})
List<Order> findByUserId(String userId);
```

**Projection（投影）**：只查詢需要的欄位，避免載入整個實體：

```java
// Interface-based Projection
public interface OrderSummary {
    String getId();
    BigDecimal getTotalAmount();
    OrderStatus getStatus();
}

List<OrderSummary> summaries = orderRepository.findSummariesByUserId(userId);
// SQL 只 SELECT 需要的欄位，不是 SELECT *
```

---

## 五、現代 Java 特性的工程含義

### 5.1 Records（Java 16+）

Record 是不可變的資料載體，自動生成 constructor、accessor、`equals`、`hashCode`、`toString`：

```java
// 舊方式：大量樣板程式碼
public class Point {
    private final int x;
    private final int y;
    public Point(int x, int y) { this.x = x; this.y = y; }
    public int x() { return x; }
    public int y() { return y; }
    // equals, hashCode, toString...
}

// Record：簡潔且不可變
public record Point(int x, int y) {}

// Record 可以有自定義 compact constructor（驗證邏輯）
public record PositivePoint(int x, int y) {
    public PositivePoint {
        if (x < 0 || y < 0) throw new IllegalArgumentException("Coordinates must be positive");
    }
}
```

Record 是 DTO、Value Object、API Response 的理想選擇。

### 5.2 Sealed Classes + Pattern Matching（Java 17/21）

```java
// Sealed Class：限制可能的子類型
public sealed interface Shape permits Circle, Rectangle, Triangle {}

public record Circle(double radius) implements Shape {}
public record Rectangle(double width, double height) implements Shape {}
public record Triangle(double base, double height) implements Shape {}

// Pattern Matching + switch（Java 21）
double area = switch (shape) {
    case Circle c -> Math.PI * c.radius() * c.radius();
    case Rectangle r -> r.width() * r.height();
    case Triangle t -> 0.5 * t.base() * t.height();
    // 編譯器知道所有可能的型別，不需要 default
};
```

Sealed Classes + Pattern Matching 讓 Java 可以做到類似 Haskell/Rust 的代數資料型別（ADT）風格，配合 Exhaustiveness Check，是建模領域物件的強大工具。

---

## 六、Java 的適用場景與整體判斷

**Java 的最佳適用場景**：
- 大型企業後端系統（生態系成熟、工具完善、人才市場廣）
- 需要長期維護的系統（向後相容性的保證讓升級成本低）
- 金融、電信等需要成熟生態的領域（Spring、Hibernate、Kafka 生態系）
- 需要 JVM 生態系其他語言（Kotlin、Scala）互操作的系統

**Java 的挑戰**：
- 啟動時間慢（不適合 serverless，GraalVM Native Image 可緩解）
- 記憶體使用量較高（JVM 的固有開銷）
- 語言演化相對其他現代語言慢（但近年加速）
- 在某些場景下，Go 或 Rust 有更好的效能和更低的資源消耗

**現代 Java 的工程師視角**：Java 21 是一個真正現代化的 Java，Virtual Thread 解決了最大的架構限制，Records 和 Pattern Matching 讓程式碼更簡潔。對於熟悉 Java 生態系的團隊，升級到 Java 21 的收益是顯著的，且升級風險較低（向後相容性保證）。Java 不是過去，是仍然在積極演化的主流語言。
