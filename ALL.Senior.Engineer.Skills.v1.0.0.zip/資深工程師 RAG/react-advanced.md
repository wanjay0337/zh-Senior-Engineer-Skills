# React Advanced — 資深工程師技能指南

> 本文件記錄資深工程師對 React 深層機制的理解：不只是 API 的使用方式，而是 React 的渲染模型、Concurrent 特性的本質、自定義 Hook 的設計哲學，以及 React Server Components 對前端架構的根本影響。

---

## 一、React 的渲染模型

### 1.1 React 的工作原理：Reconciliation

React 的核心工作是把元件樹映射到 DOM，並在狀態改變時高效地更新 DOM。這個過程叫做 Reconciliation（協調）。

**Render Phase（渲染階段）**：React 呼叫元件函式，建立新的 Virtual DOM 樹，和上次的 Virtual DOM 樹進行比較（Diffing），計算出最小的 DOM 變更。這個階段是純粹計算，沒有副作用，可以被中斷和重複執行（Concurrent Mode 的基礎）。

**Commit Phase（提交階段）**：把計算出的 DOM 變更實際應用到 DOM 上，執行副作用（`useEffect`、`useLayoutEffect`）。這個階段是不可中斷的，必須同步完成。

**這個分離的工程意義**：Render Phase 可中斷意味著 React 可以在渲染大型元件樹時，暫停讓瀏覽器處理更緊急的任務（如使用者輸入），再繼續渲染。這就是 Concurrent Mode 的核心。

### 1.2 Fiber 架構

React 16 引入的 Fiber 架構讓 Reconciliation 可以被中斷。每個 React 元件對應一個 Fiber 節點，形成一個 Fiber 樹。

**Fiber 是工作單元**：React 可以在處理完一個 Fiber 後，檢查是否有更高優先級的工作需要先做，如果有就暫停當前工作，稍後再恢復。

**兩棵樹**：React 維護兩棵 Fiber 樹：
- **Current Tree**：當前螢幕上顯示的狀態
- **Work In Progress Tree**：正在計算的新狀態

當 Work In Progress Tree 計算完成，兩棵樹互換，這個操作叫做「commitRoot」。

### 1.3 渲染的觸發條件

了解什麼會觸發 React 重新渲染，是效能優化的基礎：

**會觸發重新渲染的操作**：
- `setState`（Class Component）或 `useState` 的 setter
- `useReducer` 的 dispatch
- 父元件重新渲染（預設情況下，子元件跟著重新渲染）
- Context 的值改變（所有消費者重新渲染）

**不會觸發重新渲染的操作**：
- `useRef` 的值改變（ref 不是 reactive）
- 元件外部的普通 JavaScript 變數改變

**Bailout（跳過渲染）**：React 有多個機制讓元件在不需要更新時跳過渲染：
- `React.memo`：props 沒有改變時跳過
- `useMemo` 返回相同的值時，依賴它的計算不重複執行
- setState 傳入和當前完全相同的值時（Object.is 相等），React 跳過重新渲染

---

## 二、Concurrent Features

### 2.1 什麼是 Concurrent Mode

Concurrent Mode 是 React 18 的核心，讓 React 可以同時處理多個工作，並根據優先級決定哪個先完成。

**同步渲染（舊模式）**：React 開始渲染後，必須一口氣完成，中間不能被打斷。如果渲染很慢（大型元件樹），使用者輸入在這段時間內會被阻塞。

**並發渲染（新模式）**：React 可以開始渲染，在中間暫停，讓瀏覽器處理使用者輸入，然後繼續渲染。使用者互動始終流暢。

React 18 中，使用 `createRoot` 就自動啟用了 Concurrent Mode（而不是舊的 `ReactDOM.render`）。

### 2.2 useTransition：區分緊急與非緊急更新

`useTransition` 讓你標記某些狀態更新是「非緊急的」，React 可以在有更緊急的任務時中斷它：

```typescript
function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [isPending, startTransition] = useTransition();

  function handleSearch(e: React.ChangeEvent<HTMLInputElement>) {
    const newQuery = e.target.value;
    
    // 緊急：立即更新 input 的顯示
    setQuery(newQuery);
    
    // 非緊急：搜尋結果可以稍慢更新
    startTransition(() => {
      setResults(filterResults(newQuery));
    });
  }

  return (
    <>
      <input value={query} onChange={handleSearch} placeholder="搜尋..." />
      {isPending && <Spinner />}
      <ResultList results={results} />
    </>
  );
}
```

**`isPending` 的用途**：在 Transition 進行中，`isPending` 是 `true`。你可以用它顯示 loading 指示器，告訴使用者「正在更新」，但不阻塞使用者繼續輸入。

**`startTransition` vs `setTimeout`**：都可以延遲更新，但 `startTransition` 讓 React 知道這是可以被中斷的工作，而不只是延遲執行。如果使用者在 Transition 進行中做了新的操作，React 可以放棄當前的 Transition 直接進行新的渲染。

### 2.3 useDeferredValue：推遲特定值的更新

`useDeferredValue` 讓你推遲某個值的更新，讓 UI 先顯示舊值，在空閒時才更新到新值：

```typescript
function ProductList({ searchQuery }: { searchQuery: string }) {
  // deferredQuery 在搜尋時先保持舊值，在空閒時才更新
  const deferredQuery = useDeferredValue(searchQuery);
  
  // 用 deferredQuery 做昂貴的過濾
  const filteredProducts = useMemo(
    () => expensiveFilter(products, deferredQuery),
    [products, deferredQuery]
  );

  // 當 searchQuery 和 deferredQuery 不同時，說明正在 deferred
  const isStale = searchQuery !== deferredQuery;
  
  return (
    <div style={{ opacity: isStale ? 0.7 : 1 }}>
      {filteredProducts.map(p => <ProductCard key={p.id} {...p} />)}
    </div>
  );
}
```

**`useDeferredValue` vs `useTransition` 的選擇**：
- `useTransition`：你控制觸發更新的程式碼（如自己的 setState），用 `startTransition` 包裝
- `useDeferredValue`：你無法控制觸發更新的地方（如 props 從父元件傳來），用 `useDeferredValue` 推遲這個值的消費

### 2.4 Suspense 的完整語意

Suspense 不只是用於 `React.lazy` 的程式碼分割，它是 React 的資料載入協調機制：

```typescript
// 傳統理解：只用於 lazy loading
const HeavyComponent = React.lazy(() => import('./HeavyComponent'));

// 完整語意：任何「等待狀態」的協調
function App() {
  return (
    <ErrorBoundary fallback={<ErrorPage />}>
      <Suspense fallback={<PageSkeleton />}>
        {/* 這裡的任何元件都可以「掛起」（suspend） */}
        <UserDashboard />
      </Suspense>
    </ErrorBoundary>
  );
}

// 支援 Suspense 的資料獲取（TanStack Query、SWR 都支援）
function UserDashboard() {
  // 如果資料未就緒，這個元件會 suspend
  // React 會顯示最近的 Suspense fallback
  const { data: user } = useSuspenseQuery({
    queryKey: ['user'],
    queryFn: fetchUser,
  });
  
  return <div>Welcome, {user.name}</div>;
}
```

**Suspense 的工作原理**：當元件在渲染時拋出一個 Promise，React 會：
1. 捕捉這個 Promise
2. 顯示最近的 `Suspense` fallback
3. 等待 Promise resolve
4. 重新渲染元件

**Suspense 的組合**：多個 Suspense 邊界可以分層，讓不同部分的頁面獨立顯示：

```typescript
function Dashboard() {
  return (
    <div>
      <Suspense fallback={<HeaderSkeleton />}>
        <Header />
      </Suspense>
      <div className="grid">
        <Suspense fallback={<ChartSkeleton />}>
          <SalesChart />
        </Suspense>
        <Suspense fallback={<TableSkeleton />}>
          <RecentOrders />
        </Suspense>
      </div>
    </div>
  );
}
```

---

## 三、自定義 Hook 的設計哲學

### 3.1 自定義 Hook 的本質

自定義 Hook 不是「把邏輯放進函式」，而是**把有狀態的邏輯封裝成可重用的單元**。和普通函式的區別是：自定義 Hook 可以使用 React 的 Hook（`useState`、`useEffect` 等），普通函式不行。

**一個好的自定義 Hook 應該**：
- 封裝一個完整的、有意義的行為（不只是打包幾個 useState）
- 有清晰的介面（輸入參數和返回值）
- 把複雜的邏輯隱藏在 Hook 內部，讓使用方只看到簡單的 API

### 3.2 自定義 Hook 的設計模式

**資料獲取 Hook**：

```typescript
// 封裝 API 呼叫、loading、error 狀態
function useUser(userId: string) {
  return useQuery({
    queryKey: ['user', userId],
    queryFn: () => fetchUser(userId),
    enabled: !!userId,
  });
}

// 使用方：極簡
function UserProfile({ userId }: { userId: string }) {
  const { data: user, isLoading, error } = useUser(userId);
  if (isLoading) return <Skeleton />;
  if (error) return <ErrorMessage />;
  return <div>{user.name}</div>;
}
```

**事件監聽 Hook**：

```typescript
// 封裝 event listener 的添加和清理
function useWindowSize() {
  const [size, setSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    function handleResize() {
      setSize({ width: window.innerWidth, height: window.innerHeight });
    }
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);  // cleanup
  }, []);  // 空依賴陣列：只在 mount/unmount 時執行

  return size;
}
```

**局部狀態機 Hook**：

```typescript
type FormState =
  | { status: 'idle' }
  | { status: 'submitting' }
  | { status: 'success'; data: Order }
  | { status: 'error'; error: string };

function useOrderForm() {
  const [state, setState] = useState<FormState>({ status: 'idle' });

  const submit = useCallback(async (formData: OrderFormData) => {
    setState({ status: 'submitting' });
    try {
      const order = await createOrder(formData);
      setState({ status: 'success', data: order });
    } catch (err) {
      setState({ status: 'error', error: getErrorMessage(err) });
    }
  }, []);

  const reset = useCallback(() => {
    setState({ status: 'idle' });
  }, []);

  return { state, submit, reset };
}
```

**防抖 Hook**：

```typescript
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(timer);  // 每次 value 改變時清除前一個 timer
  }, [value, delay]);

  return debouncedValue;
}

// 使用：搜尋輸入防抖
function SearchInput() {
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounce(query, 300);

  // debouncedQuery 在使用者停止輸入 300ms 後才更新
  const { data } = useSearch(debouncedQuery);
}
```

### 3.3 useEffect 的正確心智模型

`useEffect` 是 React 中最容易被誤用的 Hook。

**正確的心智模型**：`useEffect` 是讓你把元件和「外部系統」同步的機制（外部系統：DOM、第三方庫、網路、計時器等）。它不是「生命週期」的替代品。

**Effect 的依賴陣列**：依賴陣列告訴 React「當這些值改變時，重新執行這個 Effect」。**依賴陣列必須包含 Effect 中使用的所有 reactive 值**（state、props、元件內的函式和物件）。

```typescript
// 常見錯誤：依賴陣列不完整
useEffect(() => {
  fetchData(userId);  // userId 沒有在依賴陣列中
}, []);  // eslint-disable-line — 抑制 ESLint 警告是掩蓋問題

// 正確：完整的依賴陣列
useEffect(() => {
  fetchData(userId);
}, [userId, fetchData]);  // fetchData 也要包含（如果它會改變）
```

**不應該用 useEffect 的情況**（React 官方文件強調）：

```typescript
// ❌ 不要用 useEffect 同步 state
const [firstName, setFirstName] = useState('');
const [lastName, setLastName] = useState('');
const [fullName, setFullName] = useState('');

useEffect(() => {
  setFullName(firstName + ' ' + lastName);  // 多餘的重新渲染
}, [firstName, lastName]);

// ✅ 直接在渲染時計算
const fullName = firstName + ' ' + lastName;  // 不需要 state，直接派生
```

**Effect 的清理函式**：每個 Effect 都應該考慮是否需要清理。訂閱要取消訂閱、計時器要清除、Event listener 要移除、Fetch 要 abort：

```typescript
useEffect(() => {
  const controller = new AbortController();
  
  fetchData({ signal: controller.signal })
    .then(data => setData(data))
    .catch(err => {
      if (err.name !== 'AbortError') setError(err);
    });

  // 元件 unmount 或依賴改變時，abort 進行中的 fetch
  return () => controller.abort();
}, [userId]);
```

### 3.4 useRef 的完整用途

`useRef` 不只是用來存 DOM 引用，而是任何「需要持久存在但不觸發重新渲染」的值：

```typescript
// 用途 1：存 DOM 元素的引用
const inputRef = useRef<HTMLInputElement>(null);
const focus = () => inputRef.current?.focus();

// 用途 2：存任何不觸發重新渲染的值
const renderCountRef = useRef(0);
renderCountRef.current++;  // 改變 ref 不觸發重新渲染

// 用途 3：存上一個渲染的值（Previous Value Pattern）
function usePrevious<T>(value: T): T | undefined {
  const prevRef = useRef<T>();
  
  useEffect(() => {
    prevRef.current = value;
  });  // 沒有依賴陣列：每次渲染後執行
  
  return prevRef.current;  // 返回「上次渲染」的值
}

// 用途 4：存 interval/timeout 的 ID 用於清理
const timerRef = useRef<ReturnType<typeof setInterval>>();

useEffect(() => {
  timerRef.current = setInterval(tick, 1000);
  return () => clearInterval(timerRef.current);
}, []);

// 用途 5：讓 Effect 可以存取最新的 callback 但不觸發重跑
function useInterval(callback: () => void, delay: number) {
  const savedCallback = useRef(callback);
  
  useEffect(() => {
    savedCallback.current = callback;  // 永遠更新到最新的 callback
  });

  useEffect(() => {
    function tick() {
      savedCallback.current();  // 呼叫最新的 callback
    }
    const id = setInterval(tick, delay);
    return () => clearInterval(id);
  }, [delay]);  // 只有 delay 改變才重新設定 interval
}
```

---

## 四、React Server Components

### 4.1 RSC 的根本創新

React Server Components（RSC）是 React 架構的根本性改變，不只是效能優化，而是重新思考「哪些程式碼應該在哪裡執行」。

**傳統架構的問題**：
- 所有元件程式碼都下載到客戶端（即使是渲染靜態內容的元件）
- 資料獲取必須在客戶端發起 API 請求（有網路往返延遲）
- 或者在 SSR 時必須在伺服器獲取，但只能在路由層面（`getServerSideProps`）

**RSC 的解法**：讓元件在伺服器端執行，直接存取後端資源（資料庫、檔案系統），結果以 RSC Payload 的形式傳給客戶端，元件的程式碼不需要下載到客戶端。

### 4.2 Server Component vs Client Component 的邊界

```typescript
// Server Component（預設，不需要 'use server' 指令）
// 可以：直接 async/await、存取資料庫、存取伺服器資源
// 不能：使用 useState、useEffect、瀏覽器 API、事件處理器
async function ProductList({ categoryId }: { categoryId: string }) {
  // 直接查詢資料庫！不需要 API 端點
  const products = await db.product.findMany({
    where: { categoryId },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <ul>
      {products.map(product => (
        // Server Component 可以渲染 Client Component
        <li key={product.id}>
          <ProductCard product={product} />
          {/* AddToCartButton 需要互動，是 Client Component */}
          <AddToCartButton productId={product.id} />
        </li>
      ))}
    </ul>
  );
}

// Client Component：'use client' 指令標記
'use client';
function AddToCartButton({ productId }: { productId: string }) {
  const [isPending, setIsPending] = useState(false);
  
  const handleClick = async () => {
    setIsPending(true);
    await addToCart(productId);
    setIsPending(false);
  };
  
  return (
    <button onClick={handleClick} disabled={isPending}>
      {isPending ? '加入中...' : '加入購物車'}
    </button>
  );
}
```

### 4.3 Server Component 的資料獲取模型

RSC 讓「在元件樹中任意位置獲取資料」成為可能，且每個元件可以獨立獲取它需要的資料：

```typescript
// 不需要在頁面頂層獲取所有資料，每個元件按需獲取
async function ProductPage({ productId }: { productId: string }) {
  // 並行獲取所有資料
  const [product, reviews, recommendations] = await Promise.all([
    getProduct(productId),
    getReviews(productId),
    getRecommendations(productId),
  ]);

  return (
    <div>
      <ProductDetail product={product} />
      <ReviewSection reviews={reviews} />
      <Recommendations products={recommendations} />
    </div>
  );
}
```

**消除了 props drilling 的資料獲取**：在傳統架構中，為了讓深層元件獲取資料，要麼把資料從頂層一路往下傳（props drilling），要麼引入全局狀態管理。RSC 讓深層的 Server Component 可以直接獲取它需要的資料：

```typescript
// 深層元件直接獲取自己需要的資料，不需要 props 傳遞
async function UserAvatar({ userId }: { userId: string }) {
  const user = await getUser(userId);  // 直接獲取，不是從 props 接收
  return <img src={user.avatarUrl} alt={user.name} />;
}
```

### 4.4 Server Actions

Server Action 是在 Client Component 中呼叫伺服器端函式的機制：

```typescript
// actions.ts（Server Action）
'use server';

export async function createOrder(formData: FormData) {
  const userId = await getCurrentUserId();
  const order = await db.order.create({
    data: {
      userId,
      productId: formData.get('productId') as string,
      quantity: Number(formData.get('quantity')),
    },
  });
  
  revalidatePath('/orders');  // 讓 /orders 頁面重新獲取資料
  redirect(`/orders/${order.id}`);
}

// Client Component 中使用 Server Action
'use client';
import { createOrder } from './actions';

function OrderForm({ productId }: { productId: string }) {
  return (
    // action 可以直接是 Server Action
    <form action={createOrder}>
      <input type="hidden" name="productId" value={productId} />
      <input type="number" name="quantity" defaultValue={1} />
      <button type="submit">下訂單</button>
    </form>
  );
}
```

Server Action 的安全注意事項：Server Action 是公開的 HTTP endpoint，需要在 Server Action 內部驗證使用者身分和權限，不能依賴客戶端傳來的 userId 等敏感資訊。

---

## 五、效能模式

### 5.1 元件組合避免不必要的重新渲染

一個常被忽視的技巧：透過元件組合而不是 `React.memo` 來避免重新渲染：

```typescript
// 問題：ExpensiveComponent 因為 Parent 的 count 改變而重新渲染
function Parent() {
  const [count, setCount] = useState(0);
  return (
    <div>
      <button onClick={() => setCount(c => c + 1)}>{count}</button>
      <ExpensiveComponent />  {/* 每次 count 改變都重新渲染 */}
    </div>
  );
}

// 解法 1：提取包含 state 的部分，讓 ExpensiveComponent 作為 children
function CounterSection({ children }: { children: React.ReactNode }) {
  const [count, setCount] = useState(0);
  return (
    <div>
      <button onClick={() => setCount(c => c + 1)}>{count}</button>
      {children}  {/* children 的引用不會因為 count 改變 */}
    </div>
  );
}

function Parent() {
  return (
    <CounterSection>
      <ExpensiveComponent />  {/* 不再因為 count 改變而重新渲染 */}
    </CounterSection>
  );
}
```

這個技巧利用了 `children` 是從父元件傳來的，當包含 state 的元件重新渲染時，`children` 的引用沒有改變（因為它是由更上層的元件建立的）。

### 5.2 虛擬化（Virtualization）

對大型列表（超過幾百項），只渲染視窗內可見的項目：

```typescript
import { useVirtualizer } from '@tanstack/react-virtual';

function VirtualList({ items }: { items: Item[] }) {
  const parentRef = useRef<HTMLDivElement>(null);

  const virtualizer = useVirtualizer({
    count: items.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 60,  // 估計每個項目的高度
  });

  return (
    <div ref={parentRef} style={{ height: '400px', overflow: 'auto' }}>
      {/* 只有可見項目的總高度 */}
      <div style={{ height: `${virtualizer.getTotalSize()}px`, position: 'relative' }}>
        {virtualizer.getVirtualItems().map(virtualItem => (
          <div
            key={virtualItem.key}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: `${virtualItem.size}px`,
              transform: `translateY(${virtualItem.start}px)`,
            }}
          >
            <ListItem item={items[virtualItem.index]} />
          </div>
        ))}
      </div>
    </div>
  );
}
```

### 5.3 狀態提升與下移的效能含義

**狀態下移（State Colocation）**：把 state 移動到真正需要它的最低層元件，減少不必要的重新渲染範圍：

```typescript
// 問題：modal 的 state 在最頂層，每次開關都重新渲染所有元件
function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  return (
    <div>
      <HeavyList />        {/* 每次 isModalOpen 改變都重新渲染 */}
      <AnotherSection />   {/* 每次 isModalOpen 改變都重新渲染 */}
      {isModalOpen && <Modal onClose={() => setIsModalOpen(false)} />}
      <button onClick={() => setIsModalOpen(true)}>Open</button>
    </div>
  );
}

// 解法：把 modal 相關的 state 下移到只需要它的元件中
function ModalTrigger() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <button onClick={() => setIsOpen(true)}>Open</button>
      {isOpen && <Modal onClose={() => setIsOpen(false)} />}
    </>
  );
}

function App() {
  return (
    <div>
      <HeavyList />       {/* 不再因為 modal 狀態改變而重新渲染 */}
      <AnotherSection />  {/* 不再因為 modal 狀態改變而重新渲染 */}
      <ModalTrigger />    {/* modal 的 state 封裝在這裡 */}
    </div>
  );
}
```

---

## 六、Error Boundary

### 6.1 Error Boundary 的工作原理

Error Boundary 是 React 元件，用於捕獲子元件樹在渲染過程中、生命週期方法中、和建構函式中的 JavaScript 錯誤，並顯示 fallback UI：

```typescript
// Error Boundary 必須是 Class Component（目前沒有 Hook 等效）
class ErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // 記錄錯誤到監控服務
    logErrorToService(error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// react-error-boundary 套件提供更好的 API
import { ErrorBoundary } from 'react-error-boundary';

function App() {
  return (
    <ErrorBoundary
      fallback={<ErrorPage />}
      onError={(error, info) => logError(error, info)}
    >
      <ProductCatalog />
    </ErrorBoundary>
  );
}
```

### 6.2 Error Boundary 無法捕獲的錯誤

Error Boundary 只能捕獲渲染期間的錯誤，不能捕獲：
- 事件 handler 中的錯誤（需要用 try/catch）
- 非同步程式碼中的錯誤（setTimeout、Promise）
- Server-side rendering 的錯誤
- Error Boundary 元件本身的錯誤

---

## 七、資深工程師對 React 的整體判斷

**React 的核心優勢**：龐大的生態系、成熟的工具鏈、React 18 的 Concurrent 特性、RSC 對全棧架構的革新。在 Web 前端，React 仍然是大型工程組織的最主流選擇。

**React 的複雜度成本**：Concurrent Mode、Server Components、Streaming SSR——這些特性強大，但概念複雜。資深工程師的責任是理解這些機制，在適當的時候使用，不是把所有新特性都強加到每個專案。

**React 哲學的核心**：React 的設計不斷強調「讓元件是純粹的（Pure）」——相同的輸入應該產生相同的輸出，副作用應該明確地隔離。理解這個哲學，是理解 `useEffect`、RSC、Strict Mode 的關鍵。Strict Mode 在開發時雙重渲染元件，就是為了幫助發現不純粹的元件。
