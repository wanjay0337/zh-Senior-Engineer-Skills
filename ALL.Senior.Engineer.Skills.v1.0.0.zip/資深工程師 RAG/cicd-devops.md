# CI/CD & DevOps — 資深工程師技能指南

> 本文件記錄資深工程師對 CI/CD 與 DevOps 的思維框架：不是工具的操作手冊，而是「為什麼要這樣建置 pipeline」、「部署策略背後的取捨」、以及「DevOps 文化的本質是什麼」。

---

## 一、DevOps 的本質

DevOps 不是一個職位，不是一套工具，而是一種**組織文化和工作方式的改變**。

傳統模式中，開發（Dev）和維運（Ops）是兩個目標對立的部門：開發想要快速交付新功能，維運想要系統穩定不出問題。這種對立造成了「把程式碼丟過牆」的文化——開發完成就是 Ops 的事，出了問題互相推諉。

DevOps 的核心轉變是：**讓開發團隊對自己的程式碼在生產環境的行為負責**。「You build it, you run it」（Amazon 的 Werner Vogels）。這不只是技術問題，更是責任感的重新分配。

當開發工程師要 on-call，他們就會開始關心：部署流程是否安全？回滾是否容易？監控是否到位？錯誤是否容易診斷？這些問題的答案，直接影響系統的設計決策。

**DORA Metrics（DevOps Research and Assessment）**：這四個指標是衡量 DevOps 成熟度最有效的框架：

| 指標 | 說明 | 精英團隊的水準 |
|------|------|--------------|
| Deployment Frequency | 部署頻率 | 每天多次 |
| Lead Time for Changes | 從 commit 到生產的時間 | 不到一小時 |
| Change Failure Rate | 部署導致失敗的比例 | 低於 5% |
| Time to Restore | 從故障到恢復的時間 | 不到一小時 |

這四個指標同時提升是可能的，速度和穩定性不是對立的。精英工程組織同時擁有高部署頻率和低故障率，因為小批量、高頻率的部署本身就降低了每次部署的風險。

---

## 二、持續整合（CI）的設計哲學

### 2.1 CI 的核心價值

持續整合的核心不是工具，而是**一個實踐：每個人每天多次把程式碼整合到主線**。

這個實踐的背後邏輯是：整合越延遲，衝突越大，解決成本越高。兩週才整合一次的分支，合併時往往是一場災難。每天整合的分支，衝突很少且容易解決。

CI Pipeline 是讓這個實踐可行的技術基礎設施：每次 commit 或 PR 自動執行一系列驗證，在幾分鐘內告訴工程師這次改動是否破壞了任何東西。

### 2.2 CI Pipeline 的設計原則

**快速反饋**：CI Pipeline 越快，工程師就越願意等待結果而不是切換任務。超過 10 分鐘的 pipeline 開始讓人失去耐心，超過 20 分鐘就會被放著不管。

加速 Pipeline 的策略：
- **平行執行**：測試、lint、安全掃描可以同時執行，不需要依序
- **快取依賴**：npm install、pip install 的結果應該快取，只有 lock file 改變時才重新安裝
- **Smart Test Selection**：只執行受改動影響的測試（在大型 monorepo 中尤其重要）
- **Test Sharding**：把測試分散到多個 runner 並行執行

**Fail Fast**：最快、最可能失敗的檢查應該放在最前面。Lint 和型別檢查通常是最快的，放在第一步。如果 lint 就失敗了，不需要等測試跑完。

**Pipeline 即程式碼**：Pipeline 的定義（`.github/workflows/*.yml`、`Jenkinsfile`、`.gitlab-ci.yml`）應該和程式碼一起版本控制，有 review、有歷史記錄。不能接受「CI 設定在某個 UI 裡手動設置」的狀況。

### 2.3 CI Pipeline 的標準結構

```
Commit → Lint & Format Check
       → Type Check（若有靜態型別）
       → Unit Tests
       → Build（確認可以成功建置）
       → Integration Tests
       → Security Scan（SAST、依賴漏洞）
       → (PR merge) → Build Docker Image
                    → Push to Registry
                    → Deploy to Staging
                    → E2E Tests on Staging
                    → (手動 approve) → Deploy to Production
```

**什麼應該 block merge**：
- ✅ 測試失敗
- ✅ Lint / 型別錯誤
- ✅ 已知安全漏洞（高風險等級）
- ✅ 覆蓋率低於門檻（謹慎設定，避免覆蓋率遊戲）
- ❌ 效能測試（太慢，適合在 merge 後執行）
- ❌ 程式碼風格的個人偏好（應該用工具強制，不是人工 block）

### 2.4 Trunk-Based Development vs Feature Branches

**Feature Branches + PR**（最常見）：每個功能在獨立分支開發，透過 PR 合併到主線。優點是 PR review 流程自然，缺點是分支生命週期過長時整合成本高。

**Trunk-Based Development**：直接在主線（trunk/main）開發，或使用非常短命的分支（不超過一天）。優點是整合頻繁、CI 真正有效；缺點是需要 Feature Flag 支援未完成的功能、對團隊紀律要求高。

資深工程師的判斷：**長命分支是 CI 的天敵**。一個存活兩週的 feature branch，在合併時往往是最痛苦的。無論選擇哪種策略，分支的生命週期應該以天計算，而不是週或月。

---

## 三、持續交付與持續部署（CD）

### 3.1 持續交付 vs 持續部署的區別

**持續交付（Continuous Delivery）**：每次 commit 都產出一個**可以**部署到生產環境的版本，但部署本身需要人工決策。

**持續部署（Continuous Deployment）**：每次 commit 在通過所有驗證後**自動**部署到生產環境，不需要人工介入。

哪個更好？取決於業務和系統的特性：
- 需要業務審批才能上線的功能 → 持續交付
- 後端 API 服務、高度自動化測試的系統 → 持續部署
- 有合規要求（change management process）的企業環境 → 持續交付

最重要的是：**部署應該是無聊的日常操作，不是一個重大事件**。如果「部署到生產」需要全員緊張等待，那就需要改善部署策略和信心來源（測試、監控）。

### 3.2 部署策略

#### Rolling Deployment（滾動部署）

逐步用新版本替換舊版本的實例，每次替換一部分，直到全部更新完成。

```
Old: [v1][v1][v1][v1]
  → [v2][v1][v1][v1]
  → [v2][v2][v1][v1]
  → [v2][v2][v2][v1]
  → [v2][v2][v2][v2]
```

**優點**：簡單，不需要額外的資源（不需要雙倍的伺服器）。
**缺點**：部署過程中新舊版本同時在線，如果 API 有不相容的改動，混合狀態可能造成問題。回滾需要再做一次滾動部署，速度較慢。

#### Blue-Green Deployment（藍綠部署）

維護兩個完全相同的生產環境（Blue 和 Green），永遠只有一個在接流量。部署時在不接流量的環境部署新版本，測試通過後切換流量。

```
Blue (v1) ← 流量
Green (v2) ← 部署新版本，測試

切換：
Blue (v1) ← 閒置
Green (v2) ← 流量
```

**優點**：零停機部署；回滾只需要切換流量，幾乎是即時的；新版本可以在不接生產流量的情況下做 smoke test。
**缺點**：需要雙倍的基礎設施成本；資料庫 migration 的處理複雜（兩個版本可能同時存取同一個資料庫）。

#### Canary Deployment（金絲雀部署）

先把新版本部署給一小部分流量（如 1%、5%），觀察指標後再逐步擴大比例。

```
v1 ← 99% 流量
v2 ← 1% 流量（金絲雀）

觀察 error rate、latency、業務指標...

v1 ← 50% 流量
v2 ← 50% 流量

全部通過後 →
v2 ← 100% 流量
```

**優點**：風險最低，問題只影響一小部分使用者；可以在真實流量下驗證新版本的行為；支援 A/B testing。
**缺點**：部署時間較長；需要成熟的監控和自動化來決定何時擴大流量比例；流量路由的基礎設施複雜度較高。

**資深工程師的選擇邏輯**：
- 小型系統或初期 → Rolling Deployment 夠用
- 需要即時回滾能力 → Blue-Green
- 高風險改動、大型系統 → Canary

#### Feature Flags（功能旗標）

Feature Flag 是一種讓**部署和功能發布解耦**的技術。程式碼部署到生產環境，但功能被 Flag 關閉，可以在任何時間點開啟。

```python
if feature_flags.is_enabled("new_checkout_flow", user=current_user):
    return new_checkout_flow()
else:
    return old_checkout_flow()
```

Feature Flag 的強大之處：
- **Trunk-Based Development 的基礎**：未完成的功能可以合併到主線，只要用 flag 關閉
- **漸進式發布**：先對內部使用者開放，再對 beta 用戶，再全量
- **即時回滾**：不需要回滾部署，只需要關閉 flag
- **A/B Testing**：不同使用者看到不同版本

**Feature Flag 的技術債風險**：Flag 是有成本的，程式碼中的 if-else 會在 flag 長期存在後變成難以理解的分支。每個 flag 都應該有明確的退場計劃：何時全量開啟、何時移除 flag 的程式碼。

---

## 四、容器化與 Kubernetes

### 4.1 容器化的核心價值

Docker 容器解決的核心問題是**環境一致性**：「在我的機器上可以跑」的問題。容器把應用程式和它的所有依賴打包在一起，確保在任何環境（開發機、CI、Staging、Production）的行為一致。

容器化的哲學：
- **不可變基礎設施（Immutable Infrastructure）**：不是更新伺服器上的程式碼，而是替換容器。舊容器刪除，新容器啟動
- **一個容器一個程序**：每個容器只執行一個主程序，職責單一
- **設定從環境變數注入**：不把設定硬編碼在 image 中，讓同一個 image 可以在不同環境（Staging/Production）以不同設定執行

### 4.2 Kubernetes 的設計哲學

Kubernetes（K8s）是容器的編排系統，負責：在哪裡執行容器、如何擴展、如何處理故障、如何進行服務發現。

**宣告式（Declarative）vs 命令式（Imperative）**

Kubernetes 的核心哲學是宣告式：你描述**期望的狀態**，K8s 負責達到並維持這個狀態。

```yaml
# 宣告式：我要三個 replica
spec:
  replicas: 3
```

你不需要說「啟動這個容器」、「如果它掛了就重啟」，而是說「我要三個在線的實例」，K8s 會確保這個狀態被維持。

**K8s 核心概念的設計邏輯**：

- **Pod**：最小部署單位，一個或多個緊密相關的容器
- **Deployment**：管理 Pod 的副本數和滾動更新策略
- **Service**：穩定的網路端點，把流量路由到 Pod（Pod 的 IP 是暫時的，Service 的 IP 是穩定的）
- **ConfigMap / Secret**：把設定和敏感資訊從容器 image 中分離
- **Ingress**：HTTP/HTTPS 的流量入口，處理 routing、SSL termination

**資深工程師對 K8s 的判斷**：K8s 是強大但複雜的工具。對於小型團隊或早期系統，K8s 的維運成本可能遠超其帶來的好處。AWS ECS、Google Cloud Run、Heroku 等更簡單的選項往往更適合。只有當系統規模和複雜度真的需要 K8s 的能力時，才值得引入。

---

## 五、基礎設施即程式碼（Infrastructure as Code）

### 5.1 核心哲學

Infrastructure as Code（IaC）是指用程式碼來描述和管理基礎設施（伺服器、網路、資料庫、IAM 等），而不是透過 UI 手動操作。

**為什麼 IaC 是必要的**：
- **可重現性**：能夠在任何時間點重建完全相同的環境
- **版本控制**：基礎設施的變更有歷史記錄，可以 review、可以回滾
- **消除雪花伺服器（Snowflake Server）**：每台伺服器都稍微不同，因為有人手動改過一些設定。這種不一致是維運噩夢
- **審計和合規**：誰在什麼時間改了什麼基礎設施，git log 就是答案

### 5.2 Terraform 的設計哲學

Terraform 是最主流的 IaC 工具，用宣告式的 HCL 語言描述基礎設施的期望狀態：

```hcl
resource "aws_rds_instance" "main" {
  identifier     = "production-db"
  engine         = "postgres"
  instance_class = "db.t3.medium"
  allocated_storage = 100
}
```

**State 管理是 Terraform 最重要的概念**：Terraform 維護一個 state 文件，記錄它管理的資源的當前狀態。State 要存在遠端（S3 + DynamoDB for locking），不能放在本地，否則團隊協作時會出現衝突。

**Plan Before Apply**：`terraform plan` 讓你在實際執行前看到變更的影響。在 CI 中，PR 應該自動跑 `terraform plan` 並把輸出放在 PR comment，讓 reviewer 看到這次改動會對基礎設施造成什麼影響。

### 5.3 IaC 的模組化設計

好的 IaC 應該和好的程式碼一樣模組化：

```
infrastructure/
├── modules/
│   ├── vpc/          # 可重用的 VPC 模組
│   ├── rds/          # 可重用的 RDS 模組
│   └── eks/          # 可重用的 EKS 模組
├── environments/
│   ├── staging/      # Staging 環境使用這些模組
│   └── production/   # Production 環境使用同樣的模組（不同參數）
```

Staging 和 Production 使用相同的模組，只有參數不同（如 instance size、replica count）。這確保兩個環境的結構一致，Staging 的測試結果有意義。

---

## 六、環境管理策略

### 6.1 環境的設計原則

**Production Parity（生產環境等同性）**：開發、測試、生產環境應該儘量相似。環境差異是「在我的機器上可以跑」問題的根本原因。

常見的環境差異和解決方式：
- **服務版本**：用 Docker 固定版本
- **設定差異**：統一用環境變數，不同環境注入不同的值
- **資料差異**：可以，但注意不要用生產資料做測試（PII 問題）

### 6.2 Secret 管理

**絕對不能把 Secret 放在 git repository 中**：API key、資料庫密碼、JWT secret 一旦進入 git 歷史，即使之後刪除，歷史記錄中仍然存在。

Secret 管理的正確方式：
- **環境變數**：在 CI/CD 系統或容器 runtime 中注入
- **Secret Manager**：AWS Secrets Manager、HashiCorp Vault、GCP Secret Manager
- **K8s Secrets**：在 Kubernetes 環境中，用 Secret 物件存儲，透過 volume 或環境變數注入到 Pod

**Secret Rotation**：定期輪換 secret 是安全最佳實踐。好的系統設計應該讓 secret rotation 不需要停機（應用程式能夠在不重啟的情況下載入新的 secret）。

---

## 七、Deployment Pipeline 的成熟度模型

從低到高的 Pipeline 成熟度：

**Level 1 - 手動部署**：工程師手動 SSH 到伺服器、執行部署腳本。高風險，依賴個人經驗，無法追蹤。

**Level 2 - 腳本化部署**：有部署腳本，但仍需手動觸發。可重現，但沒有驗證步驟。

**Level 3 - CI Pipeline**：自動執行測試和 lint，PR 合併前有品質門檻。

**Level 4 - 持續交付**：每次 commit 產出可部署的 artifact，部署到 staging 自動化，生產部署需要手動核准。

**Level 5 - 持續部署**：全自動，通過所有驗證後自動部署到生產。監控和告警成熟，有完善的回滾機制。

**Level 6 - 進階實踐**：Canary 部署、自動回滾（基於 error rate）、混沌工程（主動注入故障驗證韌性）。

---

## 八、回滾策略

回滾策略是部署策略的另一面，資深工程師在設計部署流程時要同時考慮回滾：

**應用程式回滾**：
- Rolling Deployment：重新部署上一個版本（需要時間）
- Blue-Green：切回 Blue 環境（幾乎即時）
- Feature Flag：關閉 flag（最快，但不適用所有情境）

**資料庫 Migration 的回滾問題**：應用程式可以快速回滾，但資料庫 migration 往往很難回滾。設計 migration 的原則：
- **向後相容的 migration**：新欄位預設 nullable；舊欄位在新版本穩定後才刪除；不直接改變現有欄位的型別
- **分階段部署**：先部署能同時相容新舊 schema 的應用程式，再執行 migration，再部署只支援新 schema 的版本，最後清理舊欄位
- **永遠準備 rollback migration 腳本**：每個 migration 都要有對應的 rollback

**資深工程師的原則**：**如果不知道怎麼回滾，就不應該部署**。在高風險部署前，明確定義回滾步驟，並確保回滾可以在需要的時間內完成。

---

## 九、CI/CD 的常見反模式

**The Snowflake Pipeline**：Pipeline 設定在 CI 工具的 UI 中手動維護，沒有版本控制。沒有人知道它為什麼這樣設置，沒有人敢改動它。

**Build Once, Deploy Many（被違反）**：每個環境分別 build，導致 Staging 和 Production 跑的不是同一個 binary。正確做法是 build 一次，同一個 artifact 部署到所有環境，設定從外部注入。

**長命 Staging Branch**：有一個 `staging` 分支，和 `main` 分支長期不同步。結果是 staging 測試通過的東西，到 production 可能失敗（因為兩個環境跑的程式碼不同）。

**部署恐懼**：部署是一件大事，需要全員待命，部署後緊張觀察。這通常是缺乏測試信心、缺乏監控、缺乏快速回滾能力的綜合症狀。解法不是減少部署頻率，而是讓每次部署更小、更安全。

**忽視 Pipeline 速度**：CI 跑了 40 分鐘，但沒有人認為這是問題。慢的 Pipeline 是工程效率的隱性殺手，應該像對待 production 效能問題一樣認真對待。
