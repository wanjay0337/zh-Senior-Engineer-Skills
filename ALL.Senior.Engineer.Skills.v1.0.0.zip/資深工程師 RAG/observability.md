# Observability — 資深工程師技能指南

> 本文件記錄資深工程師對可觀測性（Observability）的思維框架：不只是「裝了什麼監控工具」，而是「如何設計一個讓你在生產環境出問題時能夠快速理解系統狀態的系統」。可觀測性是系統設計的一部分，不是事後補充的功能。

---

## 一、可觀測性的本質

**Monitoring（監控）vs Observability（可觀測性）的區別**

這是業界常見的混淆。兩者的差異不只是程度，而是思維方式的不同：

**Monitoring** 是預先定義你想知道什麼，然後收集這些資料。它回答的是：「我預期的問題有沒有發生？」它有一個隱含假設：你能夠預測系統會以什麼方式出問題。

**Observability** 是讓系統的內部狀態可以從外部被推斷出來，不管問題以什麼形式出現。它回答的是：「這個我從來沒見過的問題，發生了什麼？」

Charity Majors（Honeycomb 創辦人）的定義：一個系統是可觀測的，如果你可以在不修改程式碼、不重新部署的情況下，回答任何關於系統內部狀態的問題。

**為什麼 Observability 在現代系統中更重要**

傳統的 Monitoring 在簡單的單體系統中夠用——你知道系統會以哪些方式出問題，為這些情況設置告警就好。但在分散式系統中：
- 系統的故障模式是 emergent 的（從個別元件的行為無法預測整體的失敗方式）
- 問題往往是多個因素的組合（某個服務的慢查詢 × 特定使用者的特定操作 × 流量高峰）
- 你無法預先枚舉所有可能的問題

**可觀測性的核心價值**：讓你在生產環境出現前所未見的問題時，能夠用已有的資料推理出問題的根因，而不需要「再加一些 log 然後等問題重現」。

---

## 二、三本柱：Logs、Metrics、Traces

可觀測性的三種基本資料類型各有優勢，相互補充。

### 2.1 Logs（日誌）

**本質**：系統在特定時間點發生的事件的文字記錄，有完整的上下文。

**優勢**：
- 最豐富的資訊來源，可以包含任意細節
- 適合記錄離散事件（請求、錯誤、業務操作）
- 調查特定事件時，log 通常是最直接的答案

**劣勢**：
- 儲存成本高（尤其是高吞吐系統）
- 不適合做趨勢分析（需要聚合計算）
- 結構不一致時難以查詢和分析

**結構化日誌（Structured Logging）**

非結構化 log 是原罪：
```
# 非結構化：人看得懂，機器難以解析
[2024-01-15 10:23:45] ERROR: Payment failed for user 12345, amount 1000, reason: insufficient funds

# 結構化：人和機器都能處理
{
  "timestamp": "2024-01-15T10:23:45Z",
  "level": "ERROR",
  "event": "payment_failed",
  "user_id": "12345",
  "amount": 1000,
  "currency": "TWD",
  "reason": "insufficient_funds",
  "trace_id": "abc123",
  "duration_ms": 45
}
```

結構化 log 讓你可以：用 `user_id = 12345` 過濾所有相關事件、統計 `payment_failed` 的頻率、關聯 `trace_id` 找到完整的請求鏈。

**Log Level 的正確使用**

log level 是過濾和告警的基礎，誤用會讓 log 失去意義：

- **DEBUG**：詳細的開發資訊，只在開發或除錯時啟用。生產環境通常關閉
- **INFO**：正常的業務事件（使用者登入、訂單建立、定期任務完成）。這是告訴你「系統在做什麼」
- **WARN**：非預期但可以自動恢復的情況（重試成功、使用了降級邏輯）。這是「有些奇怪但暫時沒問題」
- **ERROR**：需要人工介入的錯誤（操作失敗、外部服務不可用）。這是「有東西壞了」
- **FATAL / CRITICAL**：系統即將崩潰或已經無法運作的嚴重錯誤

**常見誤用**：把所有 exception 都 log 為 ERROR，導致 ERROR level 充斥著「使用者輸入了錯誤的密碼」這種預期中的事件，讓真正的 ERROR 被淹沒。使用者的操作錯誤通常是 INFO 或 WARN，不是 ERROR。

**Log 的什麼時候記、記什麼**

每個 HTTP 請求的完成（包含 method、path、status code、duration）是最基本的。在此之上：
- 業務關鍵操作（支付、訂單狀態變更、帳戶變更）
- 外部服務的呼叫（API 呼叫的結果、延遲）
- 非預期的情況（catch 到的 exception、重試）
- 重要的系統事件（服務啟動/關閉、設定載入、連線建立/斷開）

**永遠不能 log 的東西**：密碼、token、信用卡號、身份證號碼、任何 PII（個人識別資訊）。這是安全和合規的基本要求。

### 2.2 Metrics（指標）

**本質**：隨時間變化的數值資料，適合做趨勢分析和告警。

**優勢**：
- 儲存成本低（數值比文字小得多）
- 適合做聚合、趨勢分析、告警
- 長期保存可以分析週期性模式

**劣勢**：
- 預先定義，無法回答預期外的問題
- 高基數（High Cardinality）的 label 會讓儲存成本爆炸
- 無法提供單個請求的詳細上下文

**四種基本 Metric 類型**

**Counter（計數器）**：只能遞增的數值，重啟後歸零。用於計算事件的發生次數（請求數、錯誤數、訊息處理數）。查詢時通常計算 rate（每秒多少次）而不是絕對值。

**Gauge（儀表）**：可以任意增減的數值，代表當前狀態（記憶體使用量、當前連線數、隊列長度）。

**Histogram（直方圖）**：把數值分配到預先定義的 bucket，用來計算分位數（P50、P95、P99）。最適合用於延遲分佈。

**Summary（摘要）**：和 Histogram 類似，但分位數在客戶端計算，無法跨多個實例聚合。現代系統通常偏好 Histogram。

**為什麼平均值（Average）是危險的指標**

平均延遲（Average Latency）是一個常見但有誤導性的指標。假設 100 個請求中，99 個花了 10ms，1 個花了 10000ms，平均是 109ms——這個數字既不代表大多數使用者的體驗，也沒有顯示出那個極端慢的請求。

**P99 延遲才是真正重要的**：它代表最差的 1% 使用者的體驗。對於服務間呼叫，P99 尤其重要，因為多個服務串聯時，每個服務的 P99 都會讓整體的尾部延遲更差。

**The Four Golden Signals（Google SRE Book）**

監控任何服務，這四個指標是最基本的：

1. **Latency（延遲）**：請求需要多長時間？要區分成功和失敗的延遲（失敗的請求可能快速失敗，讓平均延遲看起來很好）
2. **Traffic（流量）**：系統正在處理多少請求？（RPS、QPS）
3. **Errors（錯誤）**：失敗的請求比例是多少？要同時看 rate 和比例
4. **Saturation（飽和度）**：系統有多接近極限？（CPU 使用率、記憶體使用率、連線池使用率）

**High Cardinality 的問題**

Metric 的 label 是用來過濾和分組的，但 label 的唯一值數量（基數）必須是有限的。

```
# 低基數 label（正確）
http_requests_total{method="GET", status="200", service="user-api"}

# 高基數 label（危險！）
http_requests_total{user_id="12345", ...}  # user_id 有幾百萬個唯一值
```

高基數 label 會讓 Metric 的時間序列爆炸，造成監控系統的儲存和查詢效能問題。User ID、Request ID、IP Address 這類高基數的值，屬於 Log 或 Trace，不應該放在 Metric label 中。

### 2.3 Traces（分散式追蹤）

**本質**：追蹤一個請求在分散式系統中的完整旅程，記錄它經過了哪些服務、在每個服務花了多少時間。

**優勢**：
- 唯一能讓你看到跨服務請求完整路徑的工具
- 能夠精確定位延遲在哪個服務、哪個操作
- 能夠展示服務依賴關係和瓶頸

**劣勢**：
- 儲存成本高（通常需要採樣）
- 需要在所有服務中統一實作
- 查詢和分析比 Metrics 複雜

**Trace 的基本概念**

- **Trace**：一個請求的完整旅程，由一個唯一的 `trace_id` 識別
- **Span**：Trace 中的一個操作單元（一個函式呼叫、一個資料庫查詢、一個外部 API 呼叫）。Span 有開始時間、結束時間、操作名稱、標籤
- **Parent-Child 關係**：Span 之間有父子關係，構成一個 DAG（有向無環圖）

```
Trace: abc123
└── [API Gateway] handle_request (50ms)
    ├── [User Service] get_user (10ms)
    │   └── [DB] SELECT users (8ms)
    ├── [Order Service] get_orders (35ms)
    │   ├── [DB] SELECT orders (20ms)
    │   └── [Cache] get_product_details (5ms)
    └── [Response] serialize (2ms)
```

從這個 Trace 可以立刻看出：Order Service 是瓶頸，其中 DB 查詢佔了大部分時間。

**Context Propagation（上下文傳遞）**

Trace 能夠跨服務工作的關鍵，是 `trace_id` 和 `span_id` 在服務間的傳遞。每個服務收到請求時，從 header 中讀取 `trace_id`，在處理完後繼續傳遞給下游服務。

標準格式：W3C TraceContext（`traceparent` header）是現在的業界標準，統一了不同工具的格式。

**採樣策略（Sampling）**

高吞吐系統不能記錄 100% 的 Trace（成本太高）。採樣策略：

- **Head-based Sampling（頭部採樣）**：在請求開始時決定是否採樣，簡單但可能遺漏低頻的重要事件
- **Tail-based Sampling（尾部採樣）**：請求完成後根據結果決定是否保留（如：所有錯誤都保留、延遲超過閾值的都保留）。需要緩衝完整的 Trace 後再決定，成本較高但更智慧

---

## 三、可觀測性的設計原則

### 3.1 從第一天就設計可觀測性

可觀測性不是上線後再補的功能，是系統設計的一部分。在設計 API、服務、資料模型時，同時考慮：

- 這個操作成功/失敗時，我如何知道？
- 如果這個服務變慢，我如何定位原因？
- 如果使用者回報問題，我能否用他們提供的資訊在 log 中找到對應的事件？

### 3.2 Correlation ID（關聯 ID）

每個請求都應該有一個唯一的 ID（Request ID / Correlation ID），在整個請求鏈中傳遞，並出現在所有相關的 log、metric、trace 中。

```
User → API Gateway (request_id: xyz789)
     → User Service (trace_id: abc123, request_id: xyz789)
     → DB query (trace_id: abc123)
```

當使用者回報問題，他們提供 request_id，你就能立刻找到所有相關的記錄。沒有這個機制，在 log 海中找一個特定請求的記錄，是大海撈針。

### 3.3 SLI、SLO、SLA 的框架

**SLI（Service Level Indicator）**：衡量服務品質的具體指標。例如：成功請求的比例、P99 延遲。

**SLO（Service Level Objective）**：對 SLI 設定的目標。例如：99.9% 的請求在 200ms 內完成，錯誤率低於 0.1%。

**SLA（Service Level Agreement）**：對外承諾的服務等級，通常有違約賠償。SLA 通常比 SLO 寬鬆（留有緩衝）。

**Error Budget（錯誤預算）**

SLO 的另一面是 Error Budget：如果 SLO 是 99.9% 的可用性，那每個月允許的停機時間是 43.2 分鐘。這 43.2 分鐘就是 Error Budget。

Error Budget 的哲學：
- **預算充足時**：可以大膽推進新功能、接受更高風險的部署
- **預算耗盡時**：停止新功能部署，把所有精力放在可靠性改善

這個框架把可靠性從「工程師的直覺」變成可以和業務對話的具體指標：「我們這個月已經用完了 Error Budget，如果繼續部署，SLA 會被違反。」

### 3.4 告警設計哲學

**告警的兩種錯誤**：
- **False Positive（誤報）**：系統沒問題但告警響了。太多誤報讓工程師開始忽略告警（告警疲勞），最終真正的問題出現時沒有人在乎
- **False Negative（漏報）**：系統出問題但沒有告警。這是更危險的情況

**告警應該是 actionable 的**：每個告警響起，都應該有明確的處理步驟。「CPU 使用率 > 80%」不是一個好告警，因為 CPU 高可能是正常的業務高峰，也可能是問題，沒有上下文無法判斷。

更好的告警策略：**基於症狀（Symptom）而不是原因（Cause）**。
- ❌ 原因告警：CPU > 80%、記憶體 > 90%（可能是假警報）
- ✅ 症狀告警：Error Rate > 1%、P99 Latency > 2s、成功請求數突然下降（這些直接影響使用者）

**告警的分級**

不是所有問題都需要半夜叫醒 on-call 工程師：

- **PagerDuty / 立即通知（Immediate）**：使用者正在受影響，需要立即回應（Error Rate 飆升、服務完全不可用）
- **Slack 通知（Warn）**：有問題但不緊急，在工作時間處理（錯誤率略高但未超過 SLO、某個隊列積壓增加）
- **Ticket / 工作時間處理（Info）**：趨勢值得關注但不需要立即行動（磁碟使用率持續增長、某個服務的 P95 延遲緩慢上升）

---

## 四、實務工具生態

### 4.1 開源工具棧

**Metrics**：Prometheus（收集和儲存）+ Grafana（視覺化）是最主流的開源組合。Prometheus 使用 pull 模式從服務拉取 metrics，每個服務暴露 `/metrics` endpoint。

**Logs**：ELK Stack（Elasticsearch + Logstash + Kibana）或 Loki（更輕量，和 Grafana 整合好）。

**Traces**：Jaeger 或 Zipkin 是最常用的開源分散式追蹤系統。OpenTelemetry 是現在的標準 SDK，可以同時匯出到多個後端。

### 4.2 OpenTelemetry 的重要性

OpenTelemetry（OTel）是目前最重要的可觀測性標準，由 CNCF 主導，獲得所有主要雲端廠商和工具的支持。

**為什麼重要**：在 OTel 之前，不同的可觀測性工具有各自的 SDK，切換工具需要修改所有的 instrumentation 程式碼。OTel 提供了統一的 API 和 SDK，instrumentation 和後端解耦：只需要改設定，就能把資料從 Jaeger 切換到 Datadog，不需要修改應用程式碼。

**Auto-instrumentation**：OTel 對主流框架（Django、Express、Spring Boot、gin）提供自動 instrumentation，不需要手動在每個函式加 span，大幅降低接入成本。

### 4.3 商業工具

**Datadog**：最完整的商業可觀測性平台，整合 Metrics、Logs、Traces，並有 APM、RUM、Synthetic Monitoring 等進階功能。成本較高，但整合度極好。

**New Relic**、**Dynatrace**：類似 Datadog 的完整解決方案。

**Grafana Cloud**：開源工具的托管版本，降低維運成本。

**Honeycomb**：專注在高基數資料的分析，適合需要深度除錯的工程團隊。

---

## 五、可觀測性的成熟度模型

**Level 1 - 基本 Monitoring**：有基本的系統指標（CPU、記憶體、磁碟）和基本的告警。出了問題，主要靠猜和 SSH 到伺服器看 log。

**Level 2 - 結構化 Logging**：所有服務輸出結構化 log，集中到 log 管理系統。有 request_id 可以追蹤單一請求。出了問題，可以查 log 找到線索。

**Level 3 - Metrics 和告警**：有完整的業務和技術 metrics，有基於症狀的告警，有 Grafana dashboard。出了問題，可以看 dashboard 快速理解當前狀態。

**Level 4 - 分散式追蹤**：有跨服務的 distributed tracing，可以看到請求的完整旅程。出了問題，可以精確定位是哪個服務、哪個操作造成的。

**Level 5 - 可觀測性文化**：團隊在開發時就考慮可觀測性，新功能上線前就有對應的 dashboard 和告警，定期進行 on-call 演習，持續改善可觀測性。出了問題，通常在使用者回報之前就已經被發現。

---

## 六、資深工程師的可觀測性設計 Checklist

在設計或 review 一個新服務時：

**Logging**
- [ ] 所有請求都有完整的 access log（method、path、status、duration）
- [ ] 所有錯誤都有足夠的上下文（request_id、user_id、錯誤原因）
- [ ] 所有外部呼叫都有 log（目標、結果、延遲）
- [ ] 沒有任何 PII 或敏感資料出現在 log 中
- [ ] Log level 使用正確

**Metrics**
- [ ] 四個 Golden Signals 都有對應的 metric
- [ ] 業務關鍵操作有對應的 metric（訂單建立成功率、支付成功率）
- [ ] Metric label 沒有高基數問題

**Tracing**
- [ ] 服務接受並傳遞 trace context
- [ ] 關鍵操作有對應的 span
- [ ] Span 有足夠的 attribute 提供上下文

**告警**
- [ ] 有基於 SLO 的告警（Error Rate、Latency）
- [ ] 告警有 runbook（出現時該怎麼做）
- [ ] 告警是 actionable 的，不會產生告警疲勞

**Dashboard**
- [ ] 有服務的 overview dashboard
- [ ] On-call 工程師看 dashboard 能夠快速判斷系統是否健康
