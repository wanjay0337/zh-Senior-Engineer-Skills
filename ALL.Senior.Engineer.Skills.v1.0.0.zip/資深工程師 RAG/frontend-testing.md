# Frontend Testing — 資深工程師技能指南

> 本文件記錄資深工程師對前端測試的思維框架：不只是工具的使用方式，而是「為什麼前端測試比後端測試更難」、「測試應該從使用者視角出發而不是實作細節」、以及如何建立一套讓工程師有信心重構的前端測試策略。

---

## 一、前端測試的根本挑戰

前端測試比後端測試難，原因是多方面的：

**UI 是不斷變化的**：UI 細節（元素的位置、樣式、命名）變動頻率遠高於業務邏輯。如果測試和 UI 細節強耦合，每次設計調整都會讓大量測試失敗，工程師很快就放棄維護測試。

**非同步無處不在**：點擊按鈕後 API 呼叫、Loading 狀態、資料出現——測試需要處理大量的非同步操作，timing 問題是前端測試最常見的不穩定（Flaky）來源。

**瀏覽器環境的複雜性**：瀏覽器 API（localStorage、fetch、IntersectionObserver）在 Node.js 環境不存在，需要 mock 或模擬。

**「測試什麼」的哲學問題**：是測試「這個元件的狀態是 X」，還是測試「使用者能夠看到/做到 Y」？這個問題的答案決定了測試的長期可維護性。

---

## 二、前端測試的哲學基礎

### 2.1 Testing Library 的核心哲學

Kent C. Dodds 在設計 React Testing Library 時提出的原則，已成為前端測試的主流哲學：

**"The more your tests resemble the way your software is used, the more confidence they can give you."**

這個原則的具體含義：測試應該模擬真實使用者的行為，而不是測試元件的內部實作。

```typescript
// 錯誤：測試實作細節（脆弱，重構後即使行為沒變也會失敗）
expect(wrapper.state('isMenuOpen')).toBe(true);
expect(component.find('Button').prop('onClick')).toBeDefined();

// 正確：測試使用者可見的行為（穩健，只要行為正確就通過）
await userEvent.click(screen.getByRole('button', { name: '開啟選單' }));
expect(screen.getByRole('menu')).toBeVisible();
```

### 2.2 查詢優先順序（Query Priority）

Testing Library 提供多種查詢方式，優先順序從高到低：

**1. 語意化查詢（最推薦）**：
- `getByRole`：按 ARIA role 查詢（button、link、heading、textbox 等）
- `getByLabelText`：按 `<label>` 的文字查詢表單元素
- `getByPlaceholderText`：按 placeholder 查詢

**2. 文字內容查詢**：
- `getByText`：按可見文字查詢

**3. 測試 ID（最後手段）**：
- `getByTestId`：按 `data-testid` 屬性查詢

**為什麼優先使用 `getByRole`**：role 是元素的語意，只有當元素的語意改變時才會失效（如把 button 改成 div）。而 `data-testid` 和元素的語意無關，是純粹的測試產物，且使用 `getByRole` 會間接推動開發者寫出更無障礙（Accessible）的 HTML。

```typescript
// 用 getByRole 查詢各種元素
screen.getByRole('button', { name: '提交' });
screen.getByRole('heading', { level: 1 });
screen.getByRole('textbox', { name: '電子郵件' });
screen.getByRole('combobox', { name: '國家' });
screen.getByRole('checkbox', { name: '同意條款' });
```

### 2.3 不測試的東西

和「要測什麼」同樣重要的是「不要測什麼」：

- **不測試第三方庫的行為**：React、UI 框架庫已經有自己的測試
- **不測試實作細節**：元件用了什麼 state、用了什麼 hook、元件的結構如何
- **不測試靜態 UI**：「這個按鈕是藍色的」用視覺回歸測試而不是 unit test
- **不過度測試**：每個互動都寫 E2E 測試會讓 test suite 極慢且脆弱

---

## 三、單元測試與整合測試

### 3.1 Vitest vs Jest

**Vitest** 是現代前端專案的首選測試框架，特別是使用 Vite 的專案：

- **速度**：使用 Vite 的轉換管線，極快的啟動速度和 HMR
- **設定簡單**：直接使用 `vite.config.ts` 的設定，不需要額外的 Babel 設定
- **API 相容 Jest**：遷移成本低，大多數 Jest 程式碼可以直接用
- **ESM 原生支援**：不需要 transform，直接支援 ESM

**什麼時候仍然用 Jest**：使用 Webpack 或 Create React App 的舊專案；有大量 Jest 特有 API（jest.fakeTimers、jest.spyOn 進階用法）的專案。

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',       // 模擬瀏覽器環境
    globals: true,               // 不需要 import describe, it, expect
    setupFiles: './src/test/setup.ts',
  },
});

// src/test/setup.ts
import '@testing-library/jest-dom';  // 擴充 expect 的 matcher
```

### 3.2 React Testing Library 的核心用法

```typescript
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { UserProfile } from './UserProfile';

describe('UserProfile', () => {
  it('顯示使用者資訊', async () => {
    // Arrange：渲染元件
    render(<UserProfile userId="123" />);

    // Assert：等待資料載入後出現
    expect(await screen.findByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('john@example.com')).toBeInTheDocument();
  });

  it('使用者可以更新暱稱', async () => {
    // Arrange
    const user = userEvent.setup();
    render(<UserProfile userId="123" />);
    await screen.findByText('John Doe');  // 等待初始載入

    // Act：模擬使用者操作
    await user.click(screen.getByRole('button', { name: '編輯' }));
    await user.clear(screen.getByRole('textbox', { name: '暱稱' }));
    await user.type(screen.getByRole('textbox', { name: '暱稱' }), 'Johnny');
    await user.click(screen.getByRole('button', { name: '儲存' }));

    // Assert：確認結果
    expect(await screen.findByText('已儲存')).toBeInTheDocument();
  });

  it('API 失敗時顯示錯誤訊息', async () => {
    // 用 MSW 模擬 API 失敗（見第四節）
    server.use(
      http.put('/api/users/123', () => new HttpResponse(null, { status: 500 }))
    );

    const user = userEvent.setup();
    render(<UserProfile userId="123" />);
    await screen.findByText('John Doe');

    await user.click(screen.getByRole('button', { name: '編輯' }));
    await user.click(screen.getByRole('button', { name: '儲存' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('儲存失敗，請稍後再試');
  });
});
```

### 3.3 非同步測試的正確方式

非同步是前端測試最多陷阱的地方：

```typescript
// ❌ 錯誤：使用固定的 waitFor 時間
await new Promise(resolve => setTimeout(resolve, 1000));
expect(screen.getByText('Loaded')).toBeInTheDocument();

// ❌ 錯誤：act() 警告通常意味著有非同步更新沒有被等待
// 不要手動 wrap act()，讓 userEvent 和 findBy 查詢處理它

// ✅ 正確：使用 findBy 查詢（自動等待元素出現）
const element = await screen.findByText('Loaded');  // 預設等待 1000ms

// ✅ 正確：使用 waitFor 等待條件成立
await waitFor(() => {
  expect(screen.getByText('Loaded')).toBeInTheDocument();
});

// ✅ 正確：userEvent 自動處理非同步操作
const user = userEvent.setup();
await user.click(button);  // 自動等待所有相關的 DOM 更新
```

**`findBy` vs `getBy` vs `queryBy` 的選擇**：
- `getBy`：元素應該存在，不存在就報錯（同步）
- `findBy`：元素可能非同步出現，等待它出現（非同步，返回 Promise）
- `queryBy`：元素可能不存在，不存在返回 null（用於確認元素不存在）

```typescript
// 確認元素不存在的正確方式
expect(screen.queryByText('Error Message')).not.toBeInTheDocument();
// 不要用 getBy，因為 getBy 找不到會直接拋出錯誤
```

### 3.4 自定義 Hook 的測試

```typescript
import { renderHook, act } from '@testing-library/react';
import { useCounter } from './useCounter';

describe('useCounter', () => {
  it('初始值為 0', () => {
    const { result } = renderHook(() => useCounter());
    expect(result.current.count).toBe(0);
  });

  it('increment 使計數增加', () => {
    const { result } = renderHook(() => useCounter());

    act(() => {
      result.current.increment();
    });

    expect(result.current.count).toBe(1);
  });
});
```

---

## 四、API Mock 與 MSW

### 4.1 Mock Service Worker（MSW）的核心價值

MSW（Mock Service Worker）在 Service Worker 層攔截 HTTP 請求，讓你可以在不修改應用程式碼的情況下 mock API 回應。

**MSW 的優勢**：
- **與實作無關**：不管應用用 `fetch`、`axios`、還是 `react-query`，MSW 都能攔截
- **真實的網路行為**：測試中的請求和生產環境一樣通過網路層（在 jsdom 環境中模擬），不需要 mock 個別的函式
- **開發和測試共用 handler**：同一套 MSW handler 可以在開發時作為 mock server，在測試中作為 test double
- **更好的測試信心**：測試更接近真實的 HTTP 呼叫

```typescript
// src/mocks/handlers.ts：定義 API handler
import { http, HttpResponse } from 'msw';

export const handlers = [
  http.get('/api/users/:id', ({ params }) => {
    const { id } = params;
    return HttpResponse.json({
      id,
      name: 'John Doe',
      email: 'john@example.com',
    });
  }),

  http.put('/api/users/:id', async ({ request, params }) => {
    const body = await request.json();
    return HttpResponse.json({ ...body, id: params.id });
  }),

  http.post('/api/orders', async ({ request }) => {
    const order = await request.json();
    return HttpResponse.json({ id: 'order_123', ...order }, { status: 201 });
  }),
];

// src/mocks/server.ts：測試環境的 MSW 設定
import { setupServer } from 'msw/node';
import { handlers } from './handlers';

export const server = setupServer(...handlers);

// src/test/setup.ts：在所有測試前後啟動/重置/停止 MSW
import { server } from '../mocks/server';

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());  // 每個測試後重置，讓 handler 不互相影響
afterAll(() => server.close());
```

### 4.2 在特定測試中覆蓋 Handler

```typescript
import { server } from '../mocks/server';
import { http, HttpResponse } from 'msw';

it('伺服器錯誤時顯示錯誤訊息', async () => {
  // 只在這個測試中覆蓋 handler
  server.use(
    http.get('/api/users/123', () => {
      return new HttpResponse(null, { status: 500 });
    })
  );

  render(<UserProfile userId="123" />);
  expect(await screen.findByRole('alert')).toBeInTheDocument();
  // resetHandlers() 在 afterEach 會自動恢復預設 handler
});
```

### 4.3 MSW 的開發模式整合

```typescript
// src/mocks/browser.ts：瀏覽器環境的 MSW（開發時使用）
import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

export const worker = setupWorker(...handlers);

// src/main.tsx：只在開發模式啟用
async function enableMocking() {
  if (process.env.NODE_ENV !== 'development') return;
  const { worker } = await import('./mocks/browser');
  return worker.start({ onUnhandledRequest: 'warn' });
}

enableMocking().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
});
```

這讓前端開發可以完全不依賴後端 API，加速開發迭代。

---

## 五、E2E 測試：Playwright

### 5.1 Playwright 的設計哲學

Playwright 是目前最強大的 E2E 測試框架，由 Microsoft 維護。相較於 Cypress，Playwright 的優勢：

- **跨瀏覽器**：支援 Chromium、Firefox、WebKit（Safari 引擎），一套測試驗證所有瀏覽器
- **多 Tab/視窗**：可以測試跨視窗的操作（如 OAuth 流程）
- **強大的等待機制**：自動等待元素可交互（Auto-waiting），大幅減少 Flaky test
- **網路攔截**：可以在 E2E 測試中 mock API 回應
- **視覺快照**：原生支援截圖比較

### 5.2 Playwright 的自動等待機制

Playwright 的最大亮點是「Auto-waiting」：幾乎所有操作都會自動等待元素達到可交互狀態：

```typescript
// Playwright 自動等待 button 出現、可見、可點擊
await page.getByRole('button', { name: '提交' }).click();

// 自動等待文字出現在頁面上
await expect(page.getByText('訂單已建立')).toBeVisible();

// 不需要手動 sleep 或 waitForSelector
```

這讓 Playwright 的測試比 Selenium 穩定得多，大幅減少因為 timing 導致的 Flaky test。

### 5.3 Playwright 的測試組織

```typescript
// tests/checkout.spec.ts
import { test, expect } from '@playwright/test';

test.describe('結帳流程', () => {
  test.beforeEach(async ({ page }) => {
    // 登入（使用 API 直接設定 session，比 UI 登入快）
    await page.goto('/login');
    await page.getByLabel('電子郵件').fill('test@example.com');
    await page.getByLabel('密碼').fill('password');
    await page.getByRole('button', { name: '登入' }).click();
    await page.waitForURL('/dashboard');
  });

  test('成功完成結帳', async ({ page }) => {
    // 加入購物車
    await page.goto('/products/123');
    await page.getByRole('button', { name: '加入購物車' }).click();

    // 進行結帳
    await page.goto('/cart');
    await page.getByRole('button', { name: '結帳' }).click();

    // 填寫付款資訊
    await page.getByLabel('信用卡號').fill('4111111111111111');
    await page.getByLabel('到期日').fill('12/25');
    await page.getByLabel('CVV').fill('123');

    // 送出訂單
    await page.getByRole('button', { name: '確認付款' }).click();

    // 確認結果
    await expect(page.getByText('訂單已建立')).toBeVisible();
    await expect(page.getByText('訂單編號')).toBeVisible();
  });

  test('付款失敗時顯示適當錯誤', async ({ page }) => {
    // 使用 Playwright 攔截網路請求，模擬付款失敗
    await page.route('/api/payments', async route => {
      await route.fulfill({
        status: 402,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'payment_declined' }),
      });
    });

    // ... 執行結帳流程 ...

    await expect(page.getByRole('alert')).toContainText('付款被拒絕');
  });
});
```

### 5.4 Page Object Model（POM）

在大型 E2E 測試套件中，把頁面操作封裝成 Page Object，提高可維護性：

```typescript
// tests/pages/CheckoutPage.ts
import { type Page, type Locator, expect } from '@playwright/test';

export class CheckoutPage {
  readonly page: Page;
  readonly cardNumberInput: Locator;
  readonly submitButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cardNumberInput = page.getByLabel('信用卡號');
    this.submitButton = page.getByRole('button', { name: '確認付款' });
  }

  async goto() {
    await this.page.goto('/checkout');
  }

  async fillPaymentDetails(cardNumber: string, expiry: string, cvv: string) {
    await this.cardNumberInput.fill(cardNumber);
    await this.page.getByLabel('到期日').fill(expiry);
    await this.page.getByLabel('CVV').fill(cvv);
  }

  async submit() {
    await this.submitButton.click();
    // 等待導航到確認頁
    await this.page.waitForURL('/order-confirmation/**');
  }
}

// 在測試中使用
test('成功結帳', async ({ page }) => {
  const checkoutPage = new CheckoutPage(page);
  await checkoutPage.goto();
  await checkoutPage.fillPaymentDetails('4111111111111111', '12/25', '123');
  await checkoutPage.submit();
  await expect(page.getByText('訂單已建立')).toBeVisible();
});
```

### 5.5 E2E 測試的策略

**E2E 測試應該覆蓋**：
- 最關鍵的使用者旅程（結帳、登入、核心業務流程）
- 需要跨多個頁面的流程
- 依賴真實瀏覽器行為的場景（cookie、localStorage、OAuth）

**E2E 測試不應該覆蓋**：
- 每一個 UI 元件的每一個狀態（用 Testing Library 做）
- 純粹的業務邏輯（用 unit test 做）
- 所有可能的錯誤情境（用 integration test + MSW mock 做）

**E2E 測試的維護成本**：E2E 測試是最脆弱的，任何 UI 改動都可能讓它失敗。控制 E2E 測試的數量，只保留真正需要 E2E 覆蓋的核心流程。

---

## 六、視覺回歸測試

### 6.1 什麼時候需要視覺回歸測試

視覺回歸測試透過比較截圖來偵測意外的 UI 變化。不是所有專案都需要，適合的場景：

- 有設計系統，需要確保元件視覺一致性
- 有大量 CSS 動畫或複雜樣式
- 曾經發生過視覺回歸問題且難以被功能測試捕捉

**工具選擇**：
- **Playwright 內建截圖比較**：適合 E2E 層的視覺回歸
- **Storybook + Chromatic**：元件層的視覺回歸，每個 Story 都有截圖，PR 時自動比較
- **Percy**：獨立的視覺回歸服務，與多種測試框架整合

### 6.2 避免視覺回歸測試的常見陷阱

**動態內容的問題**：日期、時間、隨機 ID 在截圖中每次都不同，導致截圖比較永遠失敗。解法：在測試中 mock 時間（`vi.useFakeTimers()`），或在截圖前隱藏動態內容。

**字型渲染差異**：不同 OS 的字型渲染略有不同，讓跨平台的截圖比較困難。使用 Docker 容器在一致的環境中執行截圖。

---

## 七、前端測試策略的整體框架

### 7.1 前端的測試金字塔重新詮釋

在前端，Testing Trophy 比傳統金字塔更適用：

```
         /E2E\          少量（5-10 個核心旅程）
        /------\
       / Integ  \       主力（Testing Library + MSW）
      /----------\
     /    Unit    \     適量（hooks、純函式、工具函式）
    /--------------\
   /  Static Types  \   基礎（TypeScript、ESLint）
```

**Static（靜態分析）**：TypeScript + ESLint 是最便宜的「測試」，在編輯器就能捕捉錯誤，應該是所有前端專案的基礎。

**Unit Tests**：針對沒有 UI 的純邏輯：自定義 hook 的邏輯、工具函式、資料轉換函式、狀態管理的 reducer。

**Integration Tests（Testing Library + MSW）**：這是前端測試的主力。測試使用者可以做什麼，而不是元件內部如何工作。包含 API 呼叫（用 MSW mock），但在 jsdom 環境中執行（快速）。

**E2E Tests（Playwright）**：只覆蓋最關鍵的使用者旅程，數量要嚴格控制。

### 7.2 測試的可維護性原則

**測試命名應該描述行為，不是實作**：

```typescript
// 描述實作（不好）
it('renders UserCard component with props')
it('calls setIsOpen when button is clicked')

// 描述行為（好）
it('顯示使用者的名稱和電子郵件')
it('點擊編輯按鈕後顯示編輯表單')
```

**一個測試只驗證一個行為**：如果測試失敗，應該立刻知道哪個行為壞了。一個測試驗證太多東西，失敗時難以定位問題。

**測試應該是獨立的**：每個測試不依賴其他測試的狀態，可以任意順序執行。MSW 的 `resetHandlers()` 和 Testing Library 的自動 `cleanup()` 確保測試間的狀態不互相影響。

**避免 `act()` 警告**：React Testing Library 的 `act()` 警告通常意味著有非同步的狀態更新沒有被正確等待。用 `findBy` 查詢或 `waitFor` 解決，不要用手動的 `act()` 包裝。

### 7.3 CI 中的前端測試策略

```yaml
# .github/workflows/test.yml（概念性）
jobs:
  unit-integration:
    # 快速、可以在 PR 每次 commit 時執行
    runs-on: ubuntu-latest
    steps:
      - run: pnpm test --reporter=verbose

  e2e:
    # 較慢，可以只在 PR merge 到 main 前執行，或每日執行
    runs-on: ubuntu-latest
    steps:
      - run: pnpm playwright test --shard=1/3  # 分片並行執行

  visual-regression:
    # 最慢，可以只在 PR 時執行（需要視覺回歸工具的支援）
    runs-on: ubuntu-latest
    steps:
      - run: pnpm chromatic
```

**分片執行（Sharding）**：Playwright 支援把測試分成多份，在多個 CI 機器並行執行，大幅縮短 E2E 測試的時間：

```bash
# 在 3 台機器上分別執行 1/3 的測試
playwright test --shard=1/3
playwright test --shard=2/3
playwright test --shard=3/3
```

### 7.4 資深工程師的前端測試信條

**信心是目標，不是覆蓋率**：測試的終極目的是讓你有信心部署到生產環境。覆蓋率是副產品，不是目標。高覆蓋率的低品質測試不如低覆蓋率的高品質測試。

**測試替代品**：TypeScript 可以替代很多「這個函式的參數型別正確嗎」類型的測試；ESLint 可以替代「這個模式是不是反模式」的測試；設計系統和 Storybook 可以替代很多 UI 元件的測試。不是所有驗證都需要用測試完成。

**讓測試好維護的最佳方式**：設計好的元件。高度耦合、職責不清的元件難以測試，往往意味著需要複雜的 setup 和大量的 mock。如果你發現一個元件很難測試，先問：「這個元件的設計是否有問題？」，而不是「如何讓這個難測試的元件被測試到」。
