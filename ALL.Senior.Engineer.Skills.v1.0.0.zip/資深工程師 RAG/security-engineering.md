# Security Engineering — 資深工程師技能指南

> 本文件記錄資深工程師對安全工程的思維框架：安全不是一個功能，而是系統設計的基礎屬性。資深工程師的安全意識不是記住所有漏洞的技術細節，而是理解攻擊者的思維模式，並在設計和開發的每個環節都考慮安全性。

---

## 一、安全工程的根本態度

**安全是設計問題，不是補丁問題**

最常見的安全失敗模式：系統設計和開發時不考慮安全，上線後出了漏洞才打補丁。這種「補丁思維」的根本問題是：在錯誤的時機、以錯誤的方式處理安全問題，成本極高且效果有限。

安全設計的正確時機是在架構設計和 API 設計階段，而不是在功能完成後。

**攻擊者思維（Adversarial Thinking）**

資深工程師看自己的系統時，要同時扮演兩個角色：設計者和攻擊者。

對每個功能問自己：
- 如果我是攻擊者，我會如何濫用這個功能？
- 哪些輸入是我沒有預期的？攻擊者會嘗試什麼？
- 如果這個元件被攻破，攻擊者能夠到達哪裡？

**縱深防禦（Defense in Depth）**

不依賴單一的安全機制。每一層都有可能失效，設計多層防禦讓單一層的失效不會導致系統被完全攻破：

```
外層：網路層（WAF、DDoS 防護、IP 過濾）
  中層：應用層（輸入驗證、認證授權、加密）
    內層：資料層（最小權限、資料加密、審計日誌）
      核心：監控和告警（異常行為偵測）
```

**安全的最小化原則（Principle of Least Privilege）**

每個元件、每個使用者、每個服務，都只應該有完成其工作所需的最小權限。超出需要的權限是安全風險的放大器：一旦被攻破，攻擊者能做的事情就是被攻破的元件能做的事情。

---

## 二、OWASP Top 10 的深度理解

OWASP（Open Web Application Security Project）的 Top 10 是 Web 應用最常見的安全風險。資深工程師不只要知道這些漏洞是什麼，更要理解為什麼會出現，以及如何從根本上預防。

### 2.1 Injection（注入攻擊）

**SQL Injection** 是最古老也最持久的漏洞之一。核心原因是：把不受信任的資料和程式碼指令混在一起。

```sql
-- 危險：直接拼接用戶輸入
query = "SELECT * FROM users WHERE name = '" + user_input + "'"
-- 如果 user_input 是 "'; DROP TABLE users; --"，後果嚴重

-- 安全：Parameterized Query
query = "SELECT * FROM users WHERE name = ?"
execute(query, [user_input])
```

SQL Injection 的根本防禦是**永遠不信任外部輸入，永遠使用 Parameterized Query 或 ORM**。這不是特殊情況的處理，而是所有資料庫操作的基本方式。

**Command Injection**：把用戶輸入當作 Shell 命令執行。原則：永遠不要直接把用戶輸入傳給 Shell，使用程式語言的 API 而不是 Shell 命令。

**LDAP / XML / NoSQL Injection**：注入攻擊的模式是相同的，只是目標系統不同。根本原則不變：不信任輸入，使用結構化的 API 而不是字串拼接。

### 2.2 Broken Authentication（認證漏洞）

認證是「你是誰」的問題，認證漏洞讓攻擊者能夠冒充合法用戶。

**常見問題**：
- 弱密碼政策，允許容易猜測的密碼
- 沒有限制登入嘗試次數，允許暴力破解
- 密碼以明文或弱雜湊（MD5、SHA1）儲存
- Session Token 可被預測或在不安全的地方傳輸
- 密碼重設流程有漏洞（如可預測的 token、沒有過期時間）

**密碼儲存的正確方式**：永遠使用專門為密碼設計的雜湊演算法：**bcrypt、scrypt、Argon2**。這些演算法故意設計得「慢」，讓暴力破解的成本極高。MD5 和 SHA1 不應該用於密碼，它們太快了。

**不要自己實作認證系統**：認證系統的細節非常容易出錯，使用成熟的認證庫（Passport.js、Devise、Spring Security）或 Identity Provider（Auth0、Okta、Cognito）。

### 2.3 Broken Access Control（存取控制漏洞）

認證（Authentication）回答「你是誰」，授權（Authorization）回答「你可以做什麼」。存取控制漏洞是授權邏輯的失效。

**IDOR（Insecure Direct Object Reference，不安全的直接物件參考）** 是最常見的存取控制漏洞：

```
# 危險：直接用 URL 中的 id 查詢，沒有驗證權限
GET /api/orders/12345

# 攻擊者只需要改數字，就能存取其他用戶的訂單
GET /api/orders/12346
```

防禦原則：**每次存取資源前，都要驗證當前使用者是否有權限存取這個特定資源**，不只驗證使用者已登入。

**使用不可猜測的 ID**：把資料庫的序列 ID（1, 2, 3...）直接暴露在 URL 中，讓攻擊者可以系統性地遍歷。使用 UUID 或其他不可猜測的識別符，讓遍歷變得不可行。

**垂直權限提升 vs 水平權限提升**：
- 水平：普通用戶存取其他普通用戶的資源（IDOR）
- 垂直：普通用戶存取管理員才能存取的功能

兩者都需要防禦。

### 2.4 Cryptographic Failures（密碼學失誤）

不是說密碼學演算法本身有問題，而是開發者在使用密碼學工具時常見的錯誤。

**敏感資料的識別**：哪些資料需要加密保護？
- 密碼（永遠不能儲存明文，要雜湊）
- 信用卡號、銀行帳號
- 個人識別資訊（身分證號、護照號）
- 健康資料
- Session Token、API Key

**傳輸中的加密**：所有網路通訊都必須使用 TLS 1.2 或更高版本。HTTP 在現代已經不可接受，即使是內部服務間的通訊也應該使用 TLS（Zero Trust 網路模型）。

**靜態資料的加密**：敏感欄位要在資料庫中加密儲存，即使資料庫本身被攻破，也無法直接讀取敏感資料。

**常見的密碼學錯誤**：
- 使用已知不安全的演算法（MD5、SHA1、DES、RC4）
- 硬編碼加密金鑰（出現在程式碼中）
- 使用可預測的隨機數（不使用 Cryptographically Secure Random Number Generator）
- ECB 加密模式（相同的明文塊產生相同的密文塊，會洩漏明文模式）

### 2.5 Security Misconfiguration（安全設定錯誤）

這是最廣泛的類別，涵蓋所有因為設定不當而產生的漏洞：

- 預設密碼沒有修改（路由器、資料庫、admin 介面）
- 不必要的功能或服務沒有關閉（暴露了不需要的攻擊面）
- 錯誤訊息包含過多細節（洩漏內部架構、stack trace）
- 雲端儲存設定錯誤（S3 bucket 設成 public）
- 生產環境啟用了 debug 模式
- 安全 header 缺失（CSP、HSTS、X-Frame-Options）

**Cloud Security 的特別挑戰**：雲端環境的設定錯誤尤其危險，因為一個設定錯誤可能暴露大量資源。IAM 設定（過於寬鬆的 policy）、S3 bucket 設定、安全群組設定都是高風險點。Infrastructure as Code 讓設定有版本控制和 review，是降低設定錯誤風險的有效方式。

### 2.6 Vulnerable and Outdated Components（使用有漏洞的元件）

現代軟體大量依賴第三方程式庫，這些程式庫本身可能有安全漏洞。

**管理策略**：
- 定期更新依賴（Dependabot 等工具可以自動化這個過程）
- 在 CI 中整合漏洞掃描（Snyk、npm audit、Safety for Python）
- 了解你的依賴樹（直接依賴和間接依賴）

**依賴的攻擊面**：不只是依賴本身的漏洞，還有供應鏈攻擊（Supply Chain Attack）——攻擊者在合法的開源套件中注入惡意程式碼（如 2021 年的 ua-parser-js 事件）。

### 2.7 Identification and Authentication Failures

（見 2.2，此處補充進階面向）

**Multi-Factor Authentication（MFA）**：對高風險操作（登入、資金操作、帳戶設定變更），要求 MFA。即使密碼洩漏，攻擊者也需要第二因素。

**Session 管理**：
- Session Token 要夠隨機（至少 128 bits 的熵）
- 要有合理的 Session 過期時間
- 登出時要真正使 Token 失效（不只是清除 Cookie）
- 避免 Session Fixation 攻擊（在認證成功後輪換 Session ID）

### 2.8 Software and Data Integrity Failures

確保軟體和資料在整個生命週期中沒有被篡改：

- 驗證下載的軟體或更新的完整性（Checksum、數位簽章）
- CI/CD Pipeline 的完整性（避免在 Pipeline 中注入惡意程式碼）
- 反序列化的安全（不信任的來源的序列化資料可能包含惡意 payload）

### 2.9 Security Logging and Monitoring Failures

安全事件的 logging 是不可或缺的：

- 所有認證事件（成功和失敗）
- 所有授權失敗（存取被拒絕）
- 高風險操作（資金操作、管理員操作、大量資料存取）
- 輸入驗證失敗

沒有這些 log，安全事故發生後無法追蹤攻擊者的行為，也無法確認影響範圍。

### 2.10 Server-Side Request Forgery（SSRF）

攻擊者讓伺服器代替他們發出請求，存取伺服器可以存取但攻擊者無法直接存取的資源（如內部服務、雲端 metadata API）。

```
# 攻擊者提供惡意的 URL
POST /api/fetch-url
{"url": "http://169.254.169.254/latest/meta-data/iam/credentials"}
# 如果伺服器直接 fetch 這個 URL，可以拿到雲端的 IAM credentials
```

防禦：驗證和過濾目標 URL（白名單而不是黑名單）、限制伺服器能夠存取的網路範圍。

---

## 三、認證與授權的設計

### 3.1 JWT 的正確使用

JWT（JSON Web Token）是現代 API 認證的主流方式，但也是最常被誤用的認證機制之一。

**JWT 的工作原理**：Token 包含三部分（Header、Payload、Signature），Signature 由伺服器的私鑰簽署，讓伺服器可以驗證 Token 的真實性，而不需要查詢資料庫。

**常見的 JWT 誤用**：

- **存放敏感資訊在 Payload**：JWT 的 Payload 只是 Base64 編碼，不是加密，任何人都可以解碼看到 Payload 的內容。不要在 JWT 中放密碼、個資等敏感資訊

- **Algorithm Confusion 攻擊**：如果伺服器不驗證 JWT 的 algorithm，攻擊者可以把 Algorithm 改成 `none` 或把非對稱演算法換成對稱演算法。永遠明確指定並驗證使用的演算法

- **沒有過期時間（exp）**：JWT 洩漏後，如果沒有過期時間，攻擊者可以永遠使用。JWT 必須有 `exp` claim，且過期時間要合理（Access Token：15 分鐘到 1 小時）

- **無法撤銷（Revocation）問題**：JWT 是 stateless 的，伺服器無法主動使一個還沒過期的 JWT 失效（除非維護一個黑名單，但那就失去了 stateless 的優勢）。解法：短的 Access Token 過期時間 + Refresh Token（可以被撤銷）

### 3.2 OAuth 2.0 的核心概念

OAuth 2.0 是授權框架（不是認證），用於讓第三方應用代表用戶存取資源，而不需要把用戶的密碼交給第三方應用。

**核心角色**：
- Resource Owner（用戶）：擁有資源的人
- Client（第三方應用）：想要存取資源的應用
- Authorization Server：驗證用戶身分並發放 Token
- Resource Server：保存資源的伺服器

**Authorization Code Flow**（最安全，Web 應用標準）：
1. Client 把用戶導向 Authorization Server
2. 用戶登入並同意授權
3. Authorization Server 返回 Authorization Code 給 Client
4. Client 用 Authorization Code 換取 Access Token（這一步在後端進行，Access Token 不暴露給瀏覽器）

**PKCE（Proof Key for Code Exchange）**：對於沒有後端的 SPA 或行動應用，使用 PKCE 擴展來防止 Authorization Code 被截取。

**不要使用 Implicit Flow**：在 OAuth 2.0 中，Implicit Flow 把 Access Token 直接暴露在 URL 中，已被廢棄，不應再使用。

### 3.3 RBAC vs ABAC

**RBAC（Role-Based Access Control，基於角色的存取控制）**：用戶被分配角色，角色有對應的權限。簡單直觀，適合大多數應用。

```
User → Role (Admin, Editor, Viewer) → Permissions
```

**ABAC（Attribute-Based Access Control，基於屬性的存取控制）**：根據用戶的屬性、資源的屬性、環境屬性做出存取決策。更靈活，但更複雜。

```
User (department=HR, level=Manager) + Resource (owner=HR) 
+ Environment (time=business_hours) → Allow
```

**選擇原則**：從 RBAC 開始，當 RBAC 無法表達所需的細粒度權限時，再考慮 ABAC。

---

## 四、常見 Web 攻擊的防禦

### 4.1 XSS（Cross-Site Scripting，跨站腳本攻擊）

攻擊者把惡意的 JavaScript 注入到網頁中，在其他用戶的瀏覽器中執行。

**三種類型**：
- **Stored XSS**：惡意腳本儲存在資料庫中（如在留言板中注入 script），每個查看該內容的用戶都受影響
- **Reflected XSS**：惡意腳本在 URL 中，透過社交工程讓用戶點擊惡意連結
- **DOM-based XSS**：惡意腳本直接操作 DOM，完全在客戶端執行

**防禦策略**：
- **輸出編碼（Output Encoding）**：把所有用戶提供的內容在顯示到 HTML 時進行編碼（`<` → `&lt;`）。現代前端框架（React、Vue）預設做了這件事，但 `dangerouslySetInnerHTML`（React）等接口要特別小心
- **Content Security Policy（CSP）**：透過 HTTP Header 限制頁面可以執行的腳本來源，即使 XSS 成功注入，也無法執行外部腳本
- **HttpOnly Cookie**：Session Cookie 設置 `HttpOnly` flag，讓 JavaScript 無法存取，即使 XSS 成功也無法竊取 Session

### 4.2 CSRF（Cross-Site Request Forgery，跨站請求偽造）

攻擊者讓已登入的用戶在不知情的情況下，向目標網站發出惡意請求（如轉帳、修改密碼）。

**攻擊原理**：瀏覽器在發出請求時會自動附上該域名的 Cookie，所以攻擊者只需要讓用戶的瀏覽器發出請求，Cookie 會自動附上，伺服器無法區分是用戶主動操作還是被誘導。

**防禦策略**：
- **CSRF Token**：在每個需要保護的表單或 API 中加入一個隨機的 token，伺服器驗證這個 token。攻擊者無法知道這個 token 的值（Same-Origin Policy 讓攻擊者無法讀取其他域名的頁面內容）
- **SameSite Cookie**：設置 Cookie 的 `SameSite=Strict` 或 `SameSite=Lax` attribute，讓跨站請求不帶上 Cookie
- **驗證 Origin / Referer Header**：對狀態修改的請求，驗證請求來源是否來自允許的域名

### 4.3 Rate Limiting 和暴力破解防禦

限制單個 IP 或用戶在一段時間內的請求次數，防禦：
- 登入暴力破解
- API 濫用
- DDoS 攻擊（Layer 7）
- 憑證填充攻擊（Credential Stuffing）

**實作考量**：
- 在哪一層做 Rate Limiting？（應用層、API Gateway、CDN）
- 按什麼維度限制？（IP、用戶 ID、API Key、端點）
- 超過限制的響應：429 Too Many Requests + `Retry-After` header
- 對敏感端點（登入、密碼重設）要特別嚴格

---

## 五、安全開發生命週期（Secure SDLC）

安全應該融入開發流程的每個階段，而不是在最後才做安全審查：

**設計階段**：Threat Modeling（威脅建模）——系統性地識別可能的攻擊向量和安全風險，在設計時就考慮如何緩解

**開發階段**：安全編碼標準、Code Review 的安全 checklist、IDE 的安全分析插件

**測試階段**：
- SAST（Static Application Security Testing）：靜態程式碼分析，在 CI 中自動執行（Semgrep、CodeQL、Bandit for Python）
- DAST（Dynamic Application Security Testing）：對運行中的應用進行動態掃描（OWASP ZAP、Burp Suite）
- 依賴漏洞掃描（Snyk、npm audit）
- Penetration Testing：定期聘請安全專家做滲透測試

**部署階段**：Container Image 掃描、基礎設施設定合規掃描

**運行階段**：WAF（Web Application Firewall）、SIEM（Security Information and Event Management）、異常行為偵測

### 5.1 Threat Modeling（威脅建模）

STRIDE 是最常用的威脅建模框架，對每個系統元件評估六種威脅類型：

| 威脅 | 說明 | 對應的安全屬性 |
|------|------|--------------|
| Spoofing（偽冒）| 假冒合法用戶或系統 | Authentication |
| Tampering（竄改）| 修改資料或通訊 | Integrity |
| Repudiation（否認）| 否認自己的操作 | Non-repudiation |
| Information Disclosure（資訊洩漏）| 暴露敏感資訊 | Confidentiality |
| Denial of Service（阻斷服務）| 讓系統無法使用 | Availability |
| Elevation of Privilege（權限提升）| 取得超出授權的權限 | Authorization |

---

## 六、資深工程師的安全心智模型

**永遠不信任輸入**：任何來自系統外部的資料——用戶輸入、API 回應、資料庫資料、環境變數——都不能被盲目信任。驗證、清理、編碼是處理外部輸入的標準流程。

**明確勝於隱晦（Explicit over Obscurity）**：安全設計不依賴攻擊者不知道系統的工作方式（Security by Obscurity）。假設攻擊者知道你所有的設計細節，系統仍然應該是安全的。

**Fail Securely（安全地失敗）**：當錯誤發生時，系統應該默認拒絕存取，而不是默認允許。例如：權限檢查的程式碼拋出 exception，應該默認為「沒有權限」而不是「有權限」。

**減少攻擊面（Minimize Attack Surface）**：關閉不需要的功能、端口、服務。每一個暴露的功能都是潛在的攻擊向量。越簡單的系統，攻擊面越小。

**安全是全團隊的責任**：安全不是安全工程師的專屬責任，是每個工程師在每次 PR、每次設計決策中都需要考慮的維度。資深工程師要在 Code Review 中把安全意識傳遞給整個團隊。
