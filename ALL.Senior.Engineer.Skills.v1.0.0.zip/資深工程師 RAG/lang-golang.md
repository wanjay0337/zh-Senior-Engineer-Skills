# Go（Golang）— 資深工程師技能指南

> 本文件記錄資深工程師對 Go 語言的深度理解：不在於語法細節，而在於 Go 的設計哲學、並發模型的本質、錯誤處理的工程思維，以及 Go 在什麼場景下是最佳選擇、在什麼場景下不是。

---

## 一、Go 的設計哲學

Go 是一門刻意保持簡單的語言。這個「簡單」不是說 Go 容易學，而是說 Go 的設計者在每個功能點上都做出了「少即是多」的選擇。

**為什麼 Go 選擇簡單**

Go 誕生於 Google，設計者（Rob Pike、Ken Thompson、Robert Griesemer）面對的問題是：在數千名工程師的大型工程組織中，如何讓程式碼保持可讀、可維護、可大規模協作。

他們的答案是：**語言越簡單，大型組織的代碼庫越一致**。當語言只有一種方式做一件事，不同工程師寫的程式碼風格自然趨近一致，降低了認知負擔。

**Go 刻意不支援的特性**

- **泛型（長期缺失）**：直到 Go 1.18 才引入，且設計保守，有意限制表達能力
- **繼承（Inheritance）**：Go 沒有繼承，只有組合（Composition）
- **例外（Exception）**：Go 用多返回值處理錯誤，不用 try/catch
- **隱式型別轉換**：型別轉換必須明確，沒有自動轉換
- **運算子重載（Operator Overloading）**

這些缺失不是疏忽，而是刻意的設計選擇。每個被拒絕的特性背後，都有「這個特性讓程式碼更難讀、更難維護」的考量。

**Go 的核心價值觀**：可讀性、簡單性、明確性、效能。當這些價值觀衝突時，可讀性通常勝出。

---

## 二、並發模型：Goroutine 與 Channel

Go 的並發模型是它最具特色的部分，也是它在後端服務領域如此流行的核心原因。

### 2.1 Goroutine 的本質

Goroutine 不是 OS Thread，而是 Go Runtime 管理的輕量級執行單元。

**Goroutine vs Thread 的關鍵差異**：

| | OS Thread | Goroutine |
|--|-----------|-----------|
| 建立成本 | ~1MB stack，建立耗時 | ~2KB 初始 stack，建立極快 |
| 調度 | OS 調度（preemptive） | Go Runtime 調度（M:N 調度） |
| 切換成本 | 高（kernel mode 切換） | 低（user space 切換） |
| 數量上限 | 數千個（記憶體限制） | 數十萬甚至百萬個 |

**M:N 調度模型**：Go Runtime 把 M 個 Goroutine 映射到 N 個 OS Thread 上執行。當一個 Goroutine 阻塞（等待 I/O、channel、syscall），調度器會把其他 Goroutine 放到這個 Thread 上繼續執行，避免 Thread 空轉等待。

這讓 Go 可以用極少的 OS Thread，高效地處理大量並發的 I/O-bound 工作。

### 2.2 Channel 的設計哲學

Go 的並發格言：**"Do not communicate by sharing memory; instead, share memory by communicating."**

Channel 是 Goroutine 之間安全傳遞資料的管道，也是 Go 並發模型的核心機制。

```go
// 無緩衝 Channel：發送方和接收方必須同時準備好（同步）
ch := make(chan int)

// 有緩衝 Channel：可以存放 n 個值，未滿時發送不阻塞
bufferedCh := make(chan int, 10)
```

**無緩衝 Channel 的語意**：發送和接收是同步的。發送方在有人接收之前會阻塞，接收方在有人發送之前會阻塞。這提供了嚴格的同步保證，適合需要確認另一端已經收到訊息的場景。

**有緩衝 Channel 的語意**：提供有限的解耦。發送方可以繼續執行，直到緩衝區滿了才阻塞。常用於 Producer-Consumer 模式中的佇列。

**Channel 方向性**：Go 的型別系統允許限制 Channel 的使用方向，提升 API 的安全性和表達力：

```go
// 只能發送的 Channel（send-only）
func produce(ch chan<- int) {
    ch <- 42
}

// 只能接收的 Channel（receive-only）
func consume(ch <-chan int) {
    val := <-ch
}
```

### 2.3 並發模式

**Fan-out / Fan-in**：

```go
// Fan-out：把工作分發給多個 worker
func fanOut(jobs <-chan Job, numWorkers int) []<-chan Result {
    results := make([]<-chan Result, numWorkers)
    for i := 0; i < numWorkers; i++ {
        results[i] = worker(jobs)
    }
    return results
}

// Fan-in：把多個 channel 的結果合併成一個
func fanIn(channels ...<-chan Result) <-chan Result {
    merged := make(chan Result)
    var wg sync.WaitGroup
    
    for _, ch := range channels {
        wg.Add(1)
        go func(c <-chan Result) {
            defer wg.Done()
            for result := range c {
                merged <- result
            }
        }(ch)
    }
    
    go func() {
        wg.Wait()
        close(merged)
    }()
    
    return merged
}
```

**Pipeline 模式**：把資料處理分成多個階段，每個階段是一個 Goroutine，透過 Channel 連接：

```go
func pipeline() {
    // Stage 1: 生成數字
    naturals := generate(1, 2, 3, 4, 5)
    // Stage 2: 平方
    squares := square(naturals)
    // Stage 3: 過濾偶數
    evens := filter(squares, func(n int) bool { return n%2 == 0 })
    
    for n := range evens {
        fmt.Println(n)
    }
}
```

**Context 的取消傳遞**：

```go
func fetchWithTimeout(ctx context.Context, url string) ([]byte, error) {
    req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
    if err != nil {
        return nil, err
    }
    
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err  // context 取消時，err 會是 context.Canceled
    }
    defer resp.Body.Close()
    
    return io.ReadAll(resp.Body)
}

// 呼叫端：帶 timeout 的 context
ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
defer cancel()  // 必須呼叫 cancel，避免 resource leak

data, err := fetchWithTimeout(ctx, "https://api.example.com")
```

`context.Context` 是 Go 的取消信號和 deadline 傳遞機制。它應該是每個需要取消能力的函式的第一個參數，這是 Go 的慣例。

### 2.4 Goroutine Leak（Goroutine 洩漏）

Goroutine 洩漏是 Go 程式中最常見的資源洩漏形式：Goroutine 啟動了但永遠無法結束（永遠阻塞在 channel 操作、等待永遠不會完成的工作），導致記憶體和相關資源無法釋放。

**常見原因**：

```go
// 洩漏：channel 沒有人接收，goroutine 永遠阻塞
func leak() {
    ch := make(chan int)
    go func() {
        ch <- 1  // 如果沒有人接收這個值，goroutine 永遠在這裡等待
    }()
    // 函式返回，但 goroutine 還在
}

// 修復：確保有人接收，或用 select + context 提供退出機制
func noLeak(ctx context.Context) {
    ch := make(chan int, 1)  // 有緩衝，不會阻塞發送
    go func() {
        select {
        case ch <- 1:
        case <-ctx.Done():  // context 取消時，goroutine 退出
        }
    }()
}
```

**Goroutine 洩漏的偵測**：`runtime.NumGoroutine()` 可以查看當前 Goroutine 數量。在測試中使用 `goleak` 套件可以自動偵測洩漏。

---

## 三、記憶體模型

### 3.1 Go 的記憶體模型基礎

Go 的記憶體模型定義了在多個 Goroutine 中，什麼時候一個 Goroutine 的寫入對另一個 Goroutine 可見。

核心原則：**如果沒有明確的同步機制（channel 操作、sync 套件、atomic 操作），不同 Goroutine 的記憶體操作沒有確定的順序**。

這意味著在沒有同步的情況下，讀取另一個 Goroutine 寫入的變數，可能看到舊值、新值、或中間狀態——行為是未定義的。

### 3.2 Happens-Before 關係

Go 記憶體模型用 Happens-Before 定義同步語意：如果操作 A happens-before 操作 B，那麼 B 可以看到 A 的所有寫入。

建立 Happens-Before 的機制：
- **Channel 操作**：對 channel 的發送 happens-before 對應的接收完成
- **sync.Mutex**：`Unlock()` happens-before 下一個 `Lock()`
- **sync.WaitGroup**：`Done()` happens-before `Wait()` 返回
- **sync/atomic**：原子操作提供特定的記憶體順序保證

### 3.3 Race Condition 的偵測

Go 提供了內建的 Race Detector，在測試和開發時使用：

```bash
go test -race ./...
go run -race main.go
```

Race Detector 會在執行時偵測資料競爭，找到問題後立即報告並終止程式。它有 5-10 倍的效能開銷，只適合在測試和開發時使用，不適合生產環境。

**資深工程師的判斷**：`go test -race` 應該是 CI Pipeline 的標配，不是可選項。

### 3.4 sync 套件的正確使用

**sync.Mutex vs sync.RWMutex**：

```go
type SafeCounter struct {
    mu    sync.RWMutex
    count map[string]int
}

// 讀操作：多個 goroutine 可以同時持有 RLock
func (c *SafeCounter) Get(key string) int {
    c.mu.RLock()
    defer c.mu.RUnlock()
    return c.count[key]
}

// 寫操作：只有一個 goroutine 可以持有 Lock
func (c *SafeCounter) Inc(key string) {
    c.mu.Lock()
    defer c.mu.Unlock()
    c.count[key]++
}
```

**sync.Once**：確保某個操作只執行一次（如 Singleton 初始化）：

```go
var (
    instance *Database
    once     sync.Once
)

func GetDatabase() *Database {
    once.Do(func() {
        instance = newDatabase()
    })
    return instance
}
```

**sync.Pool**：用於重用昂貴的物件（如 bytes.Buffer），避免頻繁的 GC 壓力：

```go
var bufPool = sync.Pool{
    New: func() interface{} {
        return new(bytes.Buffer)
    },
}

func process() {
    buf := bufPool.Get().(*bytes.Buffer)
    defer func() {
        buf.Reset()
        bufPool.Put(buf)
    }()
    // 使用 buf...
}
```

---

## 四、錯誤處理哲學

### 4.1 錯誤是值（Errors are Values）

Go 的錯誤處理方式是業界爭議最多的特性。Go 的立場是：**錯誤是普通的值，不是例外控制流**。

```go
// Go 的錯誤處理模式
result, err := doSomething()
if err != nil {
    return nil, fmt.Errorf("doSomething failed: %w", err)
}
```

這種模式的優勢：
- **明確**：每個可能失敗的操作，調用方被強制處理錯誤
- **可預測**：錯誤處理是普通的程式碼，不是隱藏的控制流
- **可組合**：錯誤可以被包裝、傳遞、檢查

這種模式的問題：
- **冗長**：大量的 `if err != nil` 讓程式碼的主邏輯被錯誤處理稀釋
- **容易忽略**：`_` 可以丟棄返回的 error，但這通常是 bug

### 4.2 錯誤包裝與解包（Go 1.13+）

```go
// %w：包裝錯誤，保留原始錯誤鏈
return fmt.Errorf("failed to process order %s: %w", orderID, err)

// errors.Is：檢查錯誤鏈中是否有特定錯誤
if errors.Is(err, sql.ErrNoRows) {
    return nil, ErrOrderNotFound
}

// errors.As：從錯誤鏈中提取特定型別的錯誤
var dbErr *DatabaseError
if errors.As(err, &dbErr) {
    log.Printf("Database error code: %d", dbErr.Code)
}
```

**Sentinel Error vs Error Type 的選擇**：

```go
// Sentinel Error：預定義的錯誤值，用 errors.Is 比較
var ErrNotFound = errors.New("not found")

// Error Type：自定義錯誤型別，攜帶額外資訊，用 errors.As 提取
type ValidationError struct {
    Field   string
    Message string
}
func (e *ValidationError) Error() string {
    return fmt.Sprintf("validation failed for %s: %s", e.Field, e.Message)
}
```

**選擇原則**：需要攜帶額外資訊用 Error Type；只需要識別錯誤類型用 Sentinel Error；需要兩者同時，可以讓 Error Type 包含 Sentinel Error。

### 4.3 panic 和 recover 的正確定位

**panic 不是 Go 的例外機制**。panic 應該只用於真正不可恢復的程式設計錯誤（如 nil pointer dereference、index out of bounds）。

`recover` 用於在 goroutine 崩潰前捕獲 panic，通常只在框架層（HTTP server、test runner）使用，用來防止一個請求的 panic 把整個程式拖垮：

```go
// HTTP Server 的 panic recovery middleware
func recoveryMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        defer func() {
            if err := recover(); err != nil {
                log.Printf("panic: %v\n%s", err, debug.Stack())
                http.Error(w, "Internal Server Error", 500)
            }
        }()
        next.ServeHTTP(w, r)
    })
}
```

**資深工程師的判斷**：如果你在業務邏輯中使用 panic/recover 來模擬例外處理，你在和 Go 的設計哲學對抗。這通常是設計問題的信號。

---

## 五、介面（Interface）的設計哲學

### 5.1 隱式介面實作

Go 的介面是隱式實作的：不需要宣告「我實作了這個介面」，只要有對應的方法，就自動滿足介面：

```go
type Writer interface {
    Write(p []byte) (n int, err error)
}

// File 沒有宣告實作 Writer，但只要有 Write 方法，就滿足介面
type File struct { ... }
func (f *File) Write(p []byte) (n int, err error) { ... }

var w Writer = &File{}  // 合法：File 滿足 Writer 介面
```

這讓 Go 的介面非常靈活：可以為任何型別定義介面，即使這個型別是在第三方庫中定義的。

### 5.2 介面的設計原則

**Go 的介面應該小**：標準庫中最常用的介面通常只有一到三個方法（`io.Reader`、`io.Writer`、`io.Closer`、`fmt.Stringer`）。小介面更容易實作、更容易組合、更容易 mock。

**介面應該在使用方定義，不是在實作方定義**：

```go
// 錯誤的設計：在 user 套件定義大型介面，讓使用者實作
// user/repository.go
type UserRepository interface {
    FindByID(id string) (*User, error)
    FindByEmail(email string) (*User, error)
    Save(user *User) error
    Delete(id string) error
    // ... 更多方法
}

// 正確的設計：在服務層定義只需要用到的方法
// service/user_service.go
type userFinder interface {
    FindByID(id string) (*User, error)
}

type UserService struct {
    finder userFinder
}
```

在使用方定義介面的好處：介面只包含使用方真正需要的方法，讓依賴最小化，測試時只需要 mock 需要用到的方法。

### 5.3 空介面和 any

`interface{}` 或 `any`（Go 1.18+ 的別名）接受任何值，但使用時需要型別斷言。過度使用 `any` 是放棄型別安全的信號：

```go
// 危險：過度使用 any
func process(data any) {
    if v, ok := data.(string); ok {
        // ...
    }
}

// 更好：用泛型（Go 1.18+）保留型別安全
func process[T any](data T) {
    // T 可以是任何型別，但在呼叫時是確定的
}
```

---

## 六、Go 的泛型（Go 1.18+）

### 6.1 泛型的設計保守主義

Go 的泛型設計刻意保守，只解決「沒有泛型最痛苦的問題」，而不是提供完整的型別理論。

Go 泛型的核心用途：
- 通用的資料結構（Stack、Queue、Set、Map 操作）
- 通用的演算法（排序、過濾、Map/Reduce）
- 減少重複的容器程式碼（不需要為每個型別寫一份 `Min`、`Max`）

### 6.2 Type Constraint（型別約束）

```go
// 任何數字型別的 Sum
type Number interface {
    int | int32 | int64 | float32 | float64
}

func Sum[T Number](values []T) T {
    var total T
    for _, v := range values {
        total += v
    }
    return total
}

// 使用 comparable 約束（可以用 == 比較）
func Contains[T comparable](slice []T, item T) bool {
    for _, v := range slice {
        if v == item {
            return true
        }
    }
    return false
}
```

**資深工程師的判斷**：Go 的泛型是有用的，但不是所有程式碼都需要泛型。在沒有明確需要之前，先用具體型別。過早泛化和過早抽象一樣是問題。

---

## 七、Go 的工程生態

### 7.1 工具鏈的強大

Go 的工具鏈是業界最完整的：

- **`go fmt`**：官方格式化工具，所有 Go 程式碼應該都過 `gofmt`，消除格式爭議
- **`go vet`**：靜態分析，找出常見的程式錯誤
- **`go test`**：內建測試框架，無需第三方庫
- **`go build`**：快速編譯，大型專案的增量編譯速度遠超 C++
- **`go mod`**：模組管理，自 Go 1.11 成為標準
- **`go doc`**：從程式碼生成文件

這套工具的統一性是 Go 在大型工程組織中成功的重要原因：所有工程師用同樣的工具，沒有工具鏈的意見分歧。

### 7.2 測試哲學

Go 的內建測試框架刻意保持簡單，不提供 assertion 庫（如 `assert.Equal`）。官方的哲學是：測試失敗時，工程師應該寫清楚「期望什麼、得到什麼」的訊息，而不是依賴通用的 assertion 訊息。

**Table-driven Test** 是 Go 最重要的測試模式：

```go
func TestAdd(t *testing.T) {
    tests := []struct {
        name     string
        a, b     int
        expected int
    }{
        {"positive numbers", 1, 2, 3},
        {"negative numbers", -1, -2, -3},
        {"zeros", 0, 0, 0},
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            result := Add(tt.a, tt.b)
            if result != tt.expected {
                t.Errorf("Add(%d, %d) = %d, want %d", tt.a, tt.b, result, tt.expected)
            }
        })
    }
}
```

### 7.3 Go 的適用場景

**Go 的最佳適用場景**：
- 後端 API 服務和微服務（高並發、低延遲）
- CLI 工具（單一 binary、快速啟動）
- 基礎設施工具（Docker、Kubernetes、Terraform 都用 Go 寫）
- 網路服務（代理、閘道、負載均衡）
- 需要明確資源控制的系統

**Go 的限制**：
- 資料科學和機器學習（生態系遠不如 Python）
- GUI 應用（生態系薄弱）
- 需要豐富抽象的複雜業務邏輯（Go 的簡單性在這裡反而是限制）
- 底層系統程式設計（需要更細緻的記憶體控制時，Rust 更適合）

---

## 八、資深工程師對 Go 的整體判斷

**Go 的核心優勢**：簡單、快速、並發模型優秀、工具鏈統一、部署簡單（單一 binary）。這些特性讓 Go 在後端服務和基礎設施工具領域有壓倒性的優勢。

**Go 的設計哲學帶來的工程影響**：和 Go 一起工作最有效的方式，是接受它的簡單性而不是對抗它。不要試圖在 Go 中實作 Java 的 Design Pattern、Python 的 metaprogramming、或 Haskell 的型別理論。Go 的「笨」程式碼往往是最 Go 的程式碼。

**Go 在大型工程組織中的價值**：Go 最大的工程價值不是語言本身的技術特性，而是它帶來的一致性：相同的格式、相同的工具、相同的慣用方式，讓大型組織的程式碼庫比任何其他語言都更容易在工程師之間流動。
