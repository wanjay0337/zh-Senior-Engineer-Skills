# API Design — 資深工程師技能指南

> 本文件記錄資深工程師在 API 設計上的思維框架與決策哲學。API 是系統對外的契約，一旦發布就難以更改，設計品質直接影響長期的維護成本與使用者體驗。

---

## 一、API 設計的根本態度

API 是給人用的，不只是給機器用的。一個好的 API 應該讓使用者能夠**在不讀文件的情況下猜到大部分的用法**，讀了文件之後能夠完全理解，用了之後不會後悔。

資深工程師看 API 設計的核心問題：
- **這個 API 的使用者是誰？** 內部服務、外部開發者、行動客戶端，需求截然不同
- **這個 API 需要支援多久？** 對外公開的 API 一旦發布就是承諾，改動成本極高
- **這個 API 會如何演化？** 業務會變，API 設計要為演化留出空間

**API 是契約（Contract），不是實作細節**。內部實作可以隨時重構，但 API 一旦有使用者依賴，就必須維持向後相容，否則就是在破壞信任。

---

## 二、RESTful API 設計

### 2.1 REST 的本質

REST（Representational State Transfer）是一種架構風格，核心概念是：
- **資源（Resource）**：系統中的每個概念都是資源，有唯一的 URL 識別
- **統一介面（Uniform Interface）**：用 HTTP 動詞（GET、POST、PUT、PATCH、DELETE）表達對資源的操作
- **無狀態（Stateless）**：每個請求都包含所有必要資訊，伺服器不儲存客戶端狀態

很多人以為「用 HTTP 就是 RESTful」，但真正的 REST 有嚴格定義。實務上大多數所謂的 REST API 都是「HTTP API」，而不是嚴格意義的 REST。這不是問題，重要的是**一致性和可預測性**，而不是是否符合 REST 的學術定義。

### 2.2 資源命名哲學

**用名詞，不用動詞**

```
# 錯誤
GET /getUser
POST /createOrder
POST /deleteProduct

# 正確
GET /users/{id}
POST /orders
DELETE /products/{id}
```

動詞應該由 HTTP method 表達，URL 表達的是資源，不是操作。

**複數 vs 單數**

集合資源用複數（`/users`、`/orders`），個別資源用 `/{id}` 存取（`/users/123`）。保持一致性比選哪個更重要。

**巢狀資源的邊界**

```
# 清晰的從屬關係，巢狀合理
GET /users/{userId}/orders
GET /orders/{orderId}/items

# 超過兩層巢狀，通常是資源建模有問題
GET /users/{userId}/orders/{orderId}/items/{itemId}/reviews
```

巢狀超過兩層時，通常意味著資源的從屬關係過於複雜，應該重新考慮是否讓子資源有自己的頂層路徑（`/reviews/{id}`），並透過 query parameter 過濾。

### 2.3 HTTP Method 的語意

| Method | 語意 | 冪等性 | 安全性 |
|--------|------|--------|--------|
| GET | 讀取資源 | ✅ | ✅ |
| POST | 建立資源 / 觸發操作 | ❌ | ❌ |
| PUT | 完整替換資源 | ✅ | ❌ |
| PATCH | 部分更新資源 | 視實作而定 | ❌ |
| DELETE | 刪除資源 | ✅ | ❌ |

**冪等性（Idempotency）**：多次執行同一請求，結果和執行一次相同。GET、PUT、DELETE 應該是冪等的，POST 通常不是。這對錯誤重試極為重要。

**安全性（Safety）**：操作不改變伺服器狀態。GET 是安全的，不應該有副作用。如果 GET 請求會改變資料，是嚴重的設計問題。

### 2.4 狀態碼的正確使用

狀態碼是 HTTP 協議的語意，正確使用讓 API 更可預測：

**2xx 成功**
- `200 OK`：通用成功
- `201 Created`：資源建立成功，通常搭配 `Location` header 指向新資源
- `204 No Content`：成功但無回應內容（如 DELETE 成功）

**4xx 客戶端錯誤**
- `400 Bad Request`：請求格式或內容有誤，是客戶端的問題
- `401 Unauthorized`：未認證（沒有或 token 無效），名字有誤導性
- `403 Forbidden`：已認證但沒有權限
- `404 Not Found`：資源不存在
- `409 Conflict`：請求和當前資源狀態衝突（如重複建立）
- `422 Unprocessable Entity`：格式正確但語意有誤（如欄位驗證失敗）
- `429 Too Many Requests`：超過 rate limit

**5xx 伺服器錯誤**
- `500 Internal Server Error`：伺服器內部錯誤，通常不應該暴露細節
- `503 Service Unavailable`：服務暫時不可用，搭配 `Retry-After` header

**常見的狀態碼誤用**：
- 所有錯誤都回 200，在 body 裡面用自定義 code 表示錯誤：讓 HTTP 基礎設施（proxy、monitoring）無法正確處理錯誤
- 找不到資源回 400 而不是 404
- 認證失敗回 403 而不是 401

### 2.5 錯誤回應設計

錯誤回應要讓使用者知道**哪裡出了什麼問題，以及如何修復**：

```json
{
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "Request validation failed",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      },
      {
        "field": "age",
        "message": "Must be between 0 and 150"
      }
    ],
    "request_id": "req_abc123"
  }
}
```

`request_id` 讓使用者在回報問題時能夠提供可追蹤的 ID，讓工程師在 log 中快速定位。

**不要在錯誤訊息中洩漏內部實作細節**：資料庫錯誤訊息、stack trace、內部路徑不應該出現在 API 回應中，既是安全問題也是糟糕的使用者體驗。

### 2.6 版本化策略

API 版本化是為了在 API 演化時不破壞現有使用者。常見策略：

**URL 路徑版本**（最常見）
```
/v1/users
/v2/users
```
優點：清晰可見，容易在 log 中區分；缺點：資源的 URL 不再唯一。

**Header 版本**
```
Accept: application/vnd.myapi.v2+json
API-Version: 2024-01-01
```
優點：URL 保持乾淨；缺點：不容易被瀏覽器直接測試，容易被使用者忽略。

**日期版本**（Stripe 的做法）：用日期而不是數字作為版本，明確表達 API 在哪個時間點的行為。對長期 API 特別有用。

**版本化的哲學**：**能不版本化就不版本化**。新增欄位、新增 endpoint 通常是向後相容的，不需要新版本。真正需要新版本的是：移除欄位、改變欄位語意、改變行為。

### 2.7 REST 的局限

REST 在以下情境表現不佳：
- **需要即時雙向通訊**（WebSocket 更適合）
- **需要批量操作**（一次請求操作多筆資料，REST 需要多次請求）
- **資料關係複雜，客戶端需要靈活查詢**（GraphQL 更適合）
- **高效能的服務間通訊**（gRPC 更適合）

---

## 三、GraphQL

### 3.1 核心思想

GraphQL 讓客戶端**精確描述需要什麼資料**，伺服器返回且只返回這些資料。解決了 REST 的兩個核心問題：

**Over-fetching**：REST endpoint 返回固定格式，客戶端得到一堆不需要的欄位。
**Under-fetching**：需要多次請求才能拿到所有需要的資料（N+1 請求問題）。

```graphql
# 一次請求，精確拿到需要的資料
query {
  user(id: "123") {
    name
    email
    orders(last: 5) {
      id
      total
      status
    }
  }
}
```

### 3.2 GraphQL 的真正優勢

GraphQL 最大的價值不是技術，而是**前後端協作模式的改變**：

- 前端可以獨立決定需要什麼資料，不需要等後端建 endpoint
- Schema 是前後端的契約，型別系統讓 API 自帶文件
- 一個 endpoint 取代了數十個 REST endpoint，降低了後端 routing 的複雜度

### 3.3 GraphQL 的代價與陷阱

**N+1 Query 問題**：查詢 10 個 user，每個 user 下面查 orders，如果沒有 DataLoader，會對資料庫發出 1 + 10 = 11 次查詢，而不是 2 次。DataLoader 透過 batching 解決這個問題，但需要特別實作。

**快取困難**：REST 的 GET 請求可以用 HTTP 快取（CDN、瀏覽器快取），GraphQL 的查詢通常是 POST，無法直接用 HTTP 快取。需要用 query-level 的快取或 persisted queries。

**查詢複雜度攻擊**：惡意使用者可以發送極度複雜的巢狀查詢，造成伺服器負載過高。需要限制查詢深度、複雜度評分（query cost analysis）。

**Schema 設計是長期承諾**：GraphQL 的 Schema 一旦有客戶端依賴，欄位就很難移除（可以用 `@deprecated` 標記）。Schema 設計需要像 API 設計一樣謹慎。

**過度靈活的代價**：讓客戶端自由組合查詢，也意味著後端很難預測哪些查詢組合會被使用，效能優化更難做。

### 3.4 適用情境

- 有多種客戶端（Web、iOS、Android），資料需求差異大
- 產品迭代快速，前端需要頻繁改變資料需求
- 資料關係複雜，REST 需要多次請求才能拿到所需資料
- 有強型別需求，希望 Schema 作為前後端契約

**不適合**：
- 簡單的 CRUD API，REST 完全夠用
- 公開的第三方 API，GraphQL 的靈活性讓 rate limiting 和監控更複雜
- 對 HTTP 快取有強需求的場景

---

## 四、gRPC

### 4.1 核心思想

gRPC 是 Google 開發的 RPC（Remote Procedure Call）框架，使用 Protocol Buffers 作為序列化格式，HTTP/2 作為傳輸層。

核心概念：**讓呼叫遠端服務的程式碼看起來像呼叫本地函式**。透過 `.proto` 定義服務介面，自動生成各語言的 client 和 server stub。

```protobuf
service UserService {
  rpc GetUser (GetUserRequest) returns (User);
  rpc ListUsers (ListUsersRequest) returns (stream User);
  rpc CreateUser (CreateUserRequest) returns (User);
}
```

### 4.2 gRPC 的優勢

**效能**：Protocol Buffers 比 JSON 序列化更快、體積更小（通常小 3-10 倍）。HTTP/2 的多路複用讓一個連線可以並行處理多個請求，減少連線建立的開銷。

**強型別契約**：`.proto` 文件是服務間的正式契約，型別由 protobuf 保證，跨語言一致。Schema 演化有明確規則（field number 不能複用，必須用新的 field number）。

**Streaming 支援**：gRPC 原生支援四種通訊模式：
- Unary（一問一答，最常見）
- Server Streaming（伺服器持續推送）
- Client Streaming（客戶端持續上傳）
- Bidirectional Streaming（雙向流）

**程式碼生成**：從 `.proto` 自動生成 client/server 程式碼，減少手寫樣板程式碼，且跨語言一致。

### 4.3 gRPC 的代價與陷阱

**瀏覽器支援有限**：原生 gRPC 無法在瀏覽器中使用（因為瀏覽器無法控制 HTTP/2 frame），需要 gRPC-Web 或 gRPC-Gateway 作為轉換層。

**除錯困難**：Protocol Buffers 是二進位格式，無法像 JSON 一樣直接閱讀，需要專門工具（如 grpcurl、BloomRPC）。

**學習曲線**：需要學習 protobuf 語法、proto 的 schema 演化規則，以及 gRPC 的錯誤處理模型（不是 HTTP status code，是 gRPC status code）。

**Proto Schema 演化的嚴格規則**：為了維持向後相容，修改 proto 有很多限制（不能改 field number、不能改欄位型別等），需要嚴格遵守才能保證跨版本相容。

### 4.4 適用情境

- **服務間通訊（Backend-to-Backend）**：微服務架構中，服務間的高頻呼叫
- **高效能要求**：對延遲和吞吐有嚴格要求，JSON over HTTP 的開銷難以接受
- **多語言環境**：不同服務用不同語言，需要強型別契約
- **Streaming 場景**：即時資料推送、大量資料傳輸

**不適合**：
- 對外公開的 API（瀏覽器支援問題，使用者難以直接測試）
- 簡單的系統，REST 已經夠用
- 團隊不熟悉 protobuf 生態系

---

## 五、API 設計的通用原則

這些原則跨越 REST、GraphQL、gRPC，適用於所有 API 設計。

### 5.1 一致性高於個人偏好

API 中最重要的品質是一致性。如果用 `created_at` 表示建立時間，就要在所有資源上都用 `created_at`，不能有的用 `createdAt`，有的用 `create_time`。

一致性讓使用者能夠**舉一反三**，看到一個 endpoint 的設計就能預測其他 endpoint。

### 5.2 向後相容是承諾

一旦 API 有了使用者，就必須維持向後相容。向後相容的操作：
- ✅ 新增選填欄位
- ✅ 新增 endpoint
- ✅ 新增 query parameter（有預設值）
- ❌ 移除欄位
- ❌ 改變欄位型別
- ❌ 改變欄位語意
- ❌ 改變 URL 結構
- ❌ 改變錯誤格式

**Postel's Law（強健性原則）**：對接收的內容保持寬容（接受未知欄位而不報錯），對發送的內容保持嚴格（只發送契約中承諾的欄位）。

### 5.3 冪等性設計

關鍵的寫入操作（支付、訂單建立）必須設計成冪等的，讓使用者可以安全重試：

**Idempotency Key**：客戶端生成一個唯一 ID 附在請求中，伺服器用這個 ID 識別重複請求：

```
POST /payments
Idempotency-Key: uuid-generated-by-client

{
  "amount": 1000,
  "currency": "TWD"
}
```

同一個 key 的重複請求，伺服器返回相同的結果而不重複執行操作。這讓網路失敗後的重試變得安全。

### 5.4 分頁設計

返回集合資料時必須分頁，沒有分頁的 API 在資料量大時會造成效能問題。

**Offset Pagination**：
```
GET /users?page=2&per_page=20
```
優點：簡單，可以跳到任意頁；缺點：在資料頻繁插入/刪除時，頁碼會不穩定（第 2 頁的資料可能和上次不同）。

**Cursor Pagination**：
```
GET /users?after=cursor_xyz&limit=20
```
優點：穩定，不受資料插入/刪除影響，適合 infinite scroll；缺點：無法跳到特定頁。

**選擇原則**：feed 類型的資料（社交媒體、通知）用 cursor pagination；需要跳頁的管理介面用 offset pagination。

### 5.5 Rate Limiting 與 Throttling

公開 API 必須有 rate limiting，不然一個失控的客戶端可以打垮整個服務。

設計 rate limit 時要在 response header 中告知客戶端：

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 950
X-RateLimit-Reset: 1716825600
```

超過 rate limit 時回 `429 Too Many Requests`，搭配 `Retry-After` header 告知何時可以重試。

### 5.6 安全性基本要素

**認證 vs 授權**：
- 認證（Authentication）：你是誰？（JWT、API Key、OAuth）
- 授權（Authorization）：你可以做什麼？（RBAC、ABAC）

API 設計中最常見的安全錯誤：
- 透過 URL 傳遞敏感資訊（Token 放在 URL 會出現在 log 中）
- 用序列 ID 作為資源識別（`/users/1` 讓使用者可以猜測其他使用者的 ID），應使用 UUID 或不可猜測的 ID
- 沒有驗證使用者是否有權限存取特定資源（只驗證了認證，沒有驗證授權）
- 在錯誤訊息中暴露過多內部資訊

---

## 六、API 選型決策框架

```
是否需要瀏覽器直接存取？
├── 是 → REST 或 GraphQL
│   ├── 客戶端資料需求差異大，或需要靈活查詢？
│   │   └── GraphQL
│   └── 標準 CRUD，結構清晰？
│       └── REST
└── 否（服務間通訊）
    ├── 對效能有極高要求，或需要 streaming？
    │   └── gRPC
    └── 一般效能需求，或團隊對 REST 更熟悉？
        └── REST
```

**混合使用是常態**：對外用 REST 或 GraphQL（使用者友好、工具支援好），服務間用 gRPC（高效能、強型別）。不需要為了「統一」而在所有場景用同一種 API 風格。

---

## 七、API 設計的文件化

好的 API 文件是 API 設計的一部分，不是事後補充。

**OpenAPI（Swagger）**：REST API 的業界標準規範，可以自動生成互動式文件、客戶端 SDK、測試案例。理想狀態是 API 規範先於實作（API-first design）。

**文件要包含**：
- 每個 endpoint 的用途和語意
- 所有欄位的型別、是否必填、可能的值
- 錯誤情境和對應的錯誤碼
- 至少一個完整的請求/回應範例
- Rate limit 和認證說明
- 變更歷史和棄用通知

**API 設計的最終標準**：讓你的 API 的使用者，在沒有你的協助下，能夠成功完成他們的任務。
