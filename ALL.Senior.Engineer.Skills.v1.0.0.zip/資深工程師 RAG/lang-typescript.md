# TypeScript — 資深工程師技能指南

> 本文件記錄資深工程師對 TypeScript 的深度理解：不在於語法細節，而在於 TypeScript 的型別系統設計哲學、與 JavaScript 的邊界管理、以及在大型工程中如何用型別系統提升程式碼的安全性和可維護性。

---

## 一、TypeScript 的設計哲學

TypeScript 的核心設計目標是：**在不改變 JavaScript 執行語意的前提下，透過靜態型別系統提升大型程式的開發體驗和可靠性**。

理解這個設計目標，能夠解釋 TypeScript 很多看似奇怪的設計決策：

**型別是可擦除的（Type Erasure）**：TypeScript 的型別在編譯後完全消失，不影響執行時行為。這意味著 TypeScript 的型別系統只能做靜態保證，無法做執行時保證。任何需要執行時驗證的場景（如 API 輸入），型別系統都無法替代。

**結構型別系統（Structural Typing）**：TypeScript 用結構（有哪些屬性和方法）來判斷型別相容性，而不是用名稱（Nominal Typing）。這與 Java、C# 等語言不同，也更符合 JavaScript 的 Duck Typing 哲學：

```typescript
interface Point2D { x: number; y: number }
interface Named   { name: string }

// 結構相容，TypeScript 認為這沒問題
function greet(obj: Named) { console.log(obj.name) }
const point = { x: 1, y: 2, name: "origin" }
greet(point) // OK：point 有 name 屬性，結構上相容 Named
```

**健全性 vs 實用性的取捨**：TypeScript 的型別系統刻意不追求完全的健全性（Soundness），而是在健全性和實用性之間取得平衡。有些操作在理論上可能不安全，但 TypeScript 選擇允許它們，因為完全禁止會讓 JavaScript 的常見模式變得無法表達。

---

## 二、型別系統的深度

### 2.1 結構型別系統的含義

理解結構型別系統是避免 TypeScript 型別陷阱的關鍵：

```typescript
// Excess Property Check 只在字面量直接賦值時觸發
interface Config {
  host: string;
  port: number;
}

// 錯誤：直接字面量賦值有額外屬性檢查
const config: Config = { host: "localhost", port: 3000, timeout: 5000 }
// Error: Object literal may only specify known properties

// 但透過中間變數，額外屬性不會報錯
const rawConfig = { host: "localhost", port: 3000, timeout: 5000 }
const config2: Config = rawConfig  // OK：結構上相容
```

這個行為不是 Bug，而是 TypeScript 刻意的設計：對字面量嚴格檢查（因為通常是筆誤），對變數寬鬆（因為可能有合理的額外屬性）。

### 2.2 聯合型別與交叉型別的設計語意

**Union Type（聯合型別）**：`A | B` 表示「是 A 或是 B」。使用時需要 Narrowing 來確定具體型別。

**Intersection Type（交叉型別）**：`A & B` 表示「同時是 A 和 B」，結合兩者的所有屬性。

```typescript
// Union：需要處理兩種情況
type Result<T> = { success: true; data: T } | { success: false; error: string }

function handleResult<T>(result: Result<T>) {
  if (result.success) {
    // TypeScript 知道這裡 result.data 存在
    console.log(result.data)
  } else {
    // TypeScript 知道這裡 result.error 存在
    console.log(result.error)
  }
}

// Intersection：合併型別（常見於 Mixin 模式）
type WithTimestamp = { createdAt: Date; updatedAt: Date }
type User = { id: string; name: string }
type UserWithTimestamp = User & WithTimestamp
```

### 2.3 Discriminated Union（可辨識聯合）

這是 TypeScript 中最重要的模式之一，用一個共同的「標籤」欄位讓 TypeScript 能夠精確地 narrow 型別：

```typescript
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "rectangle"; width: number; height: number }
  | { kind: "triangle"; base: number; height: number }

function area(shape: Shape): number {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2
    case "rectangle":
      return shape.width * shape.height
    case "triangle":
      return 0.5 * shape.base * shape.height
    // TypeScript 會在這裡做 exhaustiveness check
    default:
      const _exhaustive: never = shape  // 如果有未處理的 case，這裡會報錯
      throw new Error(`Unhandled shape: ${_exhaustive}`)
  }
}
```

`never` 型別在 Exhaustiveness Check 中的使用，讓你在新增 `Shape` 的 case 時，TypeScript 會強制你處理所有 case，不會有遺漏。

### 2.4 Conditional Types 和 Mapped Types

這是 TypeScript 型別系統中最強大但也最容易被濫用的功能。

**Conditional Type**：

```typescript
type NonNullable<T> = T extends null | undefined ? never : T

// 從函式型別提取返回型別
type ReturnType<T> = T extends (...args: any[]) => infer R ? R : never

// 實際應用：
type ApiResponse = { data: User[]; total: number }
type DataType = ApiResponse extends { data: infer D } ? D : never
// DataType = User[]
```

**Mapped Type**：對一個型別的所有屬性進行轉換：

```typescript
// 標準庫的 Partial、Required、Readonly 都是 Mapped Type
type Partial<T> = { [K in keyof T]?: T[K] }
type Readonly<T> = { readonly [K in keyof T]: T[K] }

// 自定義：把所有屬性改成 nullable
type Nullable<T> = { [K in keyof T]: T[K] | null }

// 過濾特定型別的屬性
type StringProps<T> = {
  [K in keyof T as T[K] extends string ? K : never]: T[K]
}
```

**資深工程師對這些進階型別的判斷**：進階型別工具非常強大，但過度使用會讓型別定義變得難以閱讀和維護。先問自己：這個複雜的型別定義是否有清晰的業務含義？還是只是在炫技？簡單清晰的型別往往比精巧複雜的型別更有價值。

### 2.5 Template Literal Types

TypeScript 4.1 引入的功能，讓字串型別可以組合：

```typescript
type EventName = "click" | "focus" | "blur"
type HandlerName = `on${Capitalize<EventName>}`
// HandlerName = "onClick" | "onFocus" | "onBlur"

// 實際應用：強型別的 CSS 屬性組合
type CSSUnit = "px" | "em" | "rem" | "%"
type CSSLength = `${number}${CSSUnit}`
// CSSLength = "10px" | "10em" | ... (雖然實際上無法列舉所有 number)
```

---

## 三、與 JavaScript 的邊界管理

### 3.1 型別斷言（Type Assertion）的使用哲學

型別斷言（`as`）是繞過 TypeScript 型別系統的工具，也是最容易製造型別安全漏洞的地方：

```typescript
// 危險：強制告訴 TypeScript "相信我，我知道這是什麼"
const value = JSON.parse(data) as UserProfile

// 問題：如果 data 的結構不符合 UserProfile，執行時會出錯
// 但 TypeScript 在編譯時不會警告你
```

**型別斷言的使用原則**：
- 應該是例外，不是常規操作
- 使用時要清楚地知道「為什麼這個斷言一定是安全的」
- 如果不確定，用 Type Guard 代替

**`as unknown as T`（雙重斷言）**：把任何型別斷言成任何其他型別。這是型別系統最危險的逃生艙。如果你發現自己需要用雙重斷言，通常是設計問題的信號。

### 3.2 Type Guard（型別守衛）

Type Guard 是正確處理不確定型別的方式，比型別斷言更安全：

```typescript
// User-defined Type Guard
function isUser(obj: unknown): obj is User {
  return (
    typeof obj === "object" &&
    obj !== null &&
    typeof (obj as any).id === "string" &&
    typeof (obj as any).name === "string"
  )
}

// 使用 Type Guard
function processInput(input: unknown) {
  if (isUser(input)) {
    // 這裡 TypeScript 知道 input 是 User
    console.log(input.name)
  }
}
```

**Zod、Valibot 等 Runtime Validation 的角色**：在 API 邊界（接收外部輸入）使用 Schema Validation 庫，既有執行時驗證，又能從 Schema 推導出 TypeScript 型別：

```typescript
import { z } from "zod"

const UserSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1).max(100),
  email: z.string().email(),
  age: z.number().int().min(0).max(150).optional(),
})

type User = z.infer<typeof UserSchema>  // 從 Schema 推導型別

// 執行時驗證
const result = UserSchema.safeParse(apiResponse)
if (result.success) {
  const user: User = result.data  // 型別安全，且已驗證
}
```

這個模式讓型別定義和驗證邏輯保持同步，避免了「型別說一套，驗證又是另一套」的問題。

### 3.3 `unknown` vs `any`

`any` 是 TypeScript 型別系統的後門：它關閉了對該值的所有型別檢查。濫用 `any` 讓 TypeScript 退化成 JavaScript。

`unknown` 是 `any` 的型別安全替代：它接受任何值，但使用前必須先 narrow（透過 Type Guard 或型別斷言）。

```typescript
function processValue(value: any) {
  // any：可以直接使用，TypeScript 不檢查
  console.log(value.nonExistentProperty)  // 不報錯，但執行時可能出錯
}

function processValue2(value: unknown) {
  // unknown：必須先確認型別才能使用
  if (typeof value === "string") {
    console.log(value.toUpperCase())  // OK
  }
  // console.log(value.nonExistentProperty)  // 編譯錯誤！
}
```

**資深工程師的立場**：`any` 的唯一合理用途是在逐步遷移 JavaScript 到 TypeScript 的過渡期。新程式碼中出現 `any` 應該觸發 Code Review 的問題。`noImplicitAny` 編譯選項應該始終開啟。

---

## 四、tsconfig 的工程設定

`tsconfig.json` 不只是編譯設定，更是定義型別嚴格程度的關鍵文件。

### 4.1 嚴格模式的重要性

`"strict": true` 是一組嚴格檢查的集合，對新 TypeScript 專案應該永遠開啟：

```json
{
  "compilerOptions": {
    "strict": true,
    // strict: true 等同於開啟以下所有選項：
    // "noImplicitAny": true,        不允許隱式 any
    // "strictNullChecks": true,     null 和 undefined 不能被賦值給其他型別
    // "strictFunctionTypes": true,  函式型別的逆變/協變檢查
    // "strictBindCallApply": true,  bind/call/apply 的型別檢查
    // "noImplicitThis": true,       不允許隱式 this
    // "useUnknownInCatchVariables": true  catch 的變數型別是 unknown
  }
}
```

**`strictNullChecks` 的特別重要性**：沒有 `strictNullChecks`，`null` 和 `undefined` 可以賦值給任何型別，TypeScript 形同虛設。這是最重要的嚴格選項。

### 4.2 模組系統設定

TypeScript 支援多種模組系統，設定需要和執行環境一致：

```json
{
  "compilerOptions": {
    // 目標執行環境的 JS 版本
    "target": "ES2022",
    
    // 模組系統：Node.js 18+ 用 NodeNext，bundler 環境用 bundler
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    
    // 或者：在 bundler（Vite、webpack）環境
    "module": "ESNext",
    "moduleResolution": "bundler"
  }
}
```

**`moduleResolution` 的演化**：舊的 `"node"` 解析策略無法正確處理 ESM 的 `.js` 副檔名要求，`"NodeNext"` 和 `"bundler"` 是現代專案的正確選擇。

### 4.3 Path Aliases

大型專案中，相對路徑（`../../components/Button`）難以維護：

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"],
      "@components/*": ["src/components/*"],
      "@utils/*": ["src/utils/*"]
    }
  }
}
```

注意：tsconfig 的 `paths` 只影響 TypeScript 的型別解析，不影響執行時的模組解析。執行時還需要 bundler（Vite、webpack）或 Node.js 的設定來支援這些別名。

---

## 五、大型 TypeScript 專案的工程實踐

### 5.1 型別的組織方式

**避免 `types.ts` 的反模式**：把所有型別都放在一個 `types.ts` 檔案，讓這個檔案成為任何東西都依賴的中心節點。隨著專案成長，這個檔案會變得難以維護，且形成難以解開的依賴關係。

**型別應該靠近使用它的程式碼**：User 相關的型別放在 `user/` 目錄，Order 相關的型別放在 `order/` 目錄。只有真正跨領域共用的基礎型別才放在共用的地方。

**型別的 barrel export**：

```typescript
// user/index.ts：只 export 外部需要知道的型別
export type { User, CreateUserInput, UpdateUserInput } from "./types"
export { UserService } from "./service"
// 不 export 內部實作細節
```

### 5.2 Declaration Merging 和 Module Augmentation

TypeScript 允許對已有的型別（包括第三方庫的型別）進行擴充：

```typescript
// 擴充 Express 的 Request 型別，加入自定義屬性
declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser
      requestId: string
    }
  }
}

// 擴充現有 interface
interface Window {
  analytics: AnalyticsClient
}
```

這讓全局狀態（如 Express middleware 注入的屬性）可以有型別安全，而不是用 `any` 繞過。

### 5.3 Branded Types（品牌型別）

在結構型別系統中，相同結構的型別可以互換，有時候這不是我們想要的：

```typescript
// 問題：UserId 和 OrderId 都是 string，可以互換
type UserId = string
type OrderId = string

function getOrder(orderId: OrderId): Order { ... }

const userId: UserId = "user_123"
getOrder(userId)  // TypeScript 不會報錯！但語意上是錯的

// 解法：Branded Type
type Brand<T, B> = T & { readonly _brand: B }
type UserId = Brand<string, "UserId">
type OrderId = Brand<string, "OrderId">

function getOrder(orderId: OrderId): Order { ... }

const userId = "user_123" as UserId
getOrder(userId)  // 型別錯誤！UserId 和 OrderId 不兼容
```

Branded Types 在金融系統（不同幣別的金額）、ID 系統（不同實體的 ID）等場景中非常有價值，能夠在編譯時防止邏輯錯誤。

### 5.4 Satisfies 運算符（TypeScript 4.9+）

`satisfies` 讓你驗證一個值符合某個型別，但保留更精確的推導型別：

```typescript
type Color = "red" | "green" | "blue"
type ColorMap = Record<Color, string | [number, number, number]>

// 問題：as 斷言丟失了精確型別
const colors = {
  red: "#ff0000",
  green: [0, 255, 0],
  blue: "#0000ff"
} as ColorMap

colors.green  // 型別是 string | [number, number, number]，失去了精確性

// satisfies：驗證型別相容性，但保留精確推導
const colors2 = {
  red: "#ff0000",
  green: [0, 255, 0],
  blue: "#0000ff"
} satisfies ColorMap

colors2.green  // 型別是 [number, number, number]，精確！
colors2.red    // 型別是 string，精確！
```

---

## 六、TypeScript 與 JavaScript 生態系的共存

### 6.1 逐步遷移策略

把現有 JavaScript 專案遷移到 TypeScript 不需要一次完成：

**階段一**：把 `.js` 改為 `.ts`，設定 `"strict": false`，允許大量 `any`。確認系統仍然可以運作。

**階段二**：開啟 `"noImplicitAny": true`，逐步為函式簽名加上型別。

**階段三**：開啟 `"strictNullChecks": true`，處理 null/undefined 相關的型別問題。這通常是最費力的階段。

**階段四**：開啟完整的 `"strict": true`，清理剩餘的型別問題。

**JSDoc as TypeScript**：在完全遷移之前，可以用 JSDoc 注釋為 JavaScript 提供型別資訊，讓 TypeScript 的語言伺服器提供基本的型別支援。

### 6.2 第三方庫的型別處理

**`@types/*` 套件**：很多 npm 套件本身不包含型別定義，由社群維護的 `@types/*` 套件提供。如 `@types/node`、`@types/react`。

**`skipLibCheck: true`**：跳過對 `node_modules` 中 `.d.ts` 的型別檢查。在第三方庫的型別定義有問題時很有用，但要小心不要掩蓋真正的問題。

---

## 七、資深工程師對 TypeScript 的整體判斷

**TypeScript 的核心價值**：在大型 JavaScript 專案中，型別系統是最有效的文件，也是最有效的重構安全網。TypeScript 的投資回報在專案規模超過一定程度後急劇增加。

**TypeScript 不能替代的東西**：
- 執行時的型別驗證（需要 Zod 等庫）
- 測試（型別系統不能發現邏輯錯誤）
- 良好的架構設計（型別可以輔助，但不能替代）

**常見的 TypeScript 誤用**：
- 過度使用 `any` 讓型別系統形同虛設
- 過度複雜的型別體操（Conditional Type 嵌套多層），讓型別定義本身難以理解
- 把所有型別都 export，讓內部實作細節洩漏到模組邊界之外
- 依賴型別斷言而不是型別守衛，埋下執行時錯誤的隱患

**TypeScript 的最終目標**：讓工程師在重構時有信心，在 Code Review 時有依據，在閱讀程式碼時能快速理解意圖。型別系統是為工程師服務的工具，不是工程師服務型別系統的地方。
