# Rust — 資深工程師技能指南

> 本文件記錄資深工程師對 Rust 的深度理解：不在於語法細節，而在於 Rust 的所有權系統的本質、它解決了什麼根本問題、以及什麼時候選擇 Rust 是正確的工程決策。Rust 是一門有強烈設計主張的語言，理解這些主張是用好 Rust 的前提。

---

## 一、Rust 的設計哲學

Rust 試圖解決一個長期被認為不可能同時解決的問題：**在沒有垃圾回收器（GC）的情況下，保證記憶體安全**。

傳統上，系統程式設計語言面臨的選擇是：
- **C/C++**：手動記憶體管理，極高效能，但充滿 use-after-free、double-free、buffer overflow 等記憶體安全問題
- **Java/Go/Python**：GC 管理記憶體，記憶體安全，但有 GC 暫停、更高的記憶體使用、無法精確控制記憶體佈局

Rust 的答案是：**透過所有權系統（Ownership System）在編譯期靜態分析記憶體的使用，在沒有 GC 的情況下保證記憶體安全**。

**Rust 的核心保證**：如果程式碼通過了 Rust 編譯器的檢查，它就不會有：
- use-after-free（使用已釋放的記憶體）
- double-free（同一塊記憶體被釋放兩次）
- null pointer dereference（除非明確使用 `unsafe`）
- data race（多執行緒的資料競爭）

這些保證是在編譯期，不是執行期，所以沒有執行時開銷。

**Rust 的代價**：編譯器的檢查非常嚴格，學習曲線陡峭。工程師需要顯式地思考每一塊資料的所有權、生命週期、和借用關係。這個思考負擔在習慣後會降低，但永遠不會消失。

---

## 二、所有權系統（Ownership System）

所有權是 Rust 最核心的概念，也是與其他語言最不同的地方。

### 2.1 所有權的三條規則

1. **每個值都有一個擁有者（Owner）**
2. **同一時間只能有一個擁有者**
3. **當擁有者離開作用域，值被自動釋放（Drop）**

```rust
fn main() {
    let s1 = String::from("hello");  // s1 是 "hello" 的擁有者
    let s2 = s1;                     // 所有權從 s1 移動到 s2（Move）
    
    // println!("{}", s1);  // 編譯錯誤！s1 已經無效，不能使用
    println!("{}", s2);     // OK：s2 是現在的擁有者
}   // s2 離開作用域，String 被自動 drop（釋放）
```

這就是「Move 語意」：把一個值賦給另一個變數，不是複製，而是所有權轉移。原來的變數無效。

### 2.2 Clone vs Copy

不是所有型別都是 Move 語意：

**Copy 型別**：實作了 `Copy` trait 的型別（所有整數型別、浮點型別、布林、char、以及只含 Copy 型別的 tuple）在賦值時自動複製，原變數仍然有效：

```rust
let x = 5;
let y = x;  // 整數是 Copy，x 被複製給 y
println!("{}", x);  // OK：x 仍然有效
```

**Clone**：需要深度複製時，顯式呼叫 `.clone()`：

```rust
let s1 = String::from("hello");
let s2 = s1.clone();  // 明確的深度複製，有成本
println!("{} {}", s1, s2);  // 兩者都有效
```

**資深工程師的判斷**：`clone()` 是解決所有權問題最簡單的辦法，但也是有成本的（記憶體分配和複製）。在效能敏感的路徑中，應該嘗試用借用來避免不必要的 clone。但也不要過早優化——先讓程式碼正確，必要時再去掉 clone。

### 2.3 借用（Borrowing）與引用（Reference）

借用讓你在不轉移所有權的情況下使用值：

```rust
fn calculate_length(s: &String) -> usize {
    s.len()  // 借用 s，不取得所有權
}

fn main() {
    let s1 = String::from("hello");
    let len = calculate_length(&s1);  // 傳遞引用，不移動所有權
    println!("{} has {} characters", s1, len);  // s1 仍然有效
}
```

**借用的規則**（這是 Rust 的核心安全保證）：

同一時間，對同一個值，只能有以下其中一種情況：
- **一個或多個不可變引用（`&T`）**
- **恰好一個可變引用（`&mut T`）**

不能同時有可變引用和不可變引用。

```rust
let mut s = String::from("hello");

let r1 = &s;     // 不可變引用，OK
let r2 = &s;     // 又一個不可變引用，OK
// let r3 = &mut s;  // 編譯錯誤！不能在有不可變引用時有可變引用

println!("{} {}", r1, r2);  // r1, r2 在這裡最後一次使用

let r3 = &mut s;  // OK：r1, r2 的生命週期已結束
r3.push_str(", world");
```

**這個規則消除了什麼問題**：
- **Data Race**：如果同一時間只有一個執行緒可以修改資料（只有一個 `&mut`），就不可能有資料競爭
- **Iterator Invalidation**：在遍歷集合時修改集合（C++ 的常見 bug），Rust 的借用規則會阻止這種操作

---

## 三、生命週期（Lifetimes）

### 3.1 生命週期的本質

生命週期是 Rust 確保引用永遠有效的機制。每個引用都有一個生命週期，表示這個引用有效的作用域範圍。

大多數時候，生命週期是隱式的，編譯器可以自動推導（Lifetime Elision）。但在某些情況下，需要顯式標注：

```rust
// 這個函式返回兩個字串中較長的那個的引用
// 問題：返回的引用的生命週期和哪個參數相關？
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() > y.len() { x } else { y }
}
```

`'a` 是生命週期參數，它表示「返回的引用的生命週期，至少和 `x`、`y` 中較短的那個一樣長」。這讓編譯器能夠驗證呼叫端正確地使用了返回的引用。

### 3.2 生命週期的直覺理解

不需要把生命週期想成複雜的理論，而是問：**這個引用指向的資料，能保證在引用被使用時仍然存在嗎？**

生命週期標注是在給編譯器提供這個問題的答案。如果你的標注使得某個引用可能指向已釋放的資料，編譯器會拒絕編譯。

```rust
// 懸空引用（Dangling Reference）：Rust 不允許這種情況
fn dangle() -> &String {  // 返回一個引用
    let s = String::from("hello");  // s 在這個函式裡建立
    &s  // 返回 s 的引用
}   // s 在這裡被 drop（釋放），但我們返回了它的引用！
// 編譯錯誤：s 的生命週期不夠長
```

### 3.3 'static 生命週期

`'static` 是最長的生命週期，表示整個程式的執行期間。字串字面量（`&str`）的生命週期是 `'static`，因為它們被編譯進 binary。

```rust
let s: &'static str = "I have a static lifetime";
```

在看到需要 `'static` 的 API 時，要思考：為什麼這個 API 需要資料活整個程式週期？這通常意味著資料會被存在全局狀態中，或在多個執行緒之間共享。

---

## 四、Rust 的並發模型

### 4.1 Fearless Concurrency（無畏並發）

Rust 的並發安全保證來自型別系統，而不是語言層面的限制。核心機制是兩個 trait：

**Send**：型別的所有權可以安全地跨執行緒轉移。大多數型別都是 Send，但 `Rc<T>`（非原子的引用計數）不是。

**Sync**：型別的引用可以安全地跨執行緒共享（`&T` 是 Send，當且僅當 T 是 Sync）。`Cell<T>` 和 `RefCell<T>` 不是 Sync，因為它們的內部可變性沒有執行緒安全保護。

如果你試圖跨執行緒共享不是 `Send` 或 `Sync` 的型別，編譯器會拒絕編譯。Data race 在 Rust 中是編譯期錯誤，不是執行期錯誤。

### 4.2 共享狀態的並發

```rust
use std::sync::{Arc, Mutex};
use std::thread;

fn main() {
    // Arc：原子引用計數，允許多個 Owner（跨執行緒）
    // Mutex：提供內部可變性（同時只有一個執行緒可以存取）
    let counter = Arc::new(Mutex::new(0));
    let mut handles = vec![];

    for _ in 0..10 {
        let counter = Arc::clone(&counter);
        let handle = thread::spawn(move || {
            let mut num = counter.lock().unwrap();
            *num += 1;
        });
        handles.push(handle);
    }

    for handle in handles {
        handle.join().unwrap();
    }

    println!("Result: {}", *counter.lock().unwrap());
}
```

**Arc vs Rc**：
- `Rc<T>`：單執行緒的引用計數，沒有原子操作，比 `Arc` 快，但不能跨執行緒
- `Arc<T>`：多執行緒的引用計數，使用原子操作，可以跨執行緒

### 4.3 async/await 與 Tokio

Rust 的 async/await 模型和 Goroutine、Python asyncio 類似，但有幾個重要的不同：

**Rust 的 Future 是惰性的**：建立一個 Future 不會立即執行任何東西，必須被 `.await` 或被 executor 驅動才會執行。

**Rust 沒有內建的 async runtime**：需要選擇第三方 runtime，最主流的是 Tokio：

```rust
// Tokio：Rust 最主流的 async runtime
#[tokio::main]
async fn main() {
    let result = tokio::join!(
        fetch_data("url1"),
        fetch_data("url2"),
        fetch_data("url3"),
    );
}

async fn fetch_data(url: &str) -> Result<String, reqwest::Error> {
    let response = reqwest::get(url).await?;
    response.text().await
}
```

**async fn 的生命週期挑戰**：async 函式中的引用生命週期比同步函式更複雜，因為 Future 可能在不同的時間點被恢復執行。這是 Rust async 程式設計中最難的部分之一。

---

## 五、Rust 的錯誤處理

### 5.1 Result 和 Option

Rust 沒有 null 和 exception。null 的替代品是 `Option<T>`，exception 的替代品是 `Result<T, E>`：

```rust
// Option：可能有值，也可能沒有
fn find_user(id: u64) -> Option<User> {
    if id == 0 { None } else { Some(User { id }) }
}

// Result：可能成功，也可能失敗
fn parse_config(path: &str) -> Result<Config, io::Error> {
    let content = fs::read_to_string(path)?;  // ? 運算子：如果是 Err，提前返回
    Ok(Config::parse(&content))
}
```

**`?` 運算子**是 Rust 錯誤處理的核心，它讓錯誤傳播簡潔：如果是 `Err`，立即返回（等同於 `return Err(e)`）；如果是 `Ok`，解包值繼續執行。

### 5.2 自定義錯誤型別與 thiserror

在大型系統中，需要定義自己的錯誤型別：

```rust
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AppError {
    #[error("Database error: {0}")]
    Database(#[from] sqlx::Error),
    
    #[error("Not found: {resource} with id {id}")]
    NotFound { resource: String, id: u64 },
    
    #[error("Validation failed: {0}")]
    Validation(String),
}

// anyhow：適合應用層，不需要精確匹配錯誤型別時
use anyhow::{Context, Result};

fn process() -> Result<()> {
    let data = load_data().context("Failed to load data")?;
    // ...
    Ok(())
}
```

**thiserror vs anyhow 的選擇**：
- `thiserror`：適合庫（Library）程式碼，呼叫方需要 match 不同的錯誤型別
- `anyhow`：適合應用（Application）程式碼，只需要傳遞和記錄錯誤，不需要精確匹配

---

## 六、Rust 的核心概念：Trait

### 6.1 Trait 是 Rust 的介面

Trait 定義共享的行為，類似其他語言的介面，但更強大：

```rust
trait Summary {
    fn summarize(&self) -> String;
    
    // Trait 可以有預設實作
    fn preview(&self) -> String {
        format!("{}...", &self.summarize()[..50])
    }
}

struct Article { title: String, content: String }

impl Summary for Article {
    fn summarize(&self) -> String {
        format!("{}: {}", self.title, &self.content[..100])
    }
}
```

### 6.2 Trait Object vs Generics 的取捨

在需要多型行為時，Rust 有兩種方式：

**Generics（靜態分發，Monomorphization）**：

```rust
// 編譯器為每個具體型別生成特化的程式碼
// 零執行時開銷，但 binary 較大（每個型別一份程式碼）
fn notify<T: Summary>(item: &T) {
    println!("{}", item.summarize());
}
```

**Trait Object（動態分發）**：

```rust
// 執行時透過 vtable 決定呼叫哪個實作
// 有一點執行時開銷，但允許異質集合（不同型別放在同一個集合）
fn notify(item: &dyn Summary) {
    println!("{}", item.summarize());
}

let items: Vec<Box<dyn Summary>> = vec![
    Box::new(Article { ... }),
    Box::new(Tweet { ... }),
];
```

**選擇原則**：預設用 Generics（零開銷）。當你需要在執行時決定型別（如異質集合、Plugin 系統），才用 Trait Object。

---

## 七、unsafe Rust

### 7.1 unsafe 的語意

`unsafe` 塊讓你執行 Rust 通常禁止的操作：
- 解引用裸指標（Raw Pointer）
- 呼叫 unsafe 函式或方法
- 實作 unsafe trait
- 存取或修改可變靜態變數
- 存取 union 的欄位

### 7.2 unsafe 的正確心態

`unsafe` 不是關閉了 Rust 的所有安全性，而是把部分安全責任從編譯器轉移到了程式設計師。使用 `unsafe` 時，你在承諾：「我理解這個操作的安全前提，並且保證這些前提是滿足的。」

```rust
// unsafe 通常被封裝在安全的介面背後
pub fn safe_function(data: &[i32]) -> &i32 {
    // 我們知道 data 至少有一個元素（由呼叫約定保證）
    // 所以這個 unsafe 操作是安全的
    unsafe { data.get_unchecked(0) }
}
```

**資深工程師的判斷**：`unsafe` 塊應該盡可能小，並且有清晰的注釋說明安全前提。如果你在 unsafe 塊中寫了大量複雜邏輯，通常是設計問題的信號。在應用層程式碼中，應該完全避免 unsafe。

---

## 八、Rust 的生態系

### 8.1 Cargo 與 crates.io

Cargo 是 Rust 的構建工具和套件管理器，是業界公認設計最好的套件管理工具之一：

- **統一工具**：build、test、bench、doc、publish，全部用 Cargo
- **確定性構建**：`Cargo.lock` 確保所有人構建的是完全相同的依賴版本
- **工作區（Workspace）**：多個相關 crate 的 monorepo 管理

### 8.2 重要的 crate 生態

**非同步**：`tokio`（最主流）、`async-std`

**Web 框架**：`axum`（Tokio 生態，設計優雅）、`actix-web`（高效能，Actor 模型）

**資料庫**：`sqlx`（非同步，支援編譯期 SQL 驗證）、`diesel`（同步，強型別 ORM）

**序列化**：`serde`（幾乎是 Rust 序列化的唯一選擇，設計非常優秀）

**錯誤處理**：`thiserror`（庫）、`anyhow`（應用）

**命令列**：`clap`（CLI 參數解析）

---

## 九、Rust 的適用場景與整體判斷

### 9.1 Rust 的最佳適用場景

**系統程式設計**：作業系統元件、驅動程式、嵌入式系統。Rust 是 Linux Kernel（2022 年起）和 Windows Kernel（微軟）中第二個被允許使用的語言（第一個是 C）。

**效能關鍵路徑**：需要接近 C 的效能，但不能接受 C 的安全問題。高頻交易系統、遊戲引擎、編解碼器。

**WebAssembly**：Rust 是 WASM 生態中最成熟的語言，可以編譯到 WASM 在瀏覽器高效執行。

**網路服務（效能敏感）**：在需要極低延遲、極高吞吐的場景，Rust 的效能超過 Go 和 Java，且記憶體使用更可預測（沒有 GC 暫停）。

**命令列工具**：快速啟動、單一 binary、跨平台。`ripgrep`、`fd`、`bat` 等都是 Rust 寫的，效能遠超 GNU 工具。

**基礎設施工具**：Deno、Neon（Node.js 的 Rust 擴展框架）、Turbopack、SWC（Webpack/Babel 的替代品）。

### 9.2 Rust 的限制

**學習曲線陡峭**：所有權和借用系統需要大量時間才能真正內化。工程師「和借用檢查器搏鬥」的時間在初期會顯著降低生產力。

**開發速度較慢**：相比 Python、Go，Rust 的開發速度明顯更慢。用 Rust 寫快速原型驗證想法，不是好的選擇。

**生態系不如主流語言成熟**：雖然快速成長，但在某些領域（資料科學、機器學習）Rust 的生態系遠不如 Python。

**編譯時間長**：大型 Rust 專案的編譯時間是已知的問題（雖然 incremental compilation 有所改善）。

### 9.3 選擇 Rust 的判斷框架

選擇 Rust 的時機應該是：
- 效能是第一優先，且其他語言無法滿足
- 需要極精細的記憶體控制（嵌入式、即時系統）
- 安全性要求極高（系統軟體、密碼學）
- 需要確定性的延遲（GC 暫停不可接受）

**不應該選擇 Rust 的情況**：
- 快速原型和業務邏輯為主的應用
- 團隊沒有 Rust 經驗，且截止日期緊迫
- 應用的效能瓶頸在資料庫或網路，而不是 CPU
- 生態系需求（如 ML/AI）在 Rust 中不成熟

### 9.4 Rust 的更深層價值

學習 Rust 即使最終不用於生產系統，也有深遠的價值：

理解所有權、生命週期、借用讓你對**其他語言中記憶體的運作**有更深的直覺。你會更清楚地理解為什麼 Python 的物件共享是安全的、為什麼 Go 需要 GC、為什麼 C 的指標是危險的。Rust 是最好的「讓你真正理解記憶體的語言」，這種理解在任何語言中都有價值。
