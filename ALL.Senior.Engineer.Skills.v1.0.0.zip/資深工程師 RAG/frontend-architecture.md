# Frontend Architecture — 資深工程師技能指南

> 本文件記錄資深工程師對前端架構的思維框架：不只是「用什麼框架」，而是如何設計可擴展、可維護的前端系統——元件邊界的劃分、狀態管理的策略、以及大型前端工程的組織方式。

---

## 一、前端架構的根本挑戰

前端架構面臨的核心挑戰和後端截然不同：

**狀態無處不在**：前端充滿了狀態——UI 狀態（某個 modal 是否打開）、伺服器狀態（API 資料的快取）、表單狀態、URL 狀態、全局設定。如何管理這些不同來源、不同生命週期的狀態，是前端架構的核心問題。

**邊界難以劃分**：後端的模組邊界相對清晰（Service、Repository），但前端的元件邊界充滿模糊地帶。一個 Button 元件應該知道它在哪個頁面嗎？一個 Form 元件應該直接呼叫 API 嗎？這些問題沒有唯一答案，但有更好和更差的設計。

**效能是使用者體驗**：前端的效能直接影響使用者感受，且效能問題往往不是「慢」，而是「卡頓」——使用者互動後 UI 沒有立即回應。

**生態系變化極快**：前端技術棧以年為單位快速演化，架構決策要考慮長期可維護性，不能每次有新框架就重寫。

---

## 二、元件設計哲學

### 2.1 元件的職責邊界

元件設計最重要的問題是：**這個元件知道多少關於它所在的環境？**

**Presentational Component（展示元件）**：只關心「看起來如何」，透過 props 接收資料，透過 callback 傳遞事件。不知道資料從哪裡來，不知道事件的後果是什麼。最容易測試和重用。

```typescript
// 展示元件：只關心外觀，通過 props 接收一切
interface UserCardProps {
  name: string;
  email: string;
  avatarUrl: string;
  onFollow: () => void;
  isFollowing: boolean;
}

function UserCard({ name, email, avatarUrl, onFollow, isFollowing }: UserCardProps) {
  return (
    <div className="user-card">
      <img src={avatarUrl} alt={name} />
      <h3>{name}</h3>
      <p>{email}</p>
      <button onClick={onFollow}>
        {isFollowing ? "Following" : "Follow"}
      </button>
    </div>
  );
}
```

**Container Component（容器元件）**：知道資料從哪裡來（API、store），負責取得資料和處理業務邏輯，把資料和 handler 傳給展示元件。

```typescript
// 容器元件：知道資料來源，處理業務邏輯
function UserCardContainer({ userId }: { userId: string }) {
  const { data: user } = useUser(userId);
  const { mutate: follow } = useFollowUser();
  const { data: followStatus } = useFollowStatus(userId);

  if (!user) return <UserCardSkeleton />;

  return (
    <UserCard
      name={user.name}
      email={user.email}
      avatarUrl={user.avatarUrl}
      onFollow={() => follow(userId)}
      isFollowing={followStatus?.isFollowing ?? false}
    />
  );
}
```

**資深工程師的判斷**：這個分離不是宗教，而是管理複雜度的工具。在小型應用中強制分離所有元件是過度工程。但在大型應用中，讓展示元件保持「無副作用、純函式」的特性，讓可測試性和可重用性大幅提升。

### 2.2 元件組合（Composition）vs 繼承

React 的官方文件明確建議：**優先使用組合，而不是繼承**。

**Props 組合**：透過 `children` 和 render props 讓元件接受任意內容：

```typescript
// 靈活的 Card 元件，通過 children 接受任意內容
function Card({ children, footer }: { children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div className="card">
      <div className="card-body">{children}</div>
      {footer && <div className="card-footer">{footer}</div>}
    </div>
  );
}

// 使用方組合出各種卡片
<Card footer={<button>Submit</button>}>
  <UserProfile user={user} />
</Card>
```

**Compound Component Pattern**：讓父元件和子元件共享隱式狀態，創造高度靈活的 API：

```typescript
// Select 元件的 Compound Component 設計
<Select value={value} onChange={setValue}>
  <Select.Trigger>Select an option</Select.Trigger>
  <Select.Content>
    <Select.Item value="a">Option A</Select.Item>
    <Select.Item value="b">Option B</Select.Item>
  </Select.Content>
</Select>
```

這個模式讓使用方可以自由決定子元件的組合方式和順序，同時父元件統一管理狀態。

### 2.3 元件的大小與拆分時機

一個常見的問題：「什麼時候應該拆分元件？」

**拆分的觸發條件**：
- 元件超過 200-300 行，很難在一個螢幕內看完
- 一個部分有獨立的狀態或副作用，可以獨立推理
- 一個部分在多處重用
- 一個部分有獨立的渲染頻率（拆分可以避免整個父元件重新渲染）

**不應該拆分的情況**：
- 只是為了縮短行數，但拆出的元件沒有獨立意義
- 拆分後子元件需要傳遞大量 props（Props Drilling），說明邊界劃錯了
- 拆分讓程式碼更難跟蹤，而不是更容易

### 2.4 設計系統（Design System）的工程含義

設計系統不只是 UI 元件庫，而是確保整個應用視覺和互動一致性的工程基礎設施。

**Primitive Components（原子元件）**：Button、Input、Modal、Select——這些元件高度可重用，樣式由設計系統統一定義，業務邏輯幾乎沒有。

**Composite Components（組合元件）**：把多個 Primitive 組合成有業務語意的元件，如 UserSearchBar（Input + Icon + Dropdown）。

**設計系統的維護挑戰**：設計系統是一個內部套件，需要版本管理、changelog、使用指南。元件的 API 一旦有其他團隊依賴，修改就需要考慮向後相容性。這是很多團隊低估的維護成本。

---

## 三、狀態管理策略

### 3.1 狀態的分類

前端狀態可以按來源和生命週期分類：

| 狀態類型 | 特性 | 適合的管理方式 |
|---------|------|--------------|
| UI 狀態 | 只影響 UI（modal open、tab active）| Local state（useState）|
| 表單狀態 | 複雜的驗證和提交邏輯 | React Hook Form、Formik |
| 伺服器狀態 | 來自 API，需要快取、同步、重新獲取 | TanStack Query、SWR |
| 全局 UI 狀態 | 跨元件共享（主題、語言、通知）| Context、Zustand |
| URL 狀態 | 可分享、可書籤的狀態 | URL params、query string |

**最重要的洞察**：大多數應用的「狀態管理問題」，其實是「伺服器狀態管理問題」。伺服器狀態（API 資料）有快取、過期、同步、樂觀更新等複雜需求。引入 TanStack Query 或 SWR 處理伺服器狀態，可以消除大量原本放在 Redux 裡的 API 相關程式碼。

### 3.2 何時需要全局狀態管理

「我要用 Redux 嗎？」是前端工程師最常問的問題之一。

**不需要全局狀態管理的情況（大多數應用）**：
- 狀態只在一個元件樹的範圍內共享 → Context API 足夠
- 狀態主要是伺服器資料 → TanStack Query 處理
- 應用規模中小，URL + Context + Local state 就能管理

**需要全局狀態管理的情況**：
- 狀態在完全不相關的元件樹之間共享
- 需要複雜的狀態更新邏輯（多個 reducer 協作）
- 需要 time-travel debugging 或狀態快照
- 狀態有複雜的派生邏輯（Selectors）

### 3.3 Context API 的正確使用

Context 是 React 的依賴注入機制，但容易被誤用：

**Context 的效能陷阱**：當 Context 的值改變，所有消費這個 Context 的元件都會重新渲染（即使它們只用到 Context 中沒有改變的部分）。

```typescript
// 問題：ThemeContext 改變，所有消費者都重新渲染
const ThemeContext = createContext({ theme: 'light', user: null, settings: {} });

// 解法 1：拆分成多個細粒度的 Context
const ThemeContext = createContext({ theme: 'light' });
const UserContext = createContext(null);
const SettingsContext = createContext({});

// 解法 2：Context 搭配 useMemo 避免不必要的 reference 變化
function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState('light');
  const value = useMemo(() => ({ theme, setTheme }), [theme]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}
```

### 3.4 Zustand、Jotai、Recoil 的選擇哲學

這三個都是「輕量全局狀態」的選擇，對比 Redux 更簡單：

**Zustand**：Store 是普通的 JavaScript 物件加上 actions。簡單直觀，沒有 Redux 的 boilerplate（action type、reducer、dispatch）。適合大多數全局狀態需求。

**Jotai**：基於「原子（Atom）」的細粒度狀態，每個原子獨立，只有依賴這個原子的元件才會重新渲染。對效能敏感的場景有優勢。

**Recoil**：Facebook 出品，概念和 Jotai 類似但更複雜。在 React 18 的 Concurrent Mode 下有更好的支援。

**資深工程師的選擇邏輯**：從 Local State + TanStack Query 開始。當確實需要跨元件樹的全局狀態時，引入 Zustand（學習成本最低）。只有在有明確的細粒度更新效能問題時，才考慮 Jotai。

---

## 四、前端的模組化與程式碼組織

### 4.1 Feature-First vs Layer-First

**Layer-First（按技術層分類）**：
```
src/
├── components/    ← 所有元件
├── hooks/         ← 所有 hooks
├── services/      ← 所有 API 呼叫
├── utils/         ← 所有工具函式
└── stores/        ← 所有狀態
```

**Feature-First（按功能分類）**：
```
src/
├── features/
│   ├── auth/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── api/
│   │   └── index.ts
│   ├── orders/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── api/
│   │   └── index.ts
│   └── ...
└── shared/        ← 真正跨功能共用的東西
```

**資深工程師的判斷**：在小型應用中，Layer-First 更簡單。在大型應用中，Feature-First 讓相關程式碼聚在一起，修改一個功能時不需要在多個資料夾間跳轉。每個 Feature 有清晰的邊界，`index.ts` 是公開 API，內部實作細節不暴露。

**Bulletproof React 的分層模型**（實用的參考架構）：
```
src/
├── assets/          ← 靜態資源
├── components/      ← 跨功能的通用元件（Button、Input、Modal）
├── config/          ← 設定和常數
├── features/        ← 功能模組（每個功能自成一體）
├── hooks/           ← 跨功能的通用 hooks
├── lib/             ← 第三方庫的封裝層
├── providers/       ← 全局 Provider 設定
├── routes/          ← 路由定義
├── stores/          ← 全局狀態（如果需要）
├── testing/         ← 測試工具和 mock
├── types/           ← 跨功能的共用型別
└── utils/           ← 純函式工具
```

### 4.2 barrel export 的取捨

barrel export（`index.ts` 重新 export 多個模組）讓 import 路徑更簡潔：

```typescript
// 沒有 barrel：
import { UserCard } from '../features/users/components/UserCard';
import { useUser } from '../features/users/hooks/useUser';

// 有 barrel：
import { UserCard, useUser } from '../features/users';
```

**barrel export 的問題**：當 bundler 不支援 tree-shaking，barrel export 可能讓你的 bundle 引入了所有 export 的程式碼，即使你只用了其中一個。現代 bundler（Vite、ESBuild）大多支援 tree-shaking，但要確認設定正確。

---

## 五、Monorepo 架構

### 5.1 Monorepo 的核心價值

Monorepo 把多個相關的套件/應用放在同一個 git repository 中。對前端工程組織，Monorepo 的主要優勢是：

**程式碼共享**：設計系統元件、工具函式、型別定義，可以在多個應用間共享，且修改是原子的（一個 commit 同時修改庫和使用它的應用）。

**統一工具鏈**：所有套件使用相同版本的 TypeScript、ESLint、Prettier，消除跨套件的版本不一致問題。

**跨套件的 Refactoring**：重命名一個 export，IDE 可以同時修改所有使用它的地方。

### 5.2 Monorepo 工具的選擇

**Turborepo**：最主流的前端 Monorepo 工具，核心特性是 Pipeline（定義任務的依賴關係）和 Remote Caching（CI 快取分享到所有開發機）。設定簡單，適合大多數前端 Monorepo。

**Nx**：功能更強大，支援程式碼生成、Project Graph 視覺化、Affected Commands（只重建被改動影響的套件）。適合大型、複雜的 Monorepo。

**pnpm Workspace**：不是完整的 Monorepo 工具，但 pnpm 的 workspace 功能讓套件間的本地連結（local linking）非常高效，通常和 Turborepo 搭配使用。

### 5.3 Monorepo 的套件邊界設計

Monorepo 中最重要的設計決策是套件的邊界：

```
packages/
├── ui/              ← 設計系統元件（無業務邏輯）
├── utils/           ← 純函式工具（無 React 依賴）
├── api-client/      ← API 客戶端（自動生成或手寫）
├── config/          ← 共用設定（ESLint、TypeScript、Tailwind）
└── types/           ← 共用型別定義

apps/
├── web/             ← 主要 Web 應用
├── admin/           ← 管理後台
└── mobile/          ← React Native 應用（共用 utils 和 types）
```

**套件邊界的原則**：
- `ui` 套件不應該依賴 `api-client`（UI 元件不知道資料從哪裡來）
- `utils` 套件不應該依賴 React（讓它可以在非 React 環境使用）
- 依賴方向是有向的，不應該有循環依賴

### 5.4 Monorepo 的常見陷阱

**套件邊界模糊**：隨著時間演化，「應該放在哪個套件」的界線變得不清晰，最終每個套件都依賴其他套件，喪失了模組化的好處。

**共用太多導致緊耦合**：把太多東西放進共用套件，讓所有應用都高度依賴同一個套件，一個改動影響所有應用。

**版本管理複雜**：如果 Monorepo 中的套件對外發布，需要謹慎管理版本和 changelog（changesets 是常用的解法）。

---

## 六、路由架構

### 6.1 客戶端路由的設計

現代前端路由不只是「URL 對應到元件」，而是整個應用的資料流起點：

**File-based Routing（Next.js、Remix、TanStack Router）**：路由結構由檔案系統決定。優點：直覺、自動程式碼分割；缺點：複雜的路由邏輯（條件重定向、巢狀布局）不容易表達。

**Data Loading 與路由的整合**：Remix 的 Loader/Action 和 TanStack Router 的 `beforeLoad`/`loader`，讓資料載入成為路由的一部分，而不是元件的副作用。這讓：
- 並行載入多個路由的資料（不是瀑布式等待）
- 在資料載入完成後才渲染（避免 loading skeleton 的跳動）
- 錯誤邊界和 404 處理更自然

### 6.2 URL 作為狀態

URL 是最被低估的狀態管理工具：它可被分享、可被書籤、瀏覽器前進/後退天然支援。

把適合的狀態放在 URL 中：
- 搜尋關鍵字（`?q=keyword`）
- 過濾條件（`?status=active&category=electronics`）
- 分頁（`?page=2`）
- Tab 選擇（`?tab=settings`）

不應該放在 URL 的狀態：
- Modal 的開/關（除非這個 URL 需要被分享）
- 表單輸入的中間狀態
- 滾動位置

---

## 七、前端架構的決策框架

資深前端工程師面對架構決策時的思維流程：

**1. 先理解規模**：應用有多少頁面？多少工程師？預計維護多久？架構決策的複雜度應該和這個規模匹配。

**2. 識別真正的問題**：是「狀態同步問題」還是「程式碼組織問題」還是「效能問題」？不同的問題有不同的解法，不能都用「重寫架構」解決。

**3. 從簡單開始**：
- 狀態：Local State → Context → Zustand → Redux
- 路由：React Router → File-based Router（Next.js/TanStack Router）
- 程式碼組織：Layer-first → Feature-first → Monorepo

每一步只在前一步真的不夠用時才跨越。

**4. 技術債的前端版本**：前端最常見的技術債是「元件做太多事」——一個元件同時負責資料取得、業務邏輯、UI 渲染。這讓測試和重用都困難。清楚地分離這三個職責，是前端架構最重要的單一實踐。
