# Python — 資深工程師技能指南

> 本文件記錄資深工程師對 Python 的深度理解：不在於語法的細節，而在於 Python 的設計哲學、工程上的判斷取捨、以及在生產系統中使用 Python 時需要深刻理解的核心概念。

---

## 一、Python 的設計哲學

Python 的設計哲學濃縮在 PEP 20（The Zen of Python）中，其中最重要的幾條對工程決策影響深遠：

**"There should be one— and preferably only one —obvious way to do it."**
Python 偏好有清晰的慣用方式（idiomatic way），而不是給你無限的彈性。遵循 Pythonic 的寫法，不只是美學問題，更是可讀性和可維護性的問題。

**"Readability counts."**
Python 把可讀性放在極高的優先級。這不只是「寫好看的程式碼」，而是 Python 的設計者認為程式碼被閱讀的次數遠多於被寫的次數，因此可讀性是最重要的工程品質。

**"Explicit is better than implicit."**
Python 偏好明確的行為，避免魔法（magic）。這與一些「聰明」的設計模式相衝突——在 Python 中，寫清楚你在做什麼，通常優於使用複雜的 metaprogramming 達成「優雅」的結果。

**"Simple is better than complex. Complex is better than complicated."**
注意這裡的區分：複雜（Complex）是問題本身的本質複雜度，複雜化（Complicated）是不必要的人為複雜度。Python 接受必要的複雜度，但拒絕不必要的複雜化。

---

## 二、GIL（Global Interpreter Lock）的深度理解

GIL 是 Python（CPython 實作）中最被誤解的概念，也是最影響架構決策的特性。

### 2.1 GIL 是什麼，為什麼存在

GIL 是 CPython 的一個互斥鎖，確保同一時間只有一個 Thread 在執行 Python bytecode。它的存在讓 CPython 的記憶體管理（特別是 Reference Counting）可以不需要是 thread-safe 的，簡化了 CPython 的實作。

### 2.2 GIL 真正的影響

**GIL 不影響的情況**：
- **I/O-bound 程式**：當 Thread 在等待 I/O（網路請求、檔案讀寫、資料庫查詢）時，GIL 會被釋放，其他 Thread 可以執行。多執行緒在 I/O-bound 的場景仍然有效
- **C Extension**：NumPy、Pandas 等大量使用 C Extension 的程式庫，在執行 C 程式碼期間會釋放 GIL，因此可以真正並行

**GIL 有影響的情況**：
- **CPU-bound 的純 Python 程式碼**：多個 Thread 無法真正並行執行 Python bytecode，多執行緒在 CPU-bound 的場景不只無效，甚至因為 Thread 切換的開銷而更慢

### 2.3 GIL 的工程影響與應對策略

理解 GIL 後，資深工程師的判斷框架：

**I/O-bound 任務**：使用 `asyncio`（協程）或 `threading`（多執行緒）。asyncio 在高並發 I/O 場景通常更高效，因為沒有 Thread 切換的開銷。

**CPU-bound 任務**：使用 `multiprocessing`（多程序）。每個 Process 有自己的 Python 解釋器和 GIL，可以真正並行。代價是程序間通訊（IPC）的開銷和更高的記憶體使用。

**混合型任務**：通常的 Web 應用是 I/O-bound（等待 DB、等待外部 API），CPU-bound 的部分（影像處理、密集計算）應該分離到獨立的 worker process 或專門的服務。

**Python 3.12+ 的 Sub-Interpreter**：Python 正在逐步解決 GIL 的限制，PEP 703（Making the GIL Optional）在 Python 3.13 進入實驗階段。但這是長期演化，目前生產系統仍需要理解和應對 GIL 的限制。

---

## 三、非同步程式設計（asyncio）

### 3.1 協程（Coroutine）的本質

asyncio 不是多執行緒，也不是多程序，而是**協作式多工（Cooperative Multitasking）**：單個執行緒，透過在等待 I/O 時主動讓出控制權，讓其他協程有機會執行。

這個模型的優勢：
- 沒有 Thread 切換的開銷
- 沒有 Race Condition（同一時間只有一個協程在執行）
- 可以處理大量並發連線（C10K 問題）

這個模型的限制：
- 任何一個協程如果長時間不讓出控制權（CPU-bound 操作、同步阻塞呼叫），會凍結整個 event loop
- 需要整個呼叫鏈都是 async（async is viral）

### 3.2 async/await 的心智模型

```python
async def fetch_user(user_id: int) -> User:
    # await 讓出控制權，讓 event loop 處理其他協程
    # 在 I/O 完成後，這個協程會被恢復
    user = await db.get_user(user_id)
    return user

async def handle_request(user_ids: list[int]) -> list[User]:
    # 並行執行多個 I/O 操作：total time = max(各個操作的時間)
    users = await asyncio.gather(*[fetch_user(uid) for uid in user_ids])
    return users
```

**asyncio.gather vs asyncio.TaskGroup（Python 3.11+）**

`asyncio.gather` 在某個 task 拋出 exception 時，其他 task 會繼續執行（除非設定 `return_exceptions=False`）。`asyncio.TaskGroup` 遵循 structured concurrency 原則，任一 task 失敗時，所有 task 都會被取消，更安全也更容易推理。

### 3.3 同步程式碼進入 async 世界的陷阱

最常見的 asyncio 錯誤：在 async 函式中呼叫同步的阻塞操作：

```python
async def bad_handler():
    # 這會阻塞整個 event loop！
    time.sleep(1)  # 同步阻塞
    data = open("large_file.txt").read()  # 同步 I/O
    result = requests.get("https://api.example.com")  # 同步 HTTP

async def good_handler():
    await asyncio.sleep(1)  # 非同步，讓出控制權
    async with aiofiles.open("large_file.txt") as f:  # 非同步 I/O
        data = await f.read()
    async with aiohttp.ClientSession() as session:  # 非同步 HTTP
        result = await session.get("https://api.example.com")
```

如果必須執行同步的 CPU-bound 或阻塞操作，使用 `loop.run_in_executor()` 把它放到 Thread Pool 或 Process Pool 中執行，避免阻塞 event loop。

---

## 四、型別系統（Type Hints）

### 4.1 型別提示的工程價值

Python 的型別提示（Type Hints，PEP 484）是可選的，不影響執行時行為。但對工程實踐有深遠影響：

- **靜態分析**：mypy、pyright、pytype 可以在不執行程式碼的情況下發現型別錯誤
- **IDE 支援**：自動補全、重構、錯誤提示更準確
- **文件化**：函式的簽名本身就是文件，不需要猜測參數和返回值的型別
- **可維護性**：型別讓程式碼的意圖更明確，重構時更有信心

資深工程師的立場：**在新的 Python codebase 中，型別提示應該是預設，不是可選**。

### 4.2 進階型別概念

**Generic（泛型）**：

```python
from typing import TypeVar, Generic

T = TypeVar('T')

class Stack(Generic[T]):
    def __init__(self) -> None:
        self._items: list[T] = []
    
    def push(self, item: T) -> None:
        self._items.append(item)
    
    def pop(self) -> T:
        return self._items.pop()
```

**Protocol（結構型別）**：

Python 的 Protocol 實現了 Duck Typing 的靜態版本。不需要繼承，只要物件有對應的方法/屬性，就算滿足 Protocol：

```python
from typing import Protocol

class Drawable(Protocol):
    def draw(self) -> None: ...

def render(item: Drawable) -> None:
    item.draw()

# Circle 不需要繼承 Drawable，只要有 draw() 方法就行
class Circle:
    def draw(self) -> None:
        print("Drawing circle")

render(Circle())  # 型別檢查通過
```

Protocol 讓 Python 的 Duck Typing 可以被靜態工具驗證，是資深工程師設計 API 時的重要工具。

**TypedDict、dataclass、Pydantic 的選擇**：

- **TypedDict**：輕量，只是型別提示，沒有執行時行為。適合函式參數、設定字典的型別標注
- **dataclass**：自動生成 `__init__`、`__repr__`、`__eq__`。適合純資料容器，有執行時行為但沒有驗證
- **Pydantic**：有執行時的資料驗證和型別轉換。適合 API 輸入驗證、設定管理、任何需要驗證外部資料的場景

**選擇原則**：需要驗證外部輸入（API request、設定檔）用 Pydantic；純內部資料傳遞用 dataclass；只需要型別提示用 TypedDict。

---

## 五、效能陷阱與優化

### 5.1 Python 的效能現實

Python 比 C、Go、Java 慢是事實，但這個事實的實際影響需要具體分析：

- **大多數 Web 應用是 I/O-bound**，瓶頸在資料庫和網路，不在 Python 的執行速度
- **C Extension 讓關鍵部分極快**：NumPy 的矩陣運算、Pandas 的資料處理，性能接近 C
- **Python 的開發速度快**，在很多場景下，開發效率的提升遠比執行效率的損失重要

過早地因為「Python 慢」而放棄 Python，是常見的過度優化。在確認效能是瓶頸後，才考慮優化策略。

### 5.2 常見效能陷阱

**不必要的串列生成**：

```python
# 陷阱：生成完整的串列，佔用大量記憶體
total = sum([x * x for x in range(1_000_000)])

# 優化：使用 generator expression，惰性求值，不生成中間串列
total = sum(x * x for x in range(1_000_000))
```

**字串拼接的 O(n²) 問題**：

```python
# 陷阱：每次 += 都建立新的字串物件，O(n²) 時間複雜度
result = ""
for item in large_list:
    result += str(item)  # 避免

# 優化：收集後一次 join，O(n)
result = "".join(str(item) for item in large_list)
```

**在迴圈中查找屬性**：

```python
# 陷阱：每次迴圈都要查找 math.sqrt
import math
for i in range(1_000_000):
    result = math.sqrt(i)

# 優化：把常用的函式提取到本地變數
from math import sqrt
for i in range(1_000_000):
    result = sqrt(i)
```

**不恰當的資料結構**：

```python
# 陷阱：在 list 中搜尋，O(n)
valid_ids = [1, 2, 3, 4, 5, ...]  # 大型列表
if user_id in valid_ids:  # 每次搜尋是 O(n)
    ...

# 優化：使用 set，O(1) 查找
valid_ids = {1, 2, 3, 4, 5, ...}
if user_id in valid_ids:  # O(1)
    ...
```

**Global 變數的效能影響**：Python 存取 Local 變數比 Global 變數快，因為 Local 變數的查找使用 LOAD_FAST bytecode，Global 使用 LOAD_GLOBAL（需要字典查找）。在效能敏感的迴圈中，把 global 函式賦值給 local 變數可以有明顯改善。

### 5.3 Profiling 工具

**cProfile**：標準庫的 CPU profiler，測量每個函式的呼叫次數和總時間：
```bash
python -m cProfile -s cumulative my_script.py
```

**line_profiler**：逐行的 CPU profiler，找到函式內哪一行最耗時。比 cProfile 更細緻，但開銷也更高。

**memory_profiler**：記憶體使用的逐行分析。找記憶體洩漏和不必要的大量記憶體使用。

**py-spy**：低開銷的採樣 profiler，可以 attach 到正在運行的 Python 程序，不需要修改程式碼。適合在生產環境做效能分析。

---

## 六、Python 生態系與工具鏈

### 6.1 套件管理的演化

Python 的套件管理長期是一個痛點，工具的碎片化讓新人困惑。資深工程師對工具選擇的判斷：

**pip + venv**：標準工具，適合簡單專案和腳本。

**Poetry**：目前最推薦的專案管理工具，整合了依賴管理（解決複雜的依賴衝突）、虛擬環境、版本發布。`pyproject.toml` 是現代 Python 專案的標準。

**uv**（Astral 出品）：用 Rust 寫的超快速套件安裝器，比 pip 快 10-100 倍。正在快速成為業界標準，特別適合 CI 環境。

**Conda**：在資料科學領域仍然常用（處理非 Python 的 C/Fortran 依賴），但在純 Web 開發中通常不需要。

### 6.2 測試生態

**pytest**：Python 測試的事實標準。相較於 unittest，pytest 的 fixture 系統更靈活，parametrize 讓測試資料分離更清晰，plugin 生態系豐富。

**pytest-asyncio**：asyncio 程式碼的測試支援。

**hypothesis**：Property-based Testing 框架，自動生成測試案例，特別擅長發現邊界情況。對業務邏輯複雜的函式很有價值。

### 6.3 Web 框架的選擇哲學

**Django**：「電池全包」（batteries included）的哲學，提供 ORM、Admin、Auth、Template 等完整解決方案。適合傳統 Web 應用，特別是有複雜資料模型和後台管理需求的場景。約定優先於配置。

**FastAPI**：現代的、基於 asyncio 的 API 框架，原生支援型別提示和自動 OpenAPI 文件生成。在 API-first 的架構中是現在的最佳選擇。基於 Pydantic 的輸入驗證讓 API 開發更安全。

**Flask**：輕量微框架，幾乎不做假設，靈活但需要自己組裝。適合簡單的 API 服務或需要高度自訂的場景。對於複雜應用，Flask 的靈活性往往變成了缺乏結構的問題。

**選擇原則**：
- 需要完整功能（ORM、Admin、Auth）→ Django
- API 服務、microservice → FastAPI
- 簡單腳本或輕量服務 → Flask

---

## 七、Python 工程實踐

### 7.1 Python 的物件模型深度

**一切都是物件**：Python 中的類別、函式、模組都是物件。這讓 Python 的 metaprogramming 極其強大，但也容易被濫用。

**Dunder methods（魔術方法）**：Python 的運算符重載和協議的實作方式。理解 `__enter__`/`__exit__`（context manager）、`__iter__`/`__next__`（iterator）、`__getattr__`/`__setattr__`（屬性存取）是寫 Pythonic 程式碼的基礎。

**Descriptor Protocol**：`property`、`staticmethod`、`classmethod` 的底層機制。理解 Descriptor 讓你能夠設計出優雅的 API。

### 7.2 Context Manager 的廣泛應用

Context Manager（`with` 語句）不只是用於檔案和鎖，而是任何需要「資源取得 → 使用 → 資源釋放」模式的場景：

```python
from contextlib import contextmanager

@contextmanager
def timer(operation_name: str):
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        logger.info(f"{operation_name} took {elapsed:.3f}s")

with timer("database query"):
    results = db.execute(complex_query)
```

Context Manager 確保清理邏輯在任何情況下都會執行（包括 exception），是 Python 中資源管理的最佳實踐。

### 7.3 Generator 和惰性求值

Generator 是 Python 處理大量資料的關鍵工具：不需要把所有資料載入記憶體，而是按需生成：

```python
def read_large_file(filepath: str):
    """逐行讀取大型檔案，不把整個檔案載入記憶體"""
    with open(filepath) as f:
        for line in f:
            yield line.strip()

def process_records(records):
    """Generator pipeline：每個環節都是惰性的"""
    filtered = (r for r in records if r.is_valid())
    transformed = (transform(r) for r in filtered)
    return transformed

# 整個 pipeline 是惰性的，不會在記憶體中存放中間結果
for record in process_records(read_large_file("large_data.csv")):
    save_to_db(record)
```

### 7.4 錯誤處理的哲學

**EAFP（Easier to Ask Forgiveness than Permission）** vs **LBYL（Look Before You Leap）**：

Python 文化傾向 EAFP：先嘗試操作，如果失敗就處理 exception，而不是先檢查條件再操作。這讓程式碼更簡潔，且避免 TOCTOU（Time of Check to Time of Use）競爭條件。

```python
# LBYL（非 Pythonic）
if key in dictionary:
    value = dictionary[key]
else:
    value = default

# EAFP（Pythonic）
try:
    value = dictionary[key]
except KeyError:
    value = default

# 或者更簡潔
value = dictionary.get(key, default)
```

**Exception 的設計**：自定義 Exception 應該有清晰的繼承層次，讓呼叫端可以精確捕獲或廣泛捕獲。不要 `raise Exception("something went wrong")`，而是定義有語意的自定義 Exception。

**永遠不要裸 except**：`except Exception` 捕獲幾乎所有 exception（包括 `SystemExit`、`KeyboardInterrupt`），`except:` 更是連 BaseException 都捕獲。這讓程式碼無法被正常中斷，也隱藏了真正的問題。

---

## 八、資深工程師對 Python 的整體判斷

**Python 的最佳適用場景**：
- Web API 服務（特別是 FastAPI 的生態）
- 資料工程和資料科學（NumPy、Pandas、Spark 生態）
- 機器學習和 AI（無可爭議的業界標準）
- 自動化腳本和工具
- 原型快速驗證

**Python 的限制和替代方案**：
- CPU-bound 的高效能計算 → 考慮 Go、Rust、或把關鍵部分用 C Extension 實作
- 強型別、高可靠性的大型系統 → TypeScript（前端）、Go（後端服務）、Rust（系統程式設計）
- 行動應用 → 不適合

**Python 工程師的成長路徑**：從語法學習者，到理解 GIL 和 asyncio 模型，到能夠設計可測試、有型別的系統，到理解 CPython 的記憶體模型和效能特性，到能夠為 Python 生態做出貢獻。每個層次的理解深度，直接影響在生產系統中做出正確決策的能力。
