# Frontend Performance — 資深工程師技能指南

> 本文件記錄資深工程師對前端效能的思維框架：不只是技術技巧的清單，而是理解瀏覽器的運作模型、量測效能的正確方式、以及在不同渲染策略間做出有依據的選擇。前端效能的終極目標是使用者體驗，不是分數。

---

## 一、前端效能的量測基礎

### 1.1 為什麼 Lighthouse 分數不夠

Lighthouse 分數是有用的診斷工具，但不是效能的終點。它的限制：

- **Lab Data vs Field Data**：Lighthouse 在模擬環境下執行（模擬網路速度、模擬裝置）。真實使用者的網路和裝置千差萬別，Lab Data 可能和 Field Data 差距極大
- **不代表真實使用者體驗**：在無人使用的凌晨優化 Lighthouse 分數，不代表午後高峰時期的使用者體驗有所改善
- **分數可以被「遊戲化」**：針對 Lighthouse 的評分指標優化，而不是針對真實使用者體驗優化，是常見的誤區

**正確的量測方式**：使用 Real User Monitoring（RUM）收集真實使用者的效能資料。Google Search Console 的 Core Web Vitals 報告、Datadog RUM、Sentry Performance 都能提供 Field Data。

### 1.2 Core Web Vitals 的深度理解

Google 的 Core Web Vitals 是衡量使用者體驗的業界標準，三個指標各有不同的含義：

**LCP（Largest Contentful Paint）— 載入速度**

衡量：頁面最大的可見元素（通常是 hero 圖片、標題文字）何時完成渲染。
目標：< 2.5s（良好）；2.5-4s（需要改善）；> 4s（差）

LCP 最常見的元素類型：
- `<img>` 元素
- `<video>` 的 poster 圖片
- CSS background-image
- 包含大量文字的 block 元素

**LCP 的常見問題和原因**：
- 圖片沒有使用正確的格式（還在用 JPEG 而不是 WebP/AVIF）
- 圖片沒有 preload（瀏覽器在解析 HTML 前不知道要載入這張圖）
- 伺服器響應時間過長（TTFB 高）
- 渲染阻塞資源（大型 CSS、同步 JavaScript）

**INP（Interaction to Next Paint）— 互動回應性**

2024 年取代 FID，衡量：頁面在整個生命週期中，使用者互動後 UI 更新的速度。
目標：< 200ms（良好）

INP 是最難優化的指標，因為它衡量所有互動的最差情況，而不只是第一次互動。

**INP 的常見原因**：
- 主線程被長任務（Long Task，> 50ms）佔用，使用者輸入無法及時處理
- 大型的 React re-render（元件樹太大，每次狀態改變都重新渲染大量元件）
- 同步的資料處理在主線程執行

**CLS（Cumulative Layout Shift）— 視覺穩定性**

衡量：頁面載入過程中，元素意外移動的累積程度。
目標：< 0.1（良好）

CLS 最常見的原因：
- 圖片和影片沒有設定 `width` 和 `height` 屬性（瀏覽器無法提前預留空間）
- 動態注入的廣告或 embed 內容把其他內容推開
- 字型替換（FOUT/FOIT）導致文字重排

---

## 二、瀏覽器的渲染管線

理解瀏覽器如何把 HTML/CSS/JS 轉換成像素，是前端效能優化的基礎。

### 2.1 關鍵渲染路徑（Critical Rendering Path）

```
HTML Parsing → DOM Construction
CSS Parsing  → CSSOM Construction  → Render Tree → Layout → Paint → Composite
JavaScript   → (可能修改 DOM/CSSOM)
```

**阻塞渲染的資源**：

CSS 是渲染阻塞的（Render-blocking）：瀏覽器必須等待所有 CSS 下載和解析完成，才能建立 Render Tree 並開始繪製。優化方向：
- 把關鍵 CSS 內嵌到 HTML（Critical CSS Inlining）
- 非關鍵 CSS 用 `media` attribute 推遲（`<link rel="stylesheet" media="print">`）

JavaScript 是解析阻塞的（Parser-blocking）：`<script>` 標籤預設會暫停 HTML 解析。優化方向：
- `defer`：下載不阻塞，HTML 解析完後按順序執行
- `async`：下載不阻塞，下載完立即執行（不保證順序）
- 把 `<script>` 放在 `</body>` 前

### 2.2 Layout、Paint、Composite 的成本差異

修改不同的 CSS 屬性會觸發不同代價的重繪：

**Layout（Reflow，最昂貴）**：改變影響元素大小或位置的屬性，瀏覽器需要重新計算所有元素的幾何資訊。
觸發 Layout 的屬性：`width`、`height`、`margin`、`padding`、`font-size`、`display`

**Paint（較昂貴）**：改變元素的外觀，但不影響幾何。
觸發 Paint 的屬性：`color`、`background-color`、`border-color`、`box-shadow`

**Composite（最便宜）**：只影響合成層的位移或透明度，可以在 GPU 上完成，不需要 CPU 介入。
只觸發 Composite 的屬性：`transform`、`opacity`

**動畫效能優化原則**：所有動畫都應該只使用 `transform` 和 `opacity`。用 `transform: translateX()` 而不是 `left`，用 `transform: scale()` 而不是 `width/height`。

**will-change 屬性**：提示瀏覽器某個元素即將改變，讓瀏覽器提前為它建立獨立的合成層：

```css
.animated-element {
  will-change: transform;  /* 提示瀏覽器為這個元素建立合成層 */
}
```

注意：`will-change` 有記憶體成本，不要對所有元素使用，只對確實需要動畫的元素使用。

### 2.3 強制同步 Layout（Layout Thrashing）

最常見的效能問題之一：在 JavaScript 中交替讀取和修改 Layout 相關屬性：

```javascript
// 問題：每次讀取 offsetWidth 都強制瀏覽器完成 Layout 計算
for (const element of elements) {
  const width = element.offsetWidth;     // 讀取，強制 Layout
  element.style.width = width * 2 + 'px';  // 修改，使 Layout 失效
  // 下一次迴圈又讀取，又強制 Layout...
}

// 優化：先批量讀取，再批量寫入
const widths = elements.map(el => el.offsetWidth);  // 批量讀取
elements.forEach((el, i) => {
  el.style.width = widths[i] * 2 + 'px';  // 批量寫入
});
```

---

## 三、JavaScript Bundle 優化

### 3.1 Bundle 大小對效能的影響鏈

```
Bundle 大小大
  → 下載時間長（網路）
  → 解析時間長（CPU，移動裝置尤其慢）
  → 執行時間長（CPU）
  → 可互動時間（TTI）延遲
  → 使用者等待時間長
```

Bundle 大小不只影響下載時間，JavaScript 的解析和執行也需要 CPU 時間。在低端行動裝置上，1MB 的 JavaScript 可能需要超過 5 秒才能解析和執行完成。

### 3.2 Code Splitting 策略

**路由層級的 Code Splitting（最基本）**：每個路由對應的程式碼只在需要時載入：

```typescript
// React.lazy + Suspense：按路由分割
const OrdersPage = React.lazy(() => import('./pages/OrdersPage'));
const SettingsPage = React.lazy(() => import('./pages/SettingsPage'));

function App() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <Routes>
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Routes>
    </Suspense>
  );
}
```

**功能層級的 Code Splitting（進階）**：重型功能按需載入：

```typescript
// 圖表庫只在需要時載入
const [ChartComponent, setChartComponent] = useState(null);

const loadChart = async () => {
  const { Chart } = await import('./components/HeavyChart');
  setChartComponent(() => Chart);
};

// 或用 React.lazy
const RichTextEditor = React.lazy(() => import('./components/RichTextEditor'));
```

### 3.3 Tree Shaking 的正確理解

Tree Shaking 讓 bundler 只打包實際被使用的 export，移除 dead code。但 Tree Shaking 有很多「陷阱」：

**Side Effects 阻止 Tree Shaking**：如果一個模組有 side effects（修改全局狀態、執行 console.log 等），bundler 不敢移除它，即使沒有 export 被使用。在 `package.json` 中設定 `"sideEffects": false`（或列出有 side effects 的檔案），讓 bundler 知道可以安全移除未使用的模組。

**Named Import vs Default Import**：

```javascript
// 可以 Tree Shake：只引入需要的部分
import { debounce } from 'lodash-es';

// 不能 Tree Shake：引入整個 lodash（如果使用 CommonJS 版本）
import _ from 'lodash';
const debounce = _.debounce;
```

注意：`lodash` 是 CommonJS，不支援 Tree Shaking。應使用 `lodash-es`（ESM 版本）或只 import 需要的子模組（`import debounce from 'lodash/debounce'`）。

### 3.4 Bundle 分析與依賴審查

**分析工具**：
- `vite-bundle-visualizer`（Vite）
- `webpack-bundle-analyzer`（Webpack）
- `bundlephobia.com`：在安裝依賴前查看它的大小

**常見的意外大型依賴**：
- `moment.js`（包含所有語言的 locale，~300KB）→ 改用 `date-fns`（Tree Shakeable）或 `dayjs`
- `lodash`（CommonJS，整包引入）→ 改用 `lodash-es` 或內建方法
- `@mui/icons-material`（整包引入數千個 icon）→ 只引入需要的 icon

### 3.5 預載入策略

**`<link rel="preload">`**：告訴瀏覽器這個資源是當前頁面關鍵的，應該提前下載：

```html
<!-- 預載入 LCP 圖片 -->
<link rel="preload" as="image" href="/hero.webp" />

<!-- 預載入關鍵字型 -->
<link rel="preload" as="font" type="font/woff2" href="/fonts/Inter.woff2" crossorigin />
```

**`<link rel="prefetch">`**：提示瀏覽器這個資源在未來的導航中可能需要，在空閒時提前下載：

```html
<!-- 使用者很可能點擊「下一頁」，提前下載下一頁的資源 -->
<link rel="prefetch" href="/next-page-data.json" />
```

**`<link rel="preconnect">`**：提前建立到第三方域名的連線（DNS lookup、TCP handshake、TLS negotiation）：

```html
<!-- 提前連線到 API 伺服器 -->
<link rel="preconnect" href="https://api.example.com" />
<!-- 提前連線到字型服務 -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
```

---

## 四、圖片效能優化

圖片通常是頁面最大的資源，對 LCP 影響最大。

### 4.1 圖片格式的選擇

| 格式 | 特性 | 適用場景 |
|------|------|---------|
| AVIF | 最佳壓縮率，瀏覽器支援度增加中 | 照片、複雜圖形，現代瀏覽器 |
| WebP | 良好壓縮率，廣泛支援 | 照片、複雜圖形，通用首選 |
| SVG | 無損，可縮放，體積小 | Logo、圖示、簡單圖形 |
| PNG | 無損壓縮，支援透明 | 需要透明背景的圖形 |
| JPEG | 有損壓縮，廣泛支援 | 舊系統相容性要求 |

**使用 `<picture>` 提供多格式回退**：

```html
<picture>
  <source type="image/avif" srcset="/image.avif" />
  <source type="image/webp" srcset="/image.webp" />
  <img src="/image.jpg" alt="Description" width="800" height="600" />
</picture>
```

### 4.2 響應式圖片

不同螢幕大小的裝置，不需要下載相同大小的圖片：

```html
<!-- srcset + sizes：瀏覽器根據視窗大小選擇最合適的圖片 -->
<img
  srcset="/image-400.webp 400w, /image-800.webp 800w, /image-1200.webp 1200w"
  sizes="(max-width: 640px) 400px, (max-width: 1024px) 800px, 1200px"
  src="/image-800.webp"
  alt="Description"
  width="800"
  height="600"
/>
```

### 4.3 圖片載入策略

**Lazy Loading**：不在視窗中的圖片延遲載入：

```html
<!-- 原生 lazy loading，廣泛支援 -->
<img src="/image.webp" loading="lazy" alt="..." width="800" height="600" />
```

**重要**：LCP 元素（hero 圖片、上方折疊的主要圖片）不應該使用 `loading="lazy"`，因為它會延遲這些關鍵圖片的載入，直接損害 LCP 分數。

**fetchpriority="high"**：提示瀏覽器這個圖片的優先級很高（用於 LCP 圖片）：

```html
<img src="/hero.webp" fetchpriority="high" alt="..." />
```

---

## 五、渲染策略的深度比較

不同的渲染策略對效能的影響是根本性的，選擇正確的策略比所有的優化技巧都重要。

### 5.1 CSR（Client-Side Rendering）

**工作方式**：伺服器只返回空的 HTML shell，瀏覽器下載 JavaScript、執行、向 API 請求資料、渲染 UI。

**效能特性**：
- TTFB（Time to First Byte）快（伺服器直接返回靜態 HTML）
- FCP（First Contentful Paint）慢（需要等 JS 下載和執行）
- 對 SEO 不友好（爬蟲看到空頁面）
- 首次載入慢，但導航速度快（已載入的頁面切換是即時的）

**適合場景**：需要登入才能存取的應用（SEO 不重要）、互動非常頻繁的工具類應用（如圖表工具、協作應用）

### 5.2 SSR（Server-Side Rendering）

**工作方式**：每次請求，伺服器根據當前資料動態生成完整的 HTML，返回給瀏覽器。

**Hydration**：SSR 返回的 HTML 是靜態的，瀏覽器還需要「注水」（Hydration）讓 React 接管 DOM，使頁面可以互動。Hydration 過程中，頁面看起來已經渲染完成，但可能還不能互動（使用者感知的「幻像」）。

**效能特性**：
- FCP 快（HTML 已包含內容）
- SEO 友好
- 伺服器壓力大（每個請求都需要渲染）
- Hydration 成本：下載並執行 JS 的時間，在 Hydration 完成前頁面互動受限

**Hydration 的問題（Over-fetching JS）**：即使是靜態內容（FAQ 頁面、部落格文章），SSR 仍然需要下載並執行所有的 React 程式碼來完成 Hydration。這讓 SSR 頁面有時候在 FCP 之後很長時間才能真正可互動（高 TTI）。

### 5.3 SSG（Static Site Generation）

**工作方式**：在建置時（Build Time）生成所有頁面的靜態 HTML，部署到 CDN。

**效能特性**：
- 最快的 TTFB（從 CDN 邊緣節點直接返回靜態 HTML）
- 最好的 FCP
- SEO 最友好
- 限制：內容是靜態的，更新需要重新建置

**ISR（Incremental Static Regeneration，Next.js）**：在 SSG 的基礎上，允許單個頁面在設定的間隔後重新生成，不需要完整重新建置。適合更新頻率不高的內容（產品頁、部落格）。

### 5.4 Partial Hydration 與 Islands Architecture

解決 Hydration 成本問題的新思路：

**Islands Architecture**：頁面的大部分是靜態 HTML，只有需要互動的「孤島（Island）」才進行 Hydration 和 JS 執行。Astro 是這個架構的代表框架。

```
頁面 = 靜態 HTML（Header、文章內容、Footer）
     + 互動島嶼（留言區、收藏按鈕、購物車）
```

這讓頁面可以只為真正需要 JS 的部分載入和執行 JS，大幅減少 Hydration 的 JS 量。

**React Server Components（RSC，Next.js App Router）**：更細粒度的方案，元件層級決定「這個元件在伺服器渲染，那個元件在客戶端渲染」：

```typescript
// Server Component（預設）：在伺服器執行，不下載到客戶端，無 Hydration 成本
async function ProductList() {
  const products = await db.getProducts();  // 直接存取資料庫
  return <ul>{products.map(p => <ProductCard key={p.id} {...p} />)}</ul>;
}

// Client Component：下載到客戶端，有互動能力
'use client';
function AddToCartButton({ productId }: { productId: string }) {
  const [added, setAdded] = useState(false);
  return <button onClick={() => setAdded(true)}>{added ? '已加入' : '加入購物車'}</button>;
}
```

RSC 的核心收益：資料取得可以在伺服器完成（不需要 API 呼叫，直接讀資料庫），且伺服器元件的程式碼不需要下載到客戶端，大幅減少 bundle 大小。

### 5.5 渲染策略的選擇框架

```
頁面內容是否需要 SEO 或快速的 FCP？
├── 否（需要登入、工具應用）→ CSR
└── 是
    ├── 內容是否經常變動？
    │   ├── 否（部落格、文件）→ SSG（+ ISR 如果需要偶爾更新）
    │   └── 是
    │       ├── 是否有大量互動？
    │       │   ├── 否 → SSR with Islands Architecture
    │       │   └── 是 → SSR with React Server Components（Next.js App Router）
```

---

## 六、React 的效能優化

### 6.1 重新渲染的成本與控制

React 的預設行為是：當父元件重新渲染，所有子元件也重新渲染（即使 props 沒有改變）。在小型元件樹中，這幾乎沒有成本，不需要優化。在大型元件樹中，這可能成為效能瓶頸。

**React.memo**：記憶化元件，當 props 沒有改變時跳過重新渲染：

```typescript
const ExpensiveComponent = React.memo(function ExpensiveComponent({ data }) {
  // 只有 data 改變時才重新渲染
  return <ComplexVisualization data={data} />;
});
```

**useMemo**：記憶化昂貴的計算結果：

```typescript
const processedData = useMemo(() => {
  return expensiveDataTransformation(rawData);
}, [rawData]);  // 只有 rawData 改變時才重新計算
```

**useCallback**：記憶化函式引用，讓傳給子元件的 callback 保持穩定引用：

```typescript
const handleSubmit = useCallback((data: FormData) => {
  onSubmit(data);
}, [onSubmit]);  // 只有 onSubmit 改變時才建立新函式
```

**資深工程師的判斷**：`React.memo`、`useMemo`、`useCallback` 是有成本的（記憶化比較、儲存舊值）。**不要過早使用它們**。先量測確認重新渲染確實是問題後，再針對性地加入。在大多數場景下，React 的重新渲染速度足夠快，不需要特別優化。

### 6.2 狀態更新的批次處理

React 18 引入了 Automatic Batching：所有的狀態更新（即使在 setTimeout、Promise 等非同步操作中）都會被批次處理，只觸發一次重新渲染：

```typescript
// React 18：即使在 setTimeout 中，兩次 setState 只觸發一次渲染
setTimeout(() => {
  setCount(c => c + 1);  // 不立即渲染
  setName('new name');   // 不立即渲染
  // 批次處理後，只渲染一次
}, 1000);
```

### 6.3 使用 Transition 區分優先級更新

React 18 的 `useTransition` 讓你標記某些狀態更新是低優先級的，不應該阻塞使用者輸入：

```typescript
const [isPending, startTransition] = useTransition();

function handleSearch(query: string) {
  setInputValue(query);  // 高優先級：立即更新輸入框
  
  startTransition(() => {
    setSearchResults(filterResults(query));  // 低優先級：可以被中斷
  });
}
```

適用場景：搜尋過濾（輸入要即時，結果可以稍慢）、Tab 切換（點擊要即時，新內容可以稍慢）。

---

## 七、字型效能優化

字型是另一個常被忽視的效能瓶頸。

### 7.1 字型載入策略

**FOUT（Flash of Unstyled Text）**：字型未載入時，用系統字型顯示文字，字型載入後替換。文字可見但樣式不對。

**FOIT（Flash of Invisible Text）**：字型未載入時，文字不顯示（invisible），字型載入後才顯示。

**font-display 的選擇**：

```css
@font-face {
  font-family: 'Inter';
  src: url('/fonts/inter.woff2') format('woff2');
  /* swap：先用系統字型顯示（FOUT），字型載入後替換。SEO 友好 */
  font-display: swap;
  /* optional：如果字型無法在很短時間內載入，就用系統字型。最小的 CLS */
  /* font-display: optional; */
}
```

`font-display: swap` 是最常用的選擇：避免 FOIT，接受少量 CLS。對文字為主的頁面，`optional` 可以完全避免 CLS，但代價是字型可能根本不被套用。

### 7.2 系統字型的效能優勢

如果設計允許，使用系統字型堆疊（System Font Stack）完全避免字型載入問題：

```css
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 
               Helvetica, Arial, sans-serif;
}
```

系統字型已經在使用者的裝置上，零載入成本。GitHub、Bootstrap 5 都使用系統字型堆疊。

---

## 八、效能優化的優先順序

資深工程師的效能優化不是「技巧清單的逐項執行」，而是有策略的：

**第一優先：正確的渲染策略**
選錯了渲染策略（如用 CSR 構建需要 SEO 的頁面），所有其他優化都是在補救先天缺陷。

**第二優先：減少網路請求的總量和大小**
- 正確的圖片格式和大小
- Code Splitting 和 Tree Shaking
- 移除未使用的依賴

**第三優先：提高關鍵資源的優先級**
- Preload LCP 圖片
- Preconnect 第三方域名
- Critical CSS Inline

**第四優先：避免主線程阻塞**
- 移除 Long Task
- 動畫只使用 transform 和 opacity
- 重型計算移到 Web Worker

**第五優先：React 特定優化**
這是最後才考慮的，大多數效能問題不在這裡。

**量測驅動**：每一步優化前後都量測真實使用者的數據，確認改善是否真實。效能優化最常見的錯誤，是在沒有量測的情況下，優化了不是瓶頸的地方。
